
jQuery(document).ready(function ($) {
    "use strict";
$(document).on("click", ".activate-license-btn", function (event) {
    // Prevent default action
    event.preventDefault();

  var storedObfuscatedCode = $("#purchase_code").data("obfuscated-value");


    // Fetch nonce and URL from multilocaMenuNonce
    var nonce = multilocaMenuNonce.usernonce;
    var url = multilocaMenuNonce.userurl;

    // Fetch email and purchase code from the input fields
    var multilocaemail = $("#wcmlim_email").val();
    var multilocapurchasecode = $("#purchase_code").val();

    // Make the AJAX request
    $.ajax({
        url: url,
        type: "POST",
        data: {
            action: "save_multiloca_menu_options",
            wcmlim_email: multilocaemail,
            purchase_code: multilocapurchasecode,
            nonce: nonce
        },
      success: function (response) {
                if (response.result === 1) {
                    let successMessage =
                        "Your License Code Has Been Validated. Thank you for your purchase.";

                    // Store the email and obfuscated purchase code
                    $("#wcmlim_email").val(multilocaemail).prop("readonly", true);
                    $("#purchase_code")
                        .val(response.obfuscated_purchase_code)
                        .prop("readonly", true);

                    // Store email and obfuscated purchase code in data attributes
                    $("#wcmlim_email").data("stored-value", multilocaemail);
                    $("#purchase_code").data("obfuscated-value", response.obfuscated_purchase_code);

                    $(".remove-multiloca-license").show();

                    Swal.fire({
                        title: "Success",
                        text: successMessage,
                        icon: "success",
                    }).then(() => {
                        location.reload(); // Reload the page to persist the changes
                    });
                } else {
                    Swal.fire({
                        title: "Verification Error",
                        text: response.message || "An unexpected error occurred. Please try again.",
                        icon: "error",
                    });

                    $("#wcmlim_email").val("");
                    $("#purchase_code").val("");
                }
            },
            error: function (xhr) {
                Swal.fire({
                    title: "Error",
                    text: "An unexpected error occurred. Please try again.",
                    icon: "error",
                });
                console.error("AJAX Error:", xhr.responseText);
            },
        });
    });


       


    $(document).on("click", ".remove-multiloca-license", function (event) {

        var nonce = multilocaMenuNonce.usernonce;
        var url = multilocaMenuNonce.userurl;


        $.ajax({
            url: url,
            type: "post",
            data: {
              action: "remove_multiloca_menu_options",
              nonce: nonce,
            },
            success: function (response) {
              
               
                Swal.fire({
                  title: "Success",
                  text: "Your License Has Been Successfully Removed.",
                  icon: "success",
                }).then((result) => {
                    location.reload();
                  });
      
              
            },
          });


    });
});