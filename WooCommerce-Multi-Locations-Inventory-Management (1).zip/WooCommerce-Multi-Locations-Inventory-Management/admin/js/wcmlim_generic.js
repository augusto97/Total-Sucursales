/**
 * This file is used to add general JavaScript scripts for the WooCommerce Multi-Locations Inventory Management plugin.
 *
 */
jQuery(document).ready(function($) {

    // Handles AJAX request to save the selected distance unit for display settings
    $('#wcmlim_distance_unit').on('change', function() {
      var selectedValue = $(this).val();
      $.post(ajaxurl, {
        action: 'save_wcmlim_distance_unit',
        distance_unit: selectedValue
      }, function(response) {                    
      });
    });
  
});