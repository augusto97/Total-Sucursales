jQuery(document).ready(t => {
    jQuery("#per_page").on("change", function() {
        var t = jQuery(this).val();
        "" != t && (document.location.href = window.location.href + "&page=wcmlim-product-central" + t)
    });
    var a = 0;

    function c(t) {
        alertify.dismissAll();
        var a = jQuery(t.target),
            c = a && a.prev(),
            e = a.val().trim();
        if (e !== c.text().trim() && "" !== e) {
            var i = a.attr("data-id"),
                s = a.attr("data-name");
            jQuery.ajax({
                type: "POST",
                url: multi_inventory.ajaxurl,
                data: {
                    action: "wcmlim_product_updated",
                    "data-id": i,
                    inp_value: e,
                    "data-name": s
                },
                success: function(t) {
                    if (t != "" || t!= "null" || t != "undefined") {
                        "false" == JSON.parse(t) ? alertify.error("Sale price should be less than regular price") : c.text(e), a.hide(), c.show()
                    }
                }
            })
        } else a.hide(), c.show()
    }
    jQuery(".SIMS_fields li.SIMS_options_li ").each(function() {
        "Show" == jQuery(this).find(".switch input").attr("chech_status") && (a += 1)
    }), 0 == a && jQuery(".tablenav.top").html('<h4 class="setting-disabled-message">Please go to the settings tab and enable the columns settings as per requirement.</h4>'), jQuery(".prodcentral_bulk_edit thead tr th").length, jQuery("ul.pctabs li").click(function() {
        var t = jQuery(this).attr("data-tabid");
        jQuery("ul.pctabs li").removeClass("current"), jQuery(".tab-content").removeClass("current"), jQuery(this).addClass("current"), jQuery("#" + t).addClass("current")
    }), jQuery(".prodcentral_bulk_edit tbody").on("click", "td.id .stckup_product_id", function() {
        alertify.dismissAll();
        var t = jQuery(this).attr("prdctID");
        document.location.href = "post.php?post=" + t + "&action=edit"
    }), jQuery(".prodcentral_bulk_edit tbody").on("change", "td.stock_status.column-stock_status .switch input", function() {
        // alertify.dismissAll();
        var t = jQuery(this).attr("id");
        if (jQuery(this).is(":checked")) var a = " Yes",
            c = "instock";
        else var a = " No",
            c = "outofstock";
        jQuery(".stckup_product_stock_status." + t).html(a), jQuery("td.stock_status.column-stock_status input.clickedit." + t).val(c);
        var e = jQuery("td.stock_status.column-stock_status input.clickedit." + t).val(),
            i = jQuery("td.stock_status.column-stock_status input.clickedit." + t).attr("data-id"),
            s = jQuery("td.stock_status.column-stock_status input.clickedit." + t).attr("data-pid"),
            l = jQuery("td.stock_status.column-stock_status input.clickedit." + t).attr("data-name");
        jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_product_updated",
                "data-id": i,
                "data-pid": s,
                inp_value: e,
                "data-name": l
            },
            success: function() {
                location.reload();
            }
        })
    }), jQuery(".prodcentral_bulk_edit tbody").on("change", "td.manage_stock.column-manage_stock .switch input", function() {
        alertify.dismissAll();
        var t = jQuery(this).attr("id");
        if (jQuery(this).is(":checked")) var a = " Yes",
            c = 1;
        else var a = " No",
            c = null;
        jQuery(".product_stock_manage." + t).html(a), jQuery("td.manage_stock.column-manage_stock input.clickedit." + t).val(c);
        var e = jQuery("td.manage_stock.column-manage_stock input.clickedit." + t).val(),
            i = jQuery("td.manage_stock.column-manage_stock input.clickedit." + t).attr("data-id"),
            s = jQuery("td.manage_stock.column-manage_stock input.clickedit." + t).attr("data-name");
        jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_product_updated",
                "data-id": i,
                inp_value: e,
                "data-name": s
            },
            success: function() {
                location.reload()
            }
        })
    }), jQuery(".prodcentral_bulk_edit tbody").on("change", "td.status.column-status select.product_status", function() {
        alertify.dismissAll();
        var t = jQuery(this).attr("Pid"),
            a = this.value,
            c = jQuery(this).attr("data-name"),
            e = jQuery("form#product-edit-table input." + t + '[data-name="' + c + '"]').attr("data-id");
        jQuery("form#product-edit-table input." + t + '[data-name="' + c + '"]').val(this.value), jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_product_updated",
                "data-id": e,
                inp_value: a,
                "data-name": c
            },
            success: function(t) {
                console.log(t), alertify.success("Product Updated"), jQuery("select.product_status").hide(), jQuery(".stckup_product_status").show(), location.reload()
            }
        })
    }), jQuery(".prodcentral_bulk_edit tbody").on("change", "td.backorders.column-backorders select.bulk_product_backorder_edit", function() {
        alertify.dismissAll();
        var t = jQuery(this).attr("Pid"),
            a = this.value,
            c = jQuery(this).attr("data-name"),
            e = jQuery("form#product-edit-table input." + t + '[data-name="' + c + '"]').attr("data-id");
        jQuery("form#product-edit-table input." + t + '[data-name="' + c + '"]').val(this.value), jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_product_updated",
                "data-id": e,
                inp_value: a,
                "data-name": c
            },
            success: function(t) {
                alertify.success("Product Updated"), jQuery("select.bulk_product_backorder_edit").hide(), jQuery(".stckup_product_backorders").show(), location.reload()
            }
        })
    }), jQuery(".prodcentral_bulk_edit tbody").on("click", "label.lbledit", function() {
        alertify.dismissAll(), jQuery(this).hide(), jQuery(this).next().show().focus()
    }), jQuery(".prodcentral_bulk_edit tbody").on("focusout", ".clickedit", function() {
        var t = jQuery(this),
            a = t && t.prev();
        a.text("" === t.val() ? a.text() : t.val()), t.hide(), a.show()
    }), jQuery(".prodcentral_bulk_edit tbody").on("change", ".clickedit", function() {
        alertify.dismissAll(), jQuery(".clickedit").hide().focusout(c).keyup(function(t) {
            return c(t), !1
        })
    }), jQuery(".prodcentral_bulk_edit tbody").on("blur", "td.column-stock_at_location input", function() {
        var t = jQuery(this),
            a = t && t.prev(),
            c = t.val().trim();
        if (c !== a.text().trim() && "" !== c) {
            var e = t.attr("data-id"),
                i = t.attr("data-name"),
                s = t.attr("data-location");
            jQuery.ajax({
                type: "POST",
                url: multi_inventory.ajaxurl,
                data: {
                    action: "wcmlim_product_updated",
                    "data-id": e,
                    inp_value: c,
                    "data-name": i,
                    "data-location": s
                },
                success: function(e, i, s) {
                    a.text(c), t.hide(), a.show(), alertify.success("Product updated successfully")
                },
                error: function(t, a, c) {
                    alertify.error("Data not updated. Please try again.")
                }
            })
        } else t.hide(), a.show()
    }), jQuery("#Submit_ProdCentral_Control").click(function() {
        var t = [],
            a = 0;
        jQuery(".SIMS_fields li.SIMS_options_li ").each(function() {
            var c = jQuery(this).find(".switch input").attr("id"),
                e = jQuery(this).find(".switch input").attr("chech_status");
            t[a++] = c + "=" + e
        }), jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_update_product_central",
                arr: t,
                security: multi_inventory.check_nonce,
            },
            success: function(t) {
                alertify.alert("<div id='pophead' style='text-align: center;'><span class='dashicons dashicons-yes-alt'></span><h2>Columns Settings!</h2><h4>Updated Control Successfully<h4><div>", function() {
                    location.reload()
                })
            }
        })
    }), jQuery("#Enable_ProdCentral_Control").click(function() {
        jQuery(this).is(":checked") ? jQuery(".SIMS_fields li.SIMS_options_li ").each(function() {
            jQuery(this).find(".switch input").attr("chech_status", "Show"), jQuery(this).find(".switch input").prop("checked", !0)
        }) : jQuery(".SIMS_fields li.SIMS_options_li ").each(function() {
            jQuery(this).find(".switch input").attr("chech_status", "Hide"), jQuery(this).find(".switch input").prop("checked", !1)
        })
    }), jQuery("#Disable_ProdCentral_Control").click(function() {
        jQuery(this).is(":checked") && jQuery(".SIMS_fields li.SIMS_options_li ").each(function() {
            jQuery(this).find(".switch input").attr("chech_status", "Hide"), jQuery(this).find(".switch input").prop("checked", !1)
        })
    }), jQuery("form#Product_Central_Setting li.SIMS_options_li .switch input").change(function() {
        jQuery(this).is(":checked") ? jQuery(this).attr("chech_status", "Show") : jQuery(this).attr("chech_status", "Hide")
    }), jQuery(".ewc-filter-cat").on("change", function() {
        var t = jQuery(this).val();
        "" != t && (document.location.href = window.location.href + "&page=wcmlim-product-central" + t)
    }), jQuery(".ewc-filter-type").on("change", function() {
        var t = jQuery(this).val();
        "" != t && (document.location.href = window.location.href + "&page=wcmlim-product-central" + t)
    }), jQuery(".wcmlim_lst_search").keypress(function(t) {
        var a = jQuery(this).val();
        13 == t.which && "" != a && (document.location.href = window.location.href + "&page=wcmlim-product-central&search=" + a, t.preventDefault())
    }),jQuery(".inventory_search_search_input").keypress(function(t) {
        var a = jQuery(this).val();
        13 == t.which && "" != a && (document.location.href = window.location.href + "&page=wcmlim-product-central&tab=tab-3&inv_search=" + a, t.preventDefault())
    }), jQuery(".ewc-filter-stock-status").on("change", function() {
        var t = jQuery(this).val();
        "" != t && (document.location.href = window.location.href + "&page=wcmlim-product-central" + t)
    }), jQuery(".multipleSelection .selectBox").click(function() {
        var a = jQuery(this).attr("prdctID");
        t(this).next(".multipleSelection .checkBoxes.check_bx_" + a).slideToggle("slow")
    }), jQuery(".prodcentral_bulk_edit td.column-categories label.stckup_product_category").click(function() {
        var a = jQuery(this).attr("prdctID");
        jQuery(".multipleSelection").hide(), t(this).next("td.column-categories .multipleSelection.check_cat_" + a).toggle()
    }), jQuery(".prodcentral_bulk_edit td.column-tags label.stckup_product_tag").click(function() {
        var a = jQuery(this).attr("prdctID");
        jQuery(".multipleSelection").hide(), t(this).next("td.column-tags .multipleSelection.check_cat_" + a).toggle()
    }), jQuery(".prodcentral_bulk_edit label").click(function() {
        var t = jQuery(this).attr("lbl_cls");
        "category" != t && "tag" != t && jQuery(".multipleSelection").hide()
    }), jQuery(".multipleSelection .checkBoxes input").click(function() {
        jQuery(this).attr("cat_id");
        var t = jQuery(this).attr("data-id"),
            a = jQuery(this).attr("inpt_typ"),
            c = jQuery(this).attr("data-name"),
            e = [],
            i = 0;
        jQuery(".checkBoxes.check_bx_" + t + ' label[lbl_cls="' + a + '"]').each(function() {
            if (jQuery(this).find("input").is(":checked")) {
                var t = jQuery(this).find("input").attr("cat_nm");
                e[i++] = t
            }
        }), jQuery.ajax({
            type: "POST",
            url: multi_inventory.ajaxurl,
            data: {
                action: "wcmlim_product_updated",
                "data-id": t,
                inp_value: e,
                "data-name": c
            }
        }), alertify.success("Product Updated");
        var s = e.toString();
        jQuery("." + c + '[prdctid="' + t + '"]').html(s), console.log(".checkBoxes.check_bx_" + t + ' label[lbl_cls="' + a + '"]')
    }), t("#wcmlim-rest").click(function() {
        t("#cat-filter, #ewc-filter-type , #ewc-filter-stock-status").val(""), dataTable.page.len(10).draw()
    }), t("#product-edit-table #current-page-selector").keypress(function(a) {
        if (13 == a.which) {
            a.preventDefault();
            var c = t(this).val();
            if ("" !== c) {
                var e = window.location.href.split("?")[0];
                e += "?page=wcmlim-product-central&paged=" + c, window.location.href = e
            }
        }
    })
});