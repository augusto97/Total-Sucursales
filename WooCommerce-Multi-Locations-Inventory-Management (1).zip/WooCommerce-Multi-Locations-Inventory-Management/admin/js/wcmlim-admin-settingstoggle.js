jQuery(document).ready(function(){   
    const elements = [
        'wcmlim_distance_calculator_by_coordinates',
        'wcmlim_distance_calculator_by_cloudfare',
        'wcmlim_enable_autodetect_location_by_maxmind',
        'wcmlim_enable_autodetect_location',
        'wcmlim_enable_autodetect_location_with_ipinfo'
    ];

    // Check each element before adding event listeners
    elements.forEach(function(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.addEventListener('change', function() {
                wcmlimUpdateFields(elementId);
            });
        }
    });

    function wcmlimUpdateFields(checkedId){
        let checkboxIds = [
            'wcmlim_distance_calculator_by_coordinates',
            'wcmlim_distance_calculator_by_cloudfare',
            'wcmlim_enable_autodetect_location_by_maxmind',
            'wcmlim_enable_autodetect_location',
            'wcmlim_enable_autodetect_location_with_ipinfo'
        ];

        // Uncheck other checkboxes except the one that was changed
        jQuery.each(checkboxIds, function(index, id) {
            if (id !== checkedId) {
                jQuery('#' + id).prop('checked', false);
            }
        });
    }
});    

jQuery(document).ready(function($) {
  // Function to toggle OpenPOS Dynamic Pricing visibility
  function toggleOpenPOSDynamicPricing() {
    var openposCompatibility = $('#wcmlim_pos_compatiblity');
    var dynamicPricingSetting = $('.openpos-dynamic-pricing');
    if (openposCompatibility.is(':checked')) {
      dynamicPricingSetting.show();
    } else {
      dynamicPricingSetting.hide();
    }
  }

  // Function to toggle CTX Feed URLs visibility
  function toggleCTXFeedUrls() {
    var ctxFeedEnabled = $('#wcmlim_enable_ctx_feed');
    var feedUrlsSection = $('.wcmlim-ctx-feed-urls');
    if (ctxFeedEnabled.is(':checked')) {
      feedUrlsSection.show();
    } else {
      feedUrlsSection.hide();
    }
  }

  // Check initial state on page load
  toggleOpenPOSDynamicPricing();
  toggleCTXFeedUrls();

  // Listen for changes to OpenPOS Compatibility setting
  $('#wcmlim_pos_compatiblity').change(function() {
    toggleOpenPOSDynamicPricing();
  });

  // Listen for changes to CTX Feed setting
  $('#wcmlim_enable_ctx_feed').change(function() {
    toggleCTXFeedUrls();
  });

  // Copy URL functionality
  $('.wcmlim-copy-url').on('click', function(e) {
    e.preventDefault();
    var url = $(this).data('url');
    var $btn = $(this);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(function() {
        var originalText = $btn.text();
        $btn.text('Copied!');
        setTimeout(function() {
          $btn.text(originalText);
        }, 2000);
      });
    } else {
      // Fallback for older browsers
      var $temp = $('<input>');
      $('body').append($temp);
      $temp.val(url).select();
      document.execCommand('copy');
      $temp.remove();
      var originalText = $btn.text();
      $btn.text('Copied!');
      setTimeout(function() {
        $btn.text(originalText);
      }, 2000);
    }
  });
});
