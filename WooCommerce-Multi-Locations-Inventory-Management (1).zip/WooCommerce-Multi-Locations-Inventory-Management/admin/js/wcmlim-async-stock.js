jQuery(document).ready(function ($) {
    $('.wcmlim-stock-container').each(function () {
        var container = $(this);
        var productId = container.data('product-id');

        $.ajax({
            url: wcmlim_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wcmlim_load_stock',
                product_id: productId,
            },
            success: function (response) {
                if (response.success) {
                    container.html(response.data);
                } else {
                    container.html('<span class="wcmlim-error">Error loading stock data.</span>');
                }
            },
            error: function () {
                container.html('<span class="wcmlim-error">Unable to fetch stock data.</span>');
            }
        });
    });
});
