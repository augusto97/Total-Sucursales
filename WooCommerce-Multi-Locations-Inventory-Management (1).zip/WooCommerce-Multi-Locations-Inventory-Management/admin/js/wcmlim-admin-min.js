jQuery(document).ready(e => {
    function t() {
        function t() {
            var t = [];
            e.each(e("input[name='tax_input[locations][]']:not(:checked)"), function() {
                t.push(e(this).val())
            });
            for (let o = 0; o < t.length; o++) e("#locationID_" + t[o]).hide(), e(".locationID_" + t[o]).hide()
        }
        t(), jQuery("body").on("click", ".woocommerce_variation", function() {
            t()
        }), jQuery("#taxonomy-locations").on("click", ".selectit", function() {
            var t = jQuery(this).children("input").val(),
                o = jQuery(this).children("input").prop("checked"),
                i = e("#wcmlim_draft_stock_at_" + t).val(),
                a = jQuery("#product-type :selected").val();
            if ("variable" == a) {
                if (!0 === o) {
                    var c = e(".locationID_" + t).find("input[type='number']");
                    for (let l = 0; l < c.length; l++) c[l].value = "";
                    e(".locationID_" + t).show()
                } else {
                    var c = e(".locationID_" + t).find("input[type='number']");
                    for (let r = 0; r < c.length; r++) c[r].value = "";
                    e(".locationID_" + t).hide()
                }
            } else if ("simple" == a) {
                if (!0 === o) {
                    var n = e("#locationID_" + t).find("input[type='number']");
                    n.val(i), e("#locationID_" + t).show()
                }
                if (!1 === o) {
                    var n = e("#locationID_" + t).find("input[type='number']");
                    n.val(""), e("#locationID_" + t).hide()
                }
            }
        })
    }

    function o() {
        if (e(".taxonomy-locations").length > 0) {
            // Don't run validation until state dropdown is properly initialized
            if (typeof window.wcmlimStateInitialized !== 'undefined' && !window.wcmlimStateInitialized) {
                return;
            }
            var t = e("#tag-name").val(),
                o = e("#postal_code").val(),
                i = e("#country").val(),
                a = e("#locality").val(),
                l = e("#administrative_area_level_1").val(),
                c = e("#administrative_area_level_1").prop("disabled");
            var r = c || l.trim() !== "";
            "" != o && "" != i && "" != t && null != t && "" != a && r ? (e("#submit").removeAttr("disabled"), e(".alert-text").hide()) : (e("#submit").attr("disabled", !0), e(".alert-text").text("Please fill all mandatory fields.").show())
        }
    }
    jQuery("#wcmlim_restrict_guest_user_location").hide(), jQuery("#wcmlim_enable_restrict_guestuser_location").is(":checked") && jQuery("#wcmlim_restrict_guest_user_location").show(), jQuery("#wcmlim_enable_restrict_guestuser_location").on("change", function() {
        this.checked ? jQuery("#wcmlim_restrict_guest_user_location").show() : jQuery("#wcmlim_restrict_guest_user_location").hide()
    }), "on" == locationWidget.keys && t(), o(), jQuery("#postal_code, #tag-name, #country, #locality, #administrative_area_level_1").on("input change", function(e) {
        o()
    }), jQuery("#submit").click(function() {
        window.location.href.includes("location_group") && (jQuery(this).attr("disabled", !0), setTimeout(function() {
            location.reload()
        }, 1e3))
    });
    let i, a = {
            street_number: "short_name",
            route: "long_name",
            locality: "long_name",
            administrative_area_level_1: "long_name",
            country: "long_name",
            postal_code: "short_name"
        },
        c = document.getElementById("wcmlim_autocomplete_address");
    if (c) {
        c.addEventListener("focus", e => {
            (i = new google.maps.places.Autocomplete(document.getElementById("wcmlim_autocomplete_address"), {})).addListener("place_changed", l)
        });

        function l() {
            let t = i.getPlace();
            if (!t.geometry) {
                window.alert("Autocomplete's returned place contains no geometry");
                return
            }
            for (let c in a) document.getElementById(c).value = "", document.getElementById(c).disabled = !1;
            for (let l = 0; l < t.address_components.length; l++) {
                let r = t.address_components[l].types[0];
                if (a[r]) {
                    let n = t.address_components[l][a[r]];
                    document.getElementById(r).value = n
                }
            }
            var s = e("#wcmlim_autocomplete_address").val();
            e.ajax({
                url: multi_inventory.ajaxurl,
                type: "POST",
                dataType: "json",
                data: {
                    action: "wcmlim_get_lat_lng",
                    wcmlim_autocomplete_address: s,
                    security: multi_inventory.check_nonce
                },
                success(t) {
                    var o = JSON.parse(JSON.stringify(t));
                    let i = o.latitude,
                        a = o.longitude;
                    e("#wcmlim_lat").length && e("#wcmlim_lat").length && (e("#wcmlim_lat").val(i), e("#wcmlim_lng").val(a))
                }
            }), o()
        }
    }
    let r = e(".locationsParent").val();
    if (-1 != r ? e(".term-address-wrap, .term-streetNumber-wrap, .term-route-wrap, .term-city-wrap, .term-state-wrap, .term-postcode-wrap, .term-country-wrap, .term-email-wrap, .term-shippingZone-wrap, .term-shopManager-wrap, .term-paymentMethods-wrap, .term-pos-wrap, .term-shippingMethod-wrap").hide() : e(".term-address-wrap, .term-streetNumber-wrap, .term-route-wrap, .term-city-wrap, .term-state-wrap, .term-postcode-wrap, .term-country-wrap, .term-email-wrap, .term-shopManager-wrap, .term-paymentMethods-wrap, .term-pos-wrap, .term-shippingMethod-wrap").show(), e(".locationsParent").on("change", function(t) {
            let o = this.value; - 1 != o ? e(".term-address-wrap, .term-streetNumber-wrap, .term-route-wrap, .term-city-wrap, .term-state-wrap, .term-postcode-wrap, .term-country-wrap, .term-email-wrap, .term-shopManager-wrap, .term-paymentMethods-wrap, .term-pos-wrap, .term-shippingMethod-wrap").hide() : e(".term-address-wrap, .term-streetNumber-wrap, .term-route-wrap, .term-city-wrap, .term-state-wrap, .term-postcode-wrap, .term-country-wrap, .term-email-wrap, .term-shopManager-wrap, .term-paymentMethods-wrap, .term-pos-wrap, .term-shippingMethod-wrap").show()
        }), e("#locationList"), e("#_manage_stock").change(function() {
            e(".wc_input_stock").prop("disabled", !0), this.checked ? e("#inventory_product_data > #locationList").show() : e("#inventory_product_data > #locationList").hide()
        }), e("#_manage_stock").prop("checked")) {
        e("#locationList").show(), e("#inventory_product_data > #locationList").show(), e(".wc_input_stock").prop("disabled", !0);
        let n = e("#locationList > .locationInner  p > input[type='number']"),
            s = 0;
        n.each((e, t) => {
            s += parseInt(t.value || 0)
        });
        let m = parseInt(e(".wc_input_stock").val());
        // Only show stock mismatch warning if the sync feature is not enabled
       
    } else "simple" == e("#product-type :selected").val() && (e("#locationList").hide(), e("#inventory_product_data > #locationList").hide(), e("._manage_stock_field").append("<p style='color:red;'>To be able to manage stocks in Locations, please activate the <b>Stock Management</b> option.</p>"));
    e("#woocommerce-product-data").on("woocommerce_variations_loaded", () => {
        e(".woocommerce_variation").each((t, o) => {
            let i = e(`input[name$="variable_manage_stock[${t}]"]`);
            !1 == i.prop("checked") && i.closest("p.options").append("<p style='color:red;'>To be able to manage stocks in Locations, please activate the <b>Stock Management</b> option.</p>")
            
            // For variations, add stock mismatch check with sync feature condition
            let variationId = e(o).find('input[name^="variable_post_id"]').val();
            if (i.prop("checked")) {
                let varLocationInputs = e(o).find(".locationInner input[type='number']"),
                    varLocationSum = 0;
                varLocationInputs.each((idx, input) => {
                    varLocationSum += parseInt(e(input).val() || 0);
                });
                let varMainStock = parseInt(e(o).find(`input#variable_stock${t}`).val() || 0);
                
            }
        });
    }), e("#location,#chosen-select,#wcmlim_shipping_zone,#wcmlim_payment_methods,#wcmlim_shipping_method,#wcmlim_tax_locations").chosen({
        width: "95%"
    }), e("#wcmlim_shop_manager").chosen({
        width: "95%"
    }), e("#wcmlim_shop_regmanager").chosen({
        width: "95%",
        max_selected_options: 1
    });
    var p, d, h, u = passedData.keys;
    e("#wcmlim_exclude_locations_from_frontend").chosen({
        max_selected_options: u,
        width: "30%"
    }), e("#wcmlim_exclude_locations_from_frontend").bind("chosen:maxselected", function() {
        jQuery(".exclude_prod_onfront").html('<p class="exclude_prod_onfront1"> You can\'t add all locations to exclude</p>')
    });
    var w = passedData_group.keys;
    e("#wcmlim_exclude_locations_group_frontend").chosen({
        max_selected_options: w,
        width: "30%"
    }), e("#wcmlim_exclude_locations_group_frontend").bind("chosen:maxselected", function() {
        jQuery(".exclude_prodg_onfront").html('<p class="exclude_prodg_onfront1"> You can\'t add all location groups to exclude</p>')
    }), e("#wcmlim_exclude_locations_group_frontend").chosen({
        width: "30%"
    }), e("#woocommerce-order-items").find("tr.item").each((e, t) => {
        t.classList.add("with-wcmlim")
    }), e("#wcmlim_shipping_zone").on("change", () => {
        var t = e("#wcmlim_shipping_zone").val();
        e.ajax({
            url: multi_inventory.ajaxurl,
            type: "POST",
            dataType: "json",
            data: {
                action: "populate_shipping_methods",
                shippingMethods: t,
                security: multi_inventory.check_nonce
            },
            success(t) {
                var o = JSON.parse(JSON.stringify(t));
                e("#wcmlim_shipping_method").empty(), e.each(o, function(t, o) {
                    e("#wcmlim_shipping_method").append(e("<option></option>").attr("value", o.key).text(o.value))
                }), e("#wcmlim_shipping_method").trigger("chosen:updated")
            }
        })
    }), e("#woocommerce-order-items").on("aftertablesort", ".woocommerce_order_items", (t, o) => {
        let i = e(t.currentTarget);
        i.find("tr.order-item-wcml-panel").each((t, o) => {
            e(o).insertAfter(i.find("tr.item.with-wcmlim").filter(`[data-order_item_id="${e(o).data("order_item_id")}"]`))
        })
    }), e(".keyEye").on("click", function(t) {
        t.preventDefault(), e(".keyEye i").toggleClass("fa-eye fa-eye-slash"), "text" == e("#wcmlim_google_api_key").attr("type") ? e("#wcmlim_google_api_key").attr("type", "password") : "password" == e("#wcmlim_google_api_key").attr("type") && e("#wcmlim_google_api_key").attr("type", "text")
    }), e(".wcmlimvalidateGMAPI").on("click", function(t) {
        var o = e("#wcmlim_google_api_key").val();
        if (null != o && "" != o) {
            e(".wcmlimvalidateGMAPI").html('<i class="fa fa-cog fa-spin"></i> Connecting'), e.ajax({
                url: multi_inventory.ajaxurl,
                type: "POST",
                data: {
                    action: "distance_matrix_validate_api",
                    api: o
                },
                success: function(e) {
                    "valid" == (e = (e = e.toString()).trim()) ? (alertify.set("notifier", "position", "bottom-right"), alertify.success("Google Map API is valid with Distance Matrix Service")) : "You must enable Billing on the Google Cloud Project at https://console.cloud.google.com/project/_/billing/enable Learn more at https://developers.google.com/maps/gmp-get-started" == e ? (alertify.set("notifier", "position", "bottom-right"), alertify.error("You must enable Billing on the Google Cloud Project at https://console.cloud.google.com/project/_/billing/enable Learn more at https://developers.google.com/maps/gmp-get-started")) : (alertify.set("notifier", "position", "bottom-right"), alertify.error("Google Map API is invalid with Distance Matrix Service, Please enable Distance Matrix Service"))
                }
            }), e.ajax({
                url: multi_inventory.ajaxurl,
                type: "POST",
                data: {
                    action: "place_validate_api",
                    api: o
                },
                success: function(e) {
                    "valid" == (e = (e = e.toString()).trim()) ? (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.success("Google Map API is valid with Place API Service")) : "You must enable Billing on the Google Cloud Project at https://console.cloud.google.com/project/_/billing/enable Learn more at https://developers.google.com/maps/gmp-get-started" == e ? (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.error("You must enable Billing on the Google Cloud Project at https://console.cloud.google.com/project/_/billing/enable Learn more at https://developers.google.com/maps/gmp-get-started")) : (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.error("Google Map API is invalid with Place API Service, Please enable Place API Service"))
                }
            }), e.ajax({
                url: multi_inventory.ajaxurl,
                type: "POST",
                data: {
                    action: "geocode_validate_api",
                    api: o
                },
                success: function(e) {
                    "valid" == (e = (e = e.toString()).trim()) ? (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.success("Google Map API is valid with Geocode Service")) : (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.error("Google Map API is invalid with Geocode Service, Please enable Geocode Service"))
                }
            });
            let i = document.createElement("script");
            var a = "https:" == window.location.protocol ? "https:" : "http:";
            i.setAttribute("src", `${a}//maps.googleapis.com/maps/api/js?libraries=geometry&sensor=false&key=${o}&callback`), document.body.appendChild(i), window.console = {
                error: function() {
                    errorText = arguments["0"], errorText.includes("Google Maps JavaScript API error") ? (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.error("Google Map API is invalid with Map Javascript Service, Please enable Map Javascript Service")) : (alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.success("Google Map API is valid with Map Javascript Service"))
                }
            }, e(".wcmlimvalidateGMAPI").html("Validate")
        } else alertify.set("notifier", "position", "bottom-right"), alertify.set("notifier", "delay", 8), alertify.error("Please enter Google API Key and try again"), e(".wcmlimvalidateGMAPI").html("Validate")
    }), e("#wcmlim_phone_validation").length > 0 && e("#wcmlim_phone_validation").on("input", function() {
        var t = this.value;
        t.length > 12 || t.length < 5 ? (e(".button").prop("disabled", !0), e("#phonevalmsg").show(), e("#phonevalmsg").css("color", "red"), e("#phonevalmsg").html('<p style="color: #9c1d1d;margin: 4px 4px;font-weight: 400;text-align: left;"> Invalid Phone number, please enter digit beetween 5-12')) : (e(".button").prop("disabled", !1), e("#phonevalmsg").hide())
    }), e(".locationsParent").length > 0 && ("-1" != e("select.locationsParent").children("option:selected").val() && (e("#start_time").prop("disabled", !0), e("#end_time").prop("disabled", !0), e("#wcmlim_phone_validation").prop("disabled", !0), e(".term-time-wrap").hide(), e(".term-phone-wrap").hide()), e("select.locationsParent").change(function() {
        e(".button").prop("disabled", !0), e(".button").html("Fetching Details", !0);
        var t = e(this).children("option:selected").val();
        "-1" != t ? e.ajax({
            url: multi_inventory.ajaxurl,
            type: "post",
            data: {
                action: "show_parent_location_time",
                loc_id: t
            },
            success(t) {
                var o = JSON.parse(t);
                if ("yes" == o.error) {
                    window.alert("Something went wrong with the ajax.");
                    return
                }
                "" != o.start && "" != o.end && o.error && (e("#start_time").val(o.start), e("#end_time").val(o.end), e("#wcmlim_phone_validation").val(o.phone)), e("#start_time").prop("disabled", !0), e("#end_time").prop("disabled", !0), e("#wcmlim_phone_validation").prop("disabled", !0), e(".term-time-wrap").hide(), e(".term-phone-wrap").hide(), e(".button").prop("disabled", !1), e(".button").html("Update", !0)
            }
        }) : (e("#start_time").prop("disabled", !1), e("#end_time").prop("disabled", !1), e("#wcmlim_phone_validation").prop("disabled", !1), e(".term-time-wrap").show(), e(".term-phone-wrap").show(), e(".button").prop("disabled", !1), e(".button").html("Update", !0))
    })), jQuery("#wcmlim_allow_only_backend").on("change", function() {
        jQuery(this).is(":checked") && (jQuery(this).is(":checked"), jQuery("#wcmlim_next_closest_location").prop("checked", !1), jQuery("#wcmlim_hide_out_of_stock_location").prop("checked", !1), jQuery("#wcmlim_clear_cart").prop("checked", !1), jQuery("#wcmlim_enable_userspecific_location").prop("checked", !1), jQuery("#wcmlim_preferred_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location_by_maxmind").prop("checked", !1), jQuery("#wcmlim_geo_location").prop("checked", !1), jQuery("#wcmlim_suggestion_off").prop("checked", !1), jQuery("#wcmlim_auto_billing_address").prop("checked", !1), jQuery("#wcmlim_enable_price").prop("checked", !1), jQuery("#wcmlim_hide_show_location_dropdown").prop("checked", !1), jQuery("#wcmlim_enable_location_onshop").prop("checked", !1), jQuery("#wcmlim_enable_location_price_onshop").prop("checked", !1), jQuery("#wcmlim_sort_shop_asper_glocation").prop("checked", !1), jQuery("#wcmlim_use_location_widget").prop("checked", !1), jQuery("#wcmlim_enable_shipping_zones").prop("checked", !1), jQuery("#wcmlim_enable_shipping_methods").prop("checked", !1), jQuery("#wcmlim_assign_payment_methods_to_locations").prop("checked", !1), jQuery("#wcmlim_order_fulfil_automatically").prop("checked", !0), jQuery("#wcmlim_allow_local_pickup").prop("checked", !0))
    }), jQuery("#wcmlim_allow_local_pickup").on("change", function() {
        jQuery(this).is(":checked") && (switchStatus = jQuery(this).is(":checked"), jQuery("#wcmlim_next_closest_location").prop("checked", !1), jQuery("#wcmlim_hide_out_of_stock_location").prop("checked", !1), jQuery("#wcmlim_clear_cart").prop("checked", !1), jQuery("#wcmlim_enable_userspecific_location").prop("checked", !1), jQuery("#wcmlim_preferred_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location_by_maxmind").prop("checked", !1), jQuery("#wcmlim_geo_location").prop("checked", !1), jQuery("#wcmlim_suggestion_off").prop("checked", !1), jQuery("#wcmlim_auto_billing_address").prop("checked", !1), jQuery("#wcmlim_enable_price").prop("checked", !1), jQuery("#wcmlim_hide_show_location_dropdown").prop("checked", !1), jQuery("#wcmlim_enable_location_onshop").prop("checked", !1), jQuery("#wcmlim_enable_location_price_onshop").prop("checked", !1), jQuery("#wcmlim_sort_shop_asper_glocation").prop("checked", !1), jQuery("#wcmlim_use_location_widget").prop("checked", !1), jQuery("#wcmlim_enable_shipping_zones").prop("checked", !1), jQuery("#wcmlim_enable_shipping_methods").prop("checked", !1), jQuery("#wcmlim_assign_payment_methods_to_locations").prop("checked", !1), jQuery("#wcmlim_allow_only_backend").prop("checked", !0), jQuery("#wcmlim_allow_local_pickup").prop("checked", !0))
    }), e(".wcmlim_update_inline_stock").on("click", t => {
        e(".wcmlim_update_inline_stock_msg").css("visibility", "unset"), e(".wcmlim_update_inline_stock_msg").html('<i class="fas fa-spinner fa-spin"></i> Loading');
        var o = e(".wcmlim_stock_modal_location_stock").val(),
            i = e(".wcmlim_stock_modal_product_id").val(),
            a = e(".wcmlim_stock_modal_location_id").val();
        e("#stock_data_attr_change_" + i + "_" + a).attr("data-stock", o), e(".change_" + i + "_" + a).html("(" + o + ")"), e.ajax({
            url: multi_inventory.ajaxurl,
            type: "post",
            data: {
                action: "update_stock_inline",
                location_stock: o,
                product_id: i,
                location_id: a,
                security: multi_inventory.check_nonce,
            },
            success(t) {
                t && (e(".wcmlim_update_inline_stock_msg").html("Updated Stock Successfully!").delay(5e3).fadeIn(), setTimeout(function() {
                    e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
                }, 3e3)), document.getElementById("stockModal").style.display = "none", location.reload()
            }
        })
    }), e(".wcmlim_update_inline_price").on("click", t => {
        e(".wcmlim_update_inline_stock_msg").css("visibility", "unset"), e(".wcmlim_update_inline_stock_msg").html('<i class="fas fa-spinner fa-spin"></i> Loading');
        var o = e(".wcmlim_stock_modal_location_regular_price").val(),
            i = e(".wcmlim_stock_modal_location_sale_price").val(),
            a = e(".wcmlim_stock_modal_product_id").val(),
            c = e(".wcmlim_stock_modal_location_id").val(),
            l = e(".wcmlim_stock_modal_currency").val(),
            r = "";
        "NaN" === parseFloat(o) ? (e(".wcmlim_update_inline_stock_msg").html('<span class="wcmlim_modal_validation">Entered Regular Price is Invalid</span>').delay(1e3).fadeIn(), setTimeout(function() {
            e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
        }, 1e6)) : "NaN" === parseFloat(i) && null != o ? (e(".wcmlim_update_inline_stock_msg").html('<span class="wcmlim_modal_validation">Entered Sale Price is Invalid</span>').delay(1e3).fadeIn(), setTimeout(function() {
            e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
        }, 1e6)) : "" == o && "" != i ? (e(".wcmlim_update_inline_stock_msg").html('<span class="wcmlim_modal_validation">Regular Price is missing !</span>').delay(1e3).fadeIn(), setTimeout(function() {
            e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
        }, 1e6)) : "" != o && "" != i && parseFloat(o) < parseFloat(i) ? (e(".wcmlim_update_inline_stock_msg").html('<span class="wcmlim_modal_validation">Regular Price should be greater than Sale Price !</span>').delay(1e3).fadeIn(), setTimeout(function() {
            e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
        }, 1e6)) : ("" != i && null != i && "NaN" != i ? (o = parseFloat(o).toFixed(2), i = parseFloat(i).toFixed(2), r = '<del aria-hidden="true"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">' + l + "</span>" + o + '</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">' + l + "</span>" + i + "</span></ins>") : (o = parseFloat(o).toFixed(2), r = '<ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">' + l + "</span>" + o + "</span></ins>"), e("#price_data_attr_change_" + a + "_" + c).attr("data-saleprice", i), e("#price_data_attr_change_" + a + "_" + c).attr("data-regularprice", o), e(".price_change_" + a + "_" + c).html("(" + r + ")"), e.ajax({
            url: multi_inventory.ajaxurl,
            type: "post",
            data: {
                action: "update_price_inline",
                sale_price: i,
                regular_price: o,
                product_id: a,
                location_id: c
            },
            success(t) {
                t && (e(".wcmlim_update_inline_stock_msg").html("Updated Price Successfully!").delay(5e3).fadeIn(), setTimeout(function() {
                    e(".wcmlim_update_inline_stock_msg").css("visibility", "hidden")
                }, 3e3)), document.getElementById("priceModal").style.display = "none"
            }
        }))
    }), e(".wcmlim_edit_stock_pro_list").on("click", t => {
        var o = t.target.getAttribute("data-id"),
            i = t.target.getAttribute("data-location"),
            a = t.target.getAttribute("data-stock"),
            c = t.target.getAttribute("data-productname"),
            l = t.target.getAttribute("data-locationname");
        e(".wcmlim_stock_modal_product_name").text(c), e(".wcmlim_stock_modal_location_name").text("Stock At " + l), e(".wcmlim_stock_modal_location_stock").val(a), e(".wcmlim_stock_modal_product_id").val(o), e(".wcmlim_stock_modal_location_id").val(i);
        var r = document.getElementById("stockModal"),
            n = document.getElementsByClassName("wcmlim-close")[0];
        r.style.display = "block", n.onclick = function() {
            r.style.display = "none"
        }, window.onclick = function(e) {
            e.target == r && (r.style.display = "none")
        }
    }), e(".wcmlim_edit_price_pro_list").on("click", t => {
        e("#priceModal").css("padding-top", "13%");
        var o = t.target.getAttribute("data-id"),
            i = t.target.getAttribute("data-location"),
            a = t.target.getAttribute("data-regularprice"),
            c = t.target.getAttribute("data-saleprice"),
            l = t.target.getAttribute("data-currency"),
            r = t.target.getAttribute("data-productname"),
            n = t.target.getAttribute("data-locationname");
        e(".wcmlim_stock_modal_product_name").text(r), e(".wcmlim_stock_modal_location_name").text("Selected Location - " + n), e(".wcmlim_stock_modal_location_sale_price").val(c), e(".wcmlim_stock_modal_location_regular_price").val(a), e(".wcmlim_stock_modal_product_id").val(o), e(".wcmlim_stock_modal_location_id").val(i), e(".wcmlim_stock_modal_currency").val(l), e(".wcmlim_price_currency").text(l);
        var s = document.getElementById("priceModal"),
            m = document.getElementsByClassName("wcmlim-price-modal-close")[0];
        s.style.display = "block", m.onclick = function() {
            s.style.display = "none"
        }, window.onclick = function(e) {
            e.target == s && (s.style.display = "none")
        }
    })
}), document.addEventListener("wheel", function(e) {
    "number" === document.activeElement.type && document.activeElement.classList.contains("noscroll") && document.activeElement.blur()
}), jQuery(document).ready(e => {
    function t() {
        jQuery(".wcmlim_localpickup_instance_enabled").each(function() {
            var e = jQuery(this).attr("id"),
                t = jQuery('input[name="instance_id').val(),
                o = window.location.href,
                i = new URL(o).searchParams.get("zone_id");
            jQuery.ajax({
                url: multi_inventory.ajaxurl,
                type: "POST",
                data: {
                    action: "wcmlim_fetch_localpickup_instance_enabled",
                    instance_id: t,
                    zone_id: i,
                    this_id: e
                },
                success: function(t) {
                    "checked" == t ? jQuery("#" + e).prop("checked", !0) : jQuery("#" + e).prop("checked", !1)
                }
            })
        })
    }
    e("#wcmlim_use_location_widget").prop("checked") ? e("#wcmlim_option_for_selection").show() : e("#wcmlim_option_for_selection").hide(), e("#wcmlim_use_location_widget").click(function() {
        e("#wcmlim_use_location_widget").prop("checked") ? e("#wcmlim_option_for_selection").show() : e("#wcmlim_option_for_selection").hide()
    }), jQuery("#wcmlim_allow_only_backend").on("change", function() {
        jQuery(this).is(":checked") ? (jQuery(this).is(":checked"), jQuery("label[for='tab1']").css({
            cursor: "not-allowed",
            filter: "blur(1px)"
        }), jQuery("label[for='tab3']").css({
            cursor: "not-allowed",
            filter: "blur(1px)"
        }), jQuery("label[for='tab4']").css({
            cursor: "not-allowed",
            filter: "blur(1px)"
        }), jQuery("label[for='tab5']").css({
            cursor: "not-allowed",
            filter: "blur(1px)"
        }), jQuery("label[for='tab6']").css({
            cursor: "not-allowed",
            filter: "blur(1px)"
        }), jQuery("#wcmlim_enable_userspecific_location").parents("tr").hide(), jQuery("#wcmlim_exclude_locations_from_frontend").parents("tr").hide(), jQuery("#wcmlim_next_closest_location").parents("tr").hide(), jQuery("#wcmlim_distance_calculator_by_coordinates").parents("tr").hide(), jQuery("#wcmlim_hide_out_of_stock_location").parents("tr").hide(), jQuery("#wcmlim_clear_cart").parents("tr").hide(), jQuery("#wcmlim_pos_compatiblity").parents("tr").hide(), jQuery("#wcmlim_wc_pos_compatiblity").parents("tr").hide(), jQuery("#general_setting_form").children("h2").hide(), jQuery("#tab1").attr("disabled", "true"), jQuery("#tab3").attr("disabled", "true"), jQuery("#tab4").attr("disabled", "true"), jQuery("#tab5").attr("disabled", "true"), jQuery("#tab6").attr("disabled", "true"), jQuery("#wcmlim_next_closest_location").prop("checked", !1), jQuery("#wcmlim_hide_out_of_stock_location").prop("checked", !1), jQuery("#wcmlim_clear_cart").prop("checked", !1), jQuery("#wcmlim_enable_userspecific_location").prop("checked", !1), jQuery("#wcmlim_preferred_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location").prop("checked", !1), jQuery("#wcmlim_enable_autodetect_location_by_maxmind").prop("checked", !1), jQuery("#wcmlim_geo_location").prop("checked", !1), jQuery("#wcmlim_suggestion_off").prop("checked", !1), jQuery("#wcmlim_auto_billing_address").prop("checked", !1), jQuery("#wcmlim_enable_price").prop("checked", !1), jQuery("#wcmlim_hide_show_location_dropdown").prop("checked", !1), jQuery("#wcmlim_enable_location_onshop").prop("checked", !1), jQuery("#wcmlim_enable_location_price_onshop").prop("checked", !1), jQuery("#wcmlim_sort_shop_asper_glocation").prop("checked", !1), jQuery("#wcmlim_use_location_widget").prop("checked", !1), jQuery("#wcmlim_enable_shipping_zones").prop("checked", !1), jQuery("#wcmlim_enable_shipping_methods").prop("checked", !1), jQuery("#wcmlim_assign_payment_methods_to_locations").prop("checked", !1), jQuery("#wcmlim_order_fulfil_automatically").prop("checked", !0), jQuery("#wcmlim_allow_local_pickup").prop("checked", !0)) : (jQuery("#wcmlim_enable_userspecific_location").parents("tr").show(), jQuery("#wcmlim_exclude_locations_from_frontend").parents("tr").show(), jQuery("#wcmlim_next_closest_location").parents("tr").show(), jQuery("#wcmlim_distance_calculator_by_coordinates").parents("tr").show(), jQuery("#wcmlim_hide_out_of_stock_location").parents("tr").show(), jQuery("#wcmlim_clear_cart").parents("tr").show(), jQuery("#wcmlim_pos_compatiblity").parents("tr").show(), jQuery("#wcmlim_wc_pos_compatiblity").parents("tr").show(), jQuery("#general_setting_form").children("h2").show(), jQuery("label[for='tab1']").css({
            cursor: "",
            filter: ""
        }), jQuery("label[for='tab3']").css({
            cursor: "",
            filter: ""
        }), jQuery("label[for='tab4']").css({
            cursor: "",
            filter: ""
        }), jQuery("label[for='tab5']").css({
            cursor: "",
            filter: ""
        }), jQuery("label[for='tab6']").css({
            cursor: "",
            filter: ""
        }), jQuery("#tab1").removeAttr("disabled"), jQuery("#tab3").removeAttr("disabled"), jQuery("#tab4").removeAttr("disabled"), jQuery("#tab5").removeAttr("disabled"), jQuery("#tab6").removeAttr("disabled"))
    }), jQuery("#wcmlim_allow_only_backend").is(":checked") ? (jQuery("#wcmlim_enable_userspecific_location").parents("tr").hide(), jQuery("#wcmlim_exclude_locations_from_frontend").parents("tr").hide(), jQuery("#wcmlim_next_closest_location").parents("tr").hide(), jQuery("#wcmlim_distance_calculator_by_coordinates").parents("tr").hide(), jQuery("#wcmlim_hide_out_of_stock_location").parents("tr").hide(), jQuery("#wcmlim_clear_cart").parents("tr").hide(), jQuery("#wcmlim_pos_compatiblity").parents("tr").hide(), jQuery("#wcmlim_wc_pos_compatiblity").parents("tr").hide(), jQuery("#general_setting_form").children("h2").hide(), jQuery("label[for='tab1']").css({
        cursor: "not-allowed",
        filter: "blur(1px)"
    }), jQuery("label[for='tab3']").css({
        cursor: "not-allowed",
        filter: "blur(1px)"
    }), jQuery("label[for='tab4']").css({
        cursor: "not-allowed",
        filter: "blur(1px)"
    }), jQuery("label[for='tab5']").css({
        cursor: "not-allowed",
        filter: "blur(1px)"
    }), jQuery("label[for='tab6']").css({
        cursor: "not-allowed",
        filter: "blur(1px)"
    }), jQuery("#tab1").attr("disabled", "true"), jQuery("#tab3").attr("disabled", "true"), jQuery("#tab4").attr("disabled", "true"), jQuery("#tab5").attr("disabled", "true"), jQuery("#tab6").attr("disabled", "true")) : (jQuery("#wcmlim_enable_userspecific_location").parents("tr").show(), jQuery("#wcmlim_exclude_locations_from_frontend").parents("tr").show(), jQuery("#wcmlim_next_closest_location").parents("tr").show(), jQuery("#wcmlim_distance_calculator_by_coordinates").parents("tr").show(), jQuery("#wcmlim_hide_out_of_stock_location").parents("tr").show(), jQuery("#wcmlim_clear_cart").parents("tr").show(), jQuery("#wcmlim_pos_compatiblity").parents("tr").show(), jQuery("#wcmlim_wc_pos_compatiblity").parents("tr").show(), jQuery("#general_setting_form").children("h2").show(), jQuery("label[for='tab1']").css({
        cursor: "",
        filter: ""
    }), jQuery("label[for='tab3']").css({
        cursor: "",
        filter: ""
    }), jQuery("label[for='tab4']").css({
        cursor: "",
        filter: ""
    }), jQuery("label[for='tab5']").css({
        cursor: "",
        filter: ""
    }), jQuery("label[for='tab6']").css({
        cursor: "",
        filter: ""
    }), jQuery("#tab1").removeAttr("disabled"), jQuery("#tab3").removeAttr("disabled"), jQuery("#tab4").removeAttr("disabled"), jQuery("#tab5").removeAttr("disabled"), jQuery("#tab6").removeAttr("disabled")), jQuery(document).on("click", ".wcmlim_localpickup_instance_enabled", function() {
        var e = "";
        e = jQuery(this).is(":checked") ? 1 : 0;
        var t = jQuery(this).attr("id"),
            o = jQuery('input[name="instance_id').val(),
            i = window.location.href,
            a = new URL(i).searchParams.get("zone_id");
        jQuery.ajax({
            url: multi_inventory.ajaxurl,
            type: "POST",
            data: {
                action: "wcmlim_save_localpickup_instance_enabled",
                instance_id: o,
                zone_id: a,
                this_value: e,
                this_id: t
            },
            success: function(e) {}
        })
    }), jQuery(document).on("click", ".wc-shipping-zone-method-settings", function() {
        t()
    }), e(document).on("keypress", ".woocommerce.wcmlim_product_regular_price", function(e) {
        if (8 != e.which && 0 != e.which && 46 != e.which && (e.which < 48 || e.which > 57)) return !1
    }), e(document).on("keypress", ".woocommerce.wcmlim_product_sale_price", function(e) {
        if (8 != e.which && 0 != e.which && 46 != e.which && (e.which < 48 || e.which > 57)) return !1
    }), e(document).on("blur", ".woocommerce.wcmlim_product_sale_price", function(t) {
        var o = e(this).val(),
            i = e(this).parent().parent().find(".wcmlim_product_regular_price").val();
        parseFloat(o) > parseFloat(i) && (Swal.fire({
            icon: "error",
            text: "Sale Price can not be greater than Regular Price !"
        }), e(this).val(""))
    }), jQuery(".userRestrictNote").length && jQuery(document).ready(function() {
        function e(e) {
            document.querySelector(".userRestrict input[type=checkbox]:checked") ? e.style.display = "block" : e.style.display = "none"
        }
        var t = document.querySelector(".userRestrictNote");
        t.style.display = "none", e(t), jQuery(".userRestrict").click(function() {
            e(t)
        })
    })
}), jQuery(document).ready(function() {
    var e = jQuery("#bulk-edit-modal");
    jQuery(".bulk-edit-modal-close").on("click", function() {
        e.hide()
    }), jQuery(window).on("click", function(t) {
        t.target === e[0] && e.hide()
    })
}), jQuery(document).ready(function(e) {
    jQuery("#cb-select-all-2").click(function() {
        e(this).is(":checked") ? (console.log("checked"), e("input[type='checkbox']").prop("checked", !0)) : (console.log("unchecked"), e("input[type='checkbox']").prop("checked", !1))
    }), e("#bulk-edit-btn").click(function() {
        if (e(".SIMS_options_li #cb").prop("checked")) {
            var t = [];
            if (e(".check-column input:checked").each(function() {
                    t.push(e(this).val())
                }), 0 === t.length) {
                alertify.error("Please select multiple products for bulk editing.");
                return
            }
            e("#bulk-edit-modal").show()
        } else alertify.error("Please enable bulk edit option from settings")
    }), e("#apply-changes").click(function() {
        var t = [];
        e(".check-column input:checked").each(function() {
            t.push(e(this).val()), location.reload()
        }), e("#stock_location").val();
        let o = [];
        e(".stock_location").each(function() {
            var t = e(this).val(),
                i = e(this).data("locid");
            o.push({
                locid: i,
                value: t
            })
        }), e.ajax({
            url: multi_inventory.ajaxurl,
            type: "POST",
            data: {
                action: "bulk_edit_products",
                products: t,
                bulk_update_loc: o,
                security: multi_inventory.check_nonce
            },
            success: function(t) {
                e("#bulk-edit-modal").hide(), alertify.success(t.data)
            }
        })
    }), e("#wcmlim_enable_location_group").change(function() {
        e(this).is(":checked") && e.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                action: "check_location_group"
            },
            success: function(t) {
                "false" === t && (alert("Please add at least one location group and map it properly."), e("#wcmlim_enable_location_group").prop("checked", !0))
            }
        })
    })
});