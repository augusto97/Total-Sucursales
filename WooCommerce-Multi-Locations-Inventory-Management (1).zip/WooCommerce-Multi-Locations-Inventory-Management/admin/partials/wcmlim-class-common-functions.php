<?php

/**
 * All Common Functions of the plugin for admin side.
 *
 * @link       http://www.techspawn.com
 * @since      1.2.10
 *
 * @package    Wcmlim
 * @subpackage Wcmlim/admin/partials
 */

class Wcmlim_Common_Functions
{
    public function __construct(){

    }

    public function wcmlim_order_page_top_location_filter($domain, $filter_id, $current){
        echo '<select name="' . esc_attr($filter_id) . '">
        <option value="">' . esc_html__('All locations', $domain) . '</option>';

        // Get all location terms directly
        $terms = get_terms(array(
            'taxonomy' => 'locations', 
            'hide_empty' => false, 
            'parent' => 0
        ));

        foreach ($terms as $term) {
            $term_slug = count(explode(" ", $term->name)) > 1 
                ? str_replace(' ', '-', strtolower($term->name)) 
                : $term->name;
                
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($term_slug),
                selected($term_slug, $current, false),
                esc_html($term->name)
            );
        }
        
        echo '</select>';
    }

    // Custom function where metakeys / labels pairs are defined
    public function wcmlim_get_filter_shop_order_meta($domain = 'woocommerce')
    {
        $order_filter = array();
        
        // Retrieve taxonomy terms directly
        $terms = get_terms(array(
            'taxonomy' => 'locations', 
            'hide_empty' => false, 
            'parent' => 0
        ));

        foreach ($terms as $term) {
            $term_slug = count(explode(" ", $term->name)) > 1 
                ? str_replace(' ', '-', strtolower($term->name)) 
                : $term->name;
                
            $order_filter[] = array(
                $term_slug => __($term->name, $domain),
            );
        }
        
        return $order_filter;
    }
}