<?php

/**
 * Provide an admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://www.techspawn.com
 * @since      1.0.0
 *
 * @package    Wcmlim
 * @subpackage Wcmlim/admin/partials
 */

// Fetching the license-related options from the database
$wcmlim_license      = get_option('wcmlim_license'); // Default to empty if not set
$wcmlim_email        = get_option('wcmlim_email');   // Default to empty if not set
$wcmlim_license_key  = get_option('purchase_code'); // Default to empty if not set
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


<!-- Replacing Design Preview Section -->
<div class="plugin-dashboard">
    <header class="dashboard-header">
        <h1><?php esc_html_e('MULTILOCA - WooCommerce Multi Locations Inventory Management', 'wcmlim'); ?></h1>
    </header>

    <section class="features-grid">
        <div class="feature-card">
            <i class="fas fa-solid fa-location-pin feature-icon"></i>
            <h2><?php esc_html_e('Find the Nearest Location', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Enable visitors to easily locate nearby stores on product pages or throughout the website.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-solid fa-dollar-sign feature-icon"></i>
            <h2><?php esc_html_e('Location-Wise Price', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Implement location-wise pricing for targeted and effective pricing strategies.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-solid fa-truck feature-icon"></i>
            <h2><?php esc_html_e('Location-Specific Shipping', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Adjusts shipping methods and rates based on customer location and delivery preferences.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-solid fa-cart-plus feature-icon"></i>
            <h2><?php esc_html_e('Ajax Add-to-Cart', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Allow users to add products to the cart without reloading the page.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-map-marker-alt feature-icon"></i>
            <h2><?php esc_html_e('Location Shop Manager', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Assign shop managers to specific locations for streamlined operations.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-sync-alt feature-icon"></i>
            <h2><?php esc_html_e('Auto Order Fullfilment Based on Rules', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Automatically processes and ships orders based on rules.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-cogs feature-icon"></i>
            <h2><?php esc_html_e('Backend-Only Mode', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Simplifying the ordering process for customers automatically from the backend.', 'wcmlim'); ?></p>
        </div>
        <div class="feature-card">
            <i class="fas fa-code-branch feature-icon"></i>
            <h2><?php esc_html_e('Rest API', 'wcmlim'); ?></h2>
            <p><?php esc_html_e('Provides an API for retrieving and updating product stock at different locations.', 'wcmlim'); ?></p>
        </div>
    </section>

  <div class="license-section">
    <h2><?php esc_html_e('License Key Verification', 'wcmlim'); ?></h2>
    <?php if ($wcmlim_license == "invalid" || $wcmlim_license == '') : ?>
        <div class="license-input">
            <input type="text" id="wcmlim_email" placeholder="<?php esc_attr_e('Enter Registered Email Address', 'wcmlim'); ?>" />
            <input type="text" id="purchase_code" placeholder="<?php esc_attr_e('Enter Envato Purchase Code', 'wcmlim'); ?>" />
            <button id="activateLicense" class="activate-license-btn" location.reload()><?php esc_html_e('Activate', 'wcmlim'); ?></button>
        </div>
    <?php elseif ($wcmlim_license == "valid") : ?>
        <div class="license-input">
            <input type="text" id="wcmlim_email" value="<?php echo esc_attr($wcmlim_email); ?>" readonly />
             <?php
                $obfuscated_purchase_code = substr($wcmlim_license_key, 0, -3) . '***';
                ?>
              <input type="text" id="purchase_code" value="<?php echo esc_attr($obfuscated_purchase_code); ?>" readonly />
            <button id="removeLicense" class="remove-multiloca-license"><?php esc_html_e('Remove', 'wcmlim'); ?></button>
        </div>
    <?php endif; ?>
</div>


    <div class="notices-section">
        <h2><?php esc_html_e('Notices', 'wcmlim'); ?></h2>
        <?php if ($wcmlim_license == '' || $wcmlim_license == "invalid") : ?>
            <div class="notice-card">
                <i class="fas fa-info-circle notice-icon"></i>
                <p><?php echo sprintf(esc_html__('For any queries, kindly contact us at - %s', 'wcmlim'), '<b>support@techspawn.com</b>'); ?></p>
            </div>
            <div class="notice-card warning">
                <i class="fas fa-exclamation-circle notice-icon"></i>
                <p><?php esc_html_e('Your plugin support is not active. Kindly renew your support.', 'wcmlim'); ?></p>
            </div>
            <div class="notice-card error">
                <i class="fas fa-times-circle notice-icon"></i>
                <p><?php esc_html_e('Please enter your registered email address and Envato purchase code to activate the license.', 'wcmlim'); ?></p>
            </div>
        <?php elseif ($wcmlim_license == "valid") : ?>
            <div class="notice-card">
                <i class="fas fa-info-circle notice-icon"></i>
                <p><?php echo sprintf(esc_html__('For any queries, kindly contact us at - %s', 'wcmlim'), '<b>support@techspawn.com</b>'); ?></p>
            </div>
            <div class="notice-card warning">
                <i class="fas fa-exclamation-circle notice-icon"></i>
                <p><?php esc_html_e('Your support is expiring in the next 6 months.', 'wcmlim'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
