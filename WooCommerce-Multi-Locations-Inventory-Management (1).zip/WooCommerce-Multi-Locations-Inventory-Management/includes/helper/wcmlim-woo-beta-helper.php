<?php

// This file will make our plugin compatible with beta version of woocommerce product editor


use Automattic\WooCommerce\Admin\BlockTemplates\BlockInterface;

if ( ! function_exists( 'wcmlim_add_block' ) ) {
	/**
	 * Add a new block to the template after the product name field.
	 *
	 * @param BlockInterface $product_name_field The product name block.
	 */
	function wcmlim_add_block( BlockInterface $product_name_field ) {
    

		$parent = $product_name_field->get_parent();

        global $wpdb;

       $backendonlymode = get_option('wcmlim_allow_only_backend');
       $specific_location = 'on';
       //$stockmanagment = get_post_meta($product_id, '_manage_stock', true);
       $defaultLocation = get_option("wcmlim_enable_default_location");

       $product_inventory_quantity_hide_conditions   = array(
        array(
            'expression' => 'editedProduct.manage_stock === false',
        ),
    );

   $location_section = $parent->add_block(
[
'id'         =>'wcmlim-location-section',

'blockName'  => 'woocommerce/product-section',
'attributes' => [
   'property' => 'meta_data.'.$location_allow_specific_location,
    'title'    => 'Manage Locations',
    'description' => sprintf(
                
                    __( 'Manage Location Specific Settings For MULTILOCA - WooCommerce Multi Locations Inventory Management', 'woocommerce' ),
                    
                ),
                //'blockGap'    => 'unit-40',
],
'hideConditions' => $product_inventory_quantity_hide_conditions,


]  
);   

       
        
        $taxonomy = 'locations';
        $locations = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
        ]);
        
        if ($defaultLocation == "on" && $backendonlymode != "on") {
        
        $options[] = array(

            'label' => 'Select Location',
            'value' => '',

        ) ;

        foreach ($locations as $key => $term) {
           
            $options[] = array(
              
                'label' => $term->name,
                'value' => "loc_".$key,

            );

          
          
        }  


        $location_section->add_block(
            [
            'id'         => 'wcmlim-default-location',
           
            'blockName'  => 'woocommerce/product-select-field',
            'attributes' => [
                'property' => 'meta_data.wcmlim_default_location',
                'label'    => 'Default Location',
                'tooltip'  => __(
                            'This setting controls whether customers can place an order even if there is insufficient stock',
                            'woocommerce'
                        ),
                'options' => $options,
                
            
        
           
        ],
            ]  
        ); 

    }

       



        foreach($locations as $location){

        $location_id = $location->term_id;
        $location_stock_meta_key = 'wcmlim_stock_at_' . $location_id;
        $location_regular_price_meta_key = 'wcmlim_regular_price_at_' . $location_id;
        $location_sale_price_meta_key = 'wcmlim_sale_price_at_' . $location_id;
        $location_allow_backorder = 'wcmlim_allow_backorder_at_' . $location_id;
        $location_allow_specific_location = 'wcmlim_allow_specific_location_at_' . $location_id;
        $location_purchase_price_meta_key = 'wcmlim_cogs_at_' . $location_id;
        $location_name = $location->name; 

       
 



//This is the new UI 


      $location_subsection =  $location_section->add_block(
            [
            'id'         => 'subsection-'.$location_name,
          
            'blockName'  => 'woocommerce/product-subsection',
            'attributes' => [
               'property' => 'meta_data.'.$locationss,
                'title'    => $location_name,
                
            ],
        
           
        ]  
        );  

     $custom_columns  = $location_subsection->add_block(
        array(
            'id'        => 'wcmlim-group-columns-'.$location_name,
            'blockName' => 'core/columns',
            
        )
    );

    $pricing_columns  = $custom_columns->add_block(
        array(
            'id'        => 'wcmlim-pricing-group-pricing-columns-'.$location_name,
            'blockName' => 'core/columns',
            
        )
    );
    
      $stock_column = $pricing_columns->add_block(
        [
            'id'         => 'wcmlim-custom-group-stock-'.$location_id,
            'blockName'  => 'core/column',
            
            'attributes' => [
                'templateLock' => 'all',
            ],
        ]
    );

    $stock_column->add_block(
                [
                'id'         => 'stock-quantity-at-'.$location_name,
               
                'blockName'  => 'woocommerce/product-number-field',
                'attributes' => [
                    'property' => 'meta_data.'.$location_stock_meta_key,
                    'label'    => 'Stock',
                    'placeholder' => 'Enter Stock For '.$location_name
                ],
        
               
          ]  
        );  

      
    
       
        if ($backendonlymode != "on") {
        
        
   
    
    $pricing_column_1 = $pricing_columns->add_block(
        [
            'id'         => 'wcmlim-pricing-group-regular-price'.$location_id,
            'blockName'  => 'core/column',
            
            'attributes' => [
                'templateLock' => 'all',
            ],
        ]
    );


    $pricing_column_1->add_block(
        [
        'id'         => 'regular-price-at-'.$location_name,
       
        'blockName'  => 'woocommerce/product-pricing-field',
        'attributes' => [
            'property' => 'meta_data.'.$location_regular_price_meta_key,
            'label'    => 'Price',
            'placeholder' => 'Enter Regular Price For '.$location_name
        ],

       
  ]  
);  

$pricing_column_2 = $pricing_columns->add_block(
    [
        'id'         => 'wcmlim-pricing-group-sale-price'.$location_id,
        'blockName'  => 'core/column',
        
        'attributes' => [
            'templateLock' => 'all',
        ],
    ]
);
    
    
    $pricing_column_2->add_block(
            [
            'id'         => 'sale-price-at-'.$location_name,
           
            'blockName'  => 'woocommerce/product-pricing-field',
            'attributes' => [
                'property' => 'meta_data.'.$location_sale_price_meta_key,
                'label'    => 'Sale Price',
                'placeholder' => 'Enter Sale Price For '.$location_name
                
            ],
            
    
           
      ]  
    );  

    $pricing_column_3 = $pricing_columns->add_block(
        [
            'id'         => 'wcmlim-pricing-group-purchase-price'.$location_id,
            'blockName'  => 'core/column',
            
            'attributes' => [
                'templateLock' => 'all',
            ],
        ]
    );
        
        
        $pricing_column_3->add_block(
                [
                'id'         => 'purchase-price-at-'.$location_name,
               
                'blockName'  => 'woocommerce/product-pricing-field',
                'attributes' => [
                    'property' => 'meta_data.'.$location_purchase_price_meta_key,
                    'label'    => 'Cost Price',
                    'placeholder' => 'Enter Purchase Price For '.$location_name
                    
                ],
                
        
               
          ]  
        );  
    
    }

    $allow_backorder_column = $pricing_columns->add_block(
        [
            'id'         => 'wcmlim-backorder-metacolumn-'.$location_id,
            'blockName'  => 'core/column',
            
            'attributes' => [
                'templateLock' => 'all',
            ],
        ]
    );


    $allow_backorder_column->add_block(
        [
        'id'         => 'backorder-at-'.$location_name,
       
        'blockName'  => 'woocommerce/product-select-field',
        'attributes' => [
            'property' => 'meta_data.'.$location_allow_backorder,
            'label'    => 'Backorder',
            'tooltip'  => __(
						'This setting controls whether customers can place an order even if there is insufficient stock',
						'woocommerce'
					),
            'options' => [
                [
                    'label' => __( 'Select', 'woocommerce' ),
                    'value' => '',
                ],
                [
                    'label' => __( 'Allow', 'woocommerce' ),
                    'value' => 'Yes',
                ],
                [
                    'label' => __( 'Dont Allow', 'woocommerce' ),
                    'value' => 'No',
                ],
        ],
        

       
    ],
        ]  
); 


$allow_specific_location_column = $pricing_columns->add_block(
    [
        'id'         => 'wcmlim-specific-location-metacolumn-'.$location_id,
        'blockName'  => 'core/column',
        
        'attributes' => [
            'templateLock' => 'all',
        ],
    ]
);

$allow_specific_location_column->add_block(
    [
    'id'         => 'specific-location-at-'.$location_name,
   
    'blockName'  => 'woocommerce/product-select-field',
    'attributes' => [
        'property' => 'meta_data.'.$location_allow_specific_location,
        'label'    => 'Visibility',
        'tooltip'  => __(
						'This setting controls the visiblity of this location on frontend',
						'woocommerce'
					),
        'options' => [
                [
                    'label' => __( 'Select', 'woocommerce' ),
                    'value' => '',
                ],
                [
                    'label' => __( 'Yes', 'woocommerce' ),
                    'value' => 'Yes',
                ],
                [
                    'label' => __( 'No', 'woocommerce' ),
                    'value' => 'No',
                ],
        ],
    ],

   
]  
); 
    
    }

}
	add_action(
		'woocommerce_block_template_area_product-form_after_add_block_product-inventory-quantity',
		'wcmlim_add_block'
	);

    add_action(
		'woocommerce_block_template_area_product-form_after_add_block_product-variation-inventory-quantity',
		'wcmlim_add_block'
	);

   
}



add_action(
    'woocommerce_block_template_area_product-form_after_add_block_product-custom-fields-toggle',
    'wcmlim_add_location_category'
);


function wcmlim_add_location_category( BlockInterface $product_name_field ) {
    

    $parent = $product_name_field->get_parent();

    global $wpdb;
    
    $parent->add_block(
        array(
            'id'         => 'product-categories-location',
            'blockName'  => 'woocommerce/product-taxonomy-field',
            'order'      => 10,
            'attributes' => array(
                'slug'               => 'locations',
                'property'           => 'locations',
                'label'              => __( 'Location As Category', 'woocommerce' ),
                'createTitle'        => __( 'Create new category', 'woocommerce' ),
                'dialogNameHelpText' => __( 'Shown to customers on the product page.', 'woocommerce' ),
                'parentTaxonomyText' => __( 'Parent category', 'woocommerce' ),
                'placeholder'        => __( 'Search or create locations', 'woocommerce' ),
            ),
        )
    ); 


}



?>