<?php

function wcmlim_add_to_cart_and_quantity_visible() {
    // Check if we're on a product page (single product)
    if (is_product()) {
        ?>
        <script type="text/javascript">
            (function($){
                $(function(){
                    // 1) a one-time show
                    showAddToCartAndQuantity();

                    // 2) watch for any changes that might hide them later
                    var observer = new MutationObserver(showAddToCartAndQuantity);
                    observer.observe(document.body, {
                        childList: true,
                        subtree:   true,
                        attributes:true
                    });
                });

                // exposes the buttons and quantity selector, and strips any "hidden" classes/styles
                function showAddToCartAndQuantity(){
                    // Ensure the Add to Cart button is visible
                    $('.summary.entry-summary .single_add_to_cart_button, button.add_to_cart_button').each(function(){
                        $(this)
                            .show()
                            .css('visibility','visible')
                            .css('opacity','1')
                            // if your plugin adds specific classes, remove them here:
                            .removeClass('hidden hide invisible custom-hide-class');
                    });

                    // Ensure the Quantity Selector is visible
                    $('.summary.entry-summary .quantity, .quantity input, .quantity button').each(function(){
                        $(this)
                            .show()
                            .css('visibility','visible')
                            .css('opacity','1')
                            // Remove hidden or invisible classes
                            .removeClass('hidden hide invisible custom-hide-class');
                    });
                }
            })(jQuery);
        </script>
        <?php
    }
}
add_action('wp_footer', 'wcmlim_add_to_cart_and_quantity_visible', 100);



?>