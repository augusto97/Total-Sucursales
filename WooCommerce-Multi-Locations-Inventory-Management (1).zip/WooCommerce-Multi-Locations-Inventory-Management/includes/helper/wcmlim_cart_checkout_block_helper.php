<?php

add_action(
	'woocommerce_blocks_loaded',

    function(){

woocommerce_store_api_register_endpoint_data(
	[
		'endpoint' => \Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema::IDENTIFIER,
		'namespace'     => 'wcmlim_location',
		'data_callback' => function( $cart_item ) {
			return [
				'location_name' => isset($cart_item['select_location']['location_name']) ? $cart_item['select_location']['location_name'] : '',
			];
		},
	]
);
    }
);





add_action( 'wp_footer', 'wcmlim_block_extenstion' );


function wcmlim_block_extenstion(){
    
    
    
    ?>

    <script type="text/javascript">

document.addEventListener('DOMContentLoaded', function() {
const { registerCheckoutFilters } = window.wc.blocksCheckout;

// Adjust cart item price of the cart line items.
registerCheckoutFilters( 'wcmlim_block_extenstion', {
    subtotalPriceFormat: ( value, extensions, args ) => {
    // Return early since this filter is not being applied in the Cart context.
    // We must return the original value we received here.
	 
	
	 if (( args?.context !== 'cart' ) && ( args?.context !== 'summary' )) {
      return value;
    }

   

    var location = args?.cartItem?.extensions?.wcmlim_location?.location_name;
		
    return '<price/>'+
    ' | Location : '+location;
  }
} );
});
    </script>

    <?php 

}



?>