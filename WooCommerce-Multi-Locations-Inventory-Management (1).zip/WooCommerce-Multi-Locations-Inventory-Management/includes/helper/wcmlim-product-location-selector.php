<?php

add_action( 'load-post-new.php', 'wcmlim_select_all_locations_by_default' );

function wcmlim_select_all_locations_by_default() {
    global $typenow;

    if ( $typenow === 'product' ) {
        add_action( 'admin_footer', 'wcmlim_auto_select_all_locations' );
    }
}

function wcmlim_auto_select_all_locations() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Select all categories
            $('#locationschecklist input[type=checkbox]').prop('checked', true);
        });
    </script>
    <?php
}

?>