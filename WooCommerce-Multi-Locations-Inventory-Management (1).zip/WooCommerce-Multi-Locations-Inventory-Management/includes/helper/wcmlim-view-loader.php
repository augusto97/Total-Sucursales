<?php
/**
 * WCMLIM View Loader - Allows overriding views via hooks/filters.
 *
 * Usage: Instead of include $view_file, use:
 * wcmlim_load_view('wcmlim-list-view', compact('var1', 'var2', ...));
 *
 * Clients can override a view by adding a filter:
 *   add_filter('wcmlim_override_view_wcmlim-list-view', function($html, $vars) {
 *     // $vars contains all variables passed to the view
 *     return '<div>Custom HTML here</div>';
 *   }, 10, 2);
 */
if (!function_exists('wcmlim_load_view')) {
    function wcmlim_load_view($view_name, $vars = []) {
        // Allow clients to override the view output
        $override = apply_filters('wcmlim_override_view_' . $view_name, null, $vars);
        if ($override !== null) {
            echo $override;
            return;
        }
        // Default: include the view file
        $view_file = WCMLIM_DIR_PATH . 'public/controller/shop/views/' . $view_name . '.php';
        if (file_exists($view_file)) {
            extract($vars, EXTR_SKIP);
            include $view_file;
        } else {
            do_action('wcmlim_view_not_found', $view_name, $view_file);
        }
    }
}
