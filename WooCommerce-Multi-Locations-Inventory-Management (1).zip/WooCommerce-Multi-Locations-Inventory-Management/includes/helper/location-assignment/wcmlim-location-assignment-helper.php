<?php
// Function to set the location cookie

/**
 * Sets the user location cookie.
 *
 * @param mixed $location The location value to be set in the cookie.
 * @param int|null $expire The cookie expiration time in seconds. Defaults to 86400 (1 day) if empty.
 */
function setLocation($key, $location, $expire = null) {
    if (empty($expire)) {
        $expire = 86400;
    }
    setcookie($key, $location, time() + $expire, "/", "", false, true);
    $_COOKIE[$key] = $location;
}

// Function to get the location cookie

/**
 * Retrieves the user location cookie.
 *
 * @return mixed|null Returns the cookie value if set, otherwise null.
 */
function getLocation($key) {
    if (isset($_COOKIE[$key])) {
        // Verify if the cookie value is exactly '-1' (used to represent the default selected location).
        return ($_COOKIE[$key] === '-1') ? null : $_COOKIE[$key];
    }
    return null; // Return null if the cookie doesn't exist
}


// Function to unset the location cookie

/**
 * Unsets the user location cookie.
 */
function unsetLocation($key) {
    unset($_COOKIE[$key]);
}
?>