<?php
/**
 * Multi-Locations Cache Handler
 */
if (!defined('ABSPATH')) exit;

class WC_Multi_Locations_Cache {
    
    private $cache_group = 'wc_multi_locations';
    private $cache_time = 3600; // 1 hour
    
    /**
     * Get cached inventory data or fetch fresh
     */
    public function get_inventory_data($product_id) {
        $cache_key = "product_inventory_{$product_id}";
        $inventory = wp_cache_get($cache_key, $this->cache_group);
        
        if (false === $inventory) {
            global $wc_multi_locations_db;
            $inventory = $wc_multi_locations_db->get_location_inventory($product_id);
            wp_cache_set($cache_key, $inventory, $this->cache_group, $this->cache_time);
        }
        
        return $inventory;
    }
    
    /**
     * Clear cache for product
     */
    public function clear_product_cache($product_id) {
        $cache_key = "product_inventory_{$product_id}";
        wp_cache_delete($cache_key, $this->cache_group);
    }
}

// Initialize cache
global $wc_multi_locations_cache;
$wc_multi_locations_cache = new WC_Multi_Locations_Cache();
