<?php
/**
 * Location Archive Template
 *
 * Displays products available at a specific location
 *
 * @link       http://www.techspawn.com
 * @since      1.0.0
 *
 * @package    Wcmlim
 */

// Get location from query var
$location_slug = get_query_var('location_slug');
$location = get_term_by('slug', $location_slug, 'locations');

if (!$location || is_wp_error($location)) {
    wp_redirect(home_url('/shop/'));
    exit;
}

// Get location metadata
$location_address = get_term_meta($location->term_id, 'wcmlim_location_address1', true);
$location_city = get_term_meta($location->term_id, 'wcmlim_location_city', true);
$location_state = get_term_meta($location->term_id, 'wcmlim_location_state', true);
$location_zip = get_term_meta($location->term_id, 'wcmlim_location_zip', true);
$location_phone = get_term_meta($location->term_id, 'wcmlim_location_phone', true);
$location_email = get_term_meta($location->term_id, 'wcmlim_location_email', true);

get_header();
?>

<div id="primary" class="content-area wcmlim-location-archive">
    <main id="main" class="site-main">

        <!-- Location Header -->
        <header class="page-header wcmlim-location-header">
            <h1 class="page-title"><?php echo esc_html($location->name); ?></h1>
            
            <?php if ($location->description): ?>
                <div class="taxonomy-description">
                    <?php echo wpautop(wp_kses_post($location->description)); ?>
                </div>
            <?php endif; ?>

            <!-- Location Info -->
            <div class="wcmlim-location-info" style="background: #f9f9f9; padding: 20px; margin: 20px 0; border-left: 4px solid #2271b1;">
                <div class="location-details">
                    <?php if ($location_address || $location_city): ?>
                        <p class="location-address">
                            <strong>📍 Address:</strong>
                            <?php 
                            echo esc_html($location_address);
                            if ($location_city) echo ', ' . esc_html($location_city);
                            if ($location_state) echo ', ' . esc_html($location_state);
                            if ($location_zip) echo ' ' . esc_html($location_zip);
                            ?>
                        </p>
                    <?php endif; ?>

                    <?php if ($location_phone): ?>
                        <p class="location-phone">
                            <strong>📞 Phone:</strong> 
                            <a href="tel:<?php echo esc_attr($location_phone); ?>">
                                <?php echo esc_html($location_phone); ?>
                            </a>
                        </p>
                    <?php endif; ?>

                    <?php if ($location_email): ?>
                        <p class="location-email">
                            <strong>✉️ Email:</strong> 
                            <a href="mailto:<?php echo esc_attr($location_email); ?>">
                                <?php echo esc_html($location_email); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <!-- Products Grid -->
        <?php if (have_posts()): ?>
            
            <div class="woocommerce">
                <div class="wcmlim-products-notice" style="background: #e7f5fe; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
                    <p><strong>ℹ️ Showing products available at <?php echo esc_html($location->name); ?></strong></p>
                </div>

                <ul class="products columns-3">
                    <?php while (have_posts()): the_post(); ?>
                        <?php
                        global $product;
                        
                        // Get stock for this location
                        $stock_qty = get_post_meta(get_the_ID(), 'wcmlim_stock_at_' . $location->term_id, true);
                        ?>
                        
                        <li class="product">
                            <a href="<?php echo esc_url(add_query_arg('location', $location_slug, get_permalink())); ?>" class="woocommerce-LoopProduct-link">
                                
                                <?php if (has_post_thumbnail()): ?>
                                    <div class="product-image">
                                        <?php the_post_thumbnail('woocommerce_thumbnail'); ?>
                                    </div>
                                <?php endif; ?>

                                <h2 class="woocommerce-loop-product__title"><?php the_title(); ?></h2>

                                <div class="wcmlim-location-stock" style="color: <?php echo $stock_qty > 0 ? '#16a34a' : '#dc2626'; ?>; font-weight: 600; margin: 10px 0;">
                                    <?php if ($stock_qty > 0): ?>
                                        ✓ In Stock (<?php echo intval($stock_qty); ?> available)
                                    <?php else: ?>
                                        ✗ Out of Stock
                                    <?php endif; ?>
                                </div>

                                <span class="price"><?php echo $product->get_price_html(); ?></span>
                            </a>

                            <a href="<?php echo esc_url(add_query_arg('location', $location_slug, get_permalink())); ?>" 
                               class="button product_type_simple add_to_cart_button" 
                               style="margin-top: 10px;">
                                View Product
                            </a>
                        </li>

                    <?php endwhile; ?>
                </ul>

                <!-- Pagination -->
                <?php
                the_posts_pagination(array(
                    'mid_size' => 2,
                    'prev_text' => __('&laquo; Previous', 'wcmlim'),
                    'next_text' => __('Next &raquo;', 'wcmlim'),
                ));
                ?>

            </div>

        <?php else: ?>
            
            <div class="woocommerce">
                <div class="woocommerce-info" style="background: #fff3cd; padding: 20px; border-left: 4px solid #ffc107;">
                    <p><strong>No products currently available at <?php echo esc_html($location->name); ?></strong></p>
                    <p><a href="<?php echo esc_url(home_url('/shop/')); ?>" class="button">Browse All Products</a></p>
                </div>
            </div>

        <?php endif; ?>

    </main>
</div>

<?php get_footer(); ?>
