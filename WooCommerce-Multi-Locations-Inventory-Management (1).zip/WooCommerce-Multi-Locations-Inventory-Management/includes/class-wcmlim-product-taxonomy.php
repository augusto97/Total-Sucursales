<?php

/**
 *
 * @since      1.0.0
 * @package    Wcmlim
 * @subpackage Wcmlim/includes
 * @author     Techspawn Solutions <contact@techspawn.com>
 */

class Wcmlim_Product_Taxonomy
{

  /**
   * Construct.
   *
   * @since 1.1.0
   */
  public function __construct()
  {
    add_action('init', array($this, 'create_taxonomy'), 1);
    add_action('locations_add_form', array($this, 'hideFields'));
    add_action('locations_edit_form', array($this, 'hideFields'));
    add_filter('manage_edit-locations_columns', array($this, 'editColumns'));
    add_action('locations_edit_form', array($this, 'formFields'), 100, 2);
    add_action('locations_add_form_fields', array($this, 'formFields'), 10, 2);
    add_action('edited_locations', array($this, 'formSave'), 10, 2);
    add_action('created_locations', array($this, 'formSave'), 10, 2);
    add_action( "delete_locations", array($this, 'execute_on_delete_locations'), 10, 4);
    add_filter('locations_row_actions', array($this, 'disable_quick_edit'), 10, 2);
    add_filter('manage_edit-location_group_columns', array($this, 'editColumns_locgroup'));
    add_filter( 'location_group_row_actions', array($this, 'editColumnsactions'), 10, 2);
    
    // AJAX handlers for country/state dependency
    add_action('wp_ajax_wcmlim_get_states', array($this, 'ajax_get_states'));
    add_action('wp_ajax_nopriv_wcmlim_get_states', array($this, 'ajax_get_states'));
    
    /*** Location Group */
    $isLocationsGroup = get_option('wcmlim_enable_location_group');	
    if( $isLocationsGroup == "on"){
      add_action('location_group_edit_form', array($this, 'formFields_location_group'), 100, 2);
      add_action('location_group_add_form_fields', array($this, 'formFields_location_group'), 10, 2);
      add_action('edited_location_group', array($this, 'formSave_location_group'), 10, 2);
      add_action('created_location_group', array($this, 'formSave_location_group'), 10, 2);
    } 
  }

  /**
   * Creates the taxonomy.
   *
   * @since 1.0.0
   * @return void
   */
  public function create_taxonomy()
  {
    $labels = array(
      'name'                       => esc_html('Locations', 'wcmlim'),
      'singular_name'              => esc_html('Location', 'wcmlim'),
      'menu_name'                  => esc_html('Location', 'wcmlim'),
      'all_items'                  => esc_html('All Locations', 'wcmlim'),
      'parent_item'                => esc_html('Parent Item', 'wcmlim'),
      'parent_item_colon'          => esc_html('Parent Item:', 'wcmlim'),
      'new_item_name'              => esc_html('New Location Name', 'wcmlim'),
      'add_new_item'               => esc_html('Add New Location', 'wcmlim'),
      'edit_item'                  => esc_html('Edit Location', 'wcmlim'),
      'update_item'                => esc_html('Update Location', 'wcmlim'),
      'separate_items_with_commas' => esc_html('Separate Location with commas', 'wcmlim'),
      'search_items'               => esc_html('Search Locations', 'wcmlim'),
      'add_or_remove_items'        => esc_html('Add or remove Location', 'wcmlim'),
      'choose_from_most_used'      => esc_html('Choose from the most used Location', 'wcmlim'),
      'lat'                => esc_html('Lat', 'wcmlim'),
      'lng'                => esc_html('Lng', 'wcmlim'),

    );
    $capabilities = array(
      'manage_terms'               => 'manage_woocommerce',
      'edit_terms'                 => 'manage_woocommerce',
      'delete_terms'               => 'manage_woocommerce',
      'assign_terms'               => 'manage_woocommerce',
    );
    
   
      $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_in_rest'               => true,
        'show_in_quick_edit'         => false,
        'show_admin_column'          => true,
        'show_in_menu'               => true,
        'show_tagcloud'              => true,
        'capabilities'               => $capabilities,
      );
    
   




    register_taxonomy('locations', 'product', $args);

    register_term_meta('locations', 'wcmlim_street_address', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_city', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_postcode', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_country_state', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_email', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_phone', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_location_priority', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_start_time', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_end_time', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_street_number', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_route', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_locality', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_administrative_area_level_1', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_postal_code', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_country', ['show_in_rest' => true]);
    register_taxonomy_for_object_type('locations', 'product');
    register_term_meta('locations', 'wcmlim_lat', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_lng', ['show_in_rest' => true]);
    register_term_meta('locations', 'wcmlim_linked_users', ['show_in_rest' => true]);

    /**start Location Group */
    register_term_meta('locations', 'wcmlim_locator', ['show_in_rest' => true]); 
   
    register_taxonomy('location_group', 'product', array(	 
      'labels' => array(
      'name' => _x( 'Location Group', 'taxonomy general name' ),
      'singular_name' => _x( 'Location Group', 'taxonomy singular name' ),
      'search_items' =>  __( 'Search Location Groups' ),
      'all_items' => __( 'All Location Group' ),
      'parent_item' => __( 'Parent Location Group' ),
      'parent_item_colon' => __( 'Parent Location Group:' ),
      'edit_item' => __( 'Edit Location Group' ),
      'update_item' => __( 'Update Location Group' ),
      'add_new_item' => __( 'Add New Location Group' ),
      'new_item_name' => __( 'New Location Group Name' ),
      'menu_name' => __( 'Location Groups' ),
      ),     
      'meta_box_cb' => false,
    ));
    register_taxonomy_for_object_type('location_group', 'product');
    /** End Location Group */
  }

  /**
   * Hide unused fields from admin
   */
  public function hideFields()
  {
    echo '<style> #wpseo_meta { position: absolute; margin-top: 75%; } .term-description-wrap, td.description.column-description { display:none; } </style>';
  }

  /**
   * Change columns displayed in table
   *
   * @param $columns
   *
   * @return mixed
   */
  public function editColumns($columns)
  {
    if (isset($columns['description']))
    {
      unset($columns['description']);
      unset($columns['posts']);
        }
        return $columns;
    }
    /**
   * Remove view for location group
   *
   * @param $columns
   *
   * @return mixed
   */
  public function editColumnsactions ($actions,$tag)
  {    
    unset($actions['view']);
    return $actions;    
  }

  /**
   * Change columns displayed in table for location_group
   *
   * @param $columns
   *
   * @return mixed
   */
  public function editColumns_locgroup($columns)
  {
    
    if (isset($columns['count'])) {
      unset($columns['count']);
    }
    return $columns;
  }
  
  /**
   * Hide quick edit on locations taxonomy
   * 
   */
  
  public function disable_quick_edit($actions = array(), $post = null)
  {
    if ($post->taxonomy !== "locations") {
      return $actions;
    }
    
    if (isset($actions['inline hide-if-no-js'])) {
      unset($actions['inline hide-if-no-js']);
    }

    return $actions;
  }
    /**
   * Update stock on deleting locations
   * 
   */
  public function execute_on_delete_locations($term, $tt_id, $deleted_term, $object_ids){
    //You can write code here to be executed when this action occurs in WordPress. Use the parameters received in the function arguments & implement the required additional custom functionality according to your website requirements.
    $args = array(
      'post_type'  => 'product',
       'numberposts' => -1,
    );
      $product_info = get_posts($args);
      foreach ($product_info as $key => $value) {
      $total = 0;
          $product_id = $value->ID;
          $product = wc_get_product($product_id);
      $locations = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false));
          foreach ($locations as $location) {
            $total +=  intval(get_post_meta($product_id, "wcmlim_stock_at_{$location->term_id}", true));
          }
          if(intval($total) > 0)
          {
            update_post_meta($product_id, '_stock', $total);
          }        

      } 
 }
  /**
   * Form fields
   *
   * @param $tag
   */
  public function formFields_location_group($term)
  {
    if (is_object($term)) {
      $groupshopManager = get_term_meta($term->term_id, 'wcmlim_shop_regmanager', true);
      (isset($groupshopManager)) ? $groupshopManager : $groupshopManager = '';
      ob_start();
      include_once plugin_dir_path(dirname(__FILE__)) . 'includes/views/lgroup-taxonomy-fields-edit.php';
      $template = ob_get_contents();
      ob_end_clean();
      if (!empty($template)) {
        printf($template);
      }
    } else {
      ob_start();
      include_once plugin_dir_path(dirname(__FILE__)) . 'includes/views/lgroup-taxonomy-fields-new.php';
      $template = ob_get_contents();
      ob_end_clean();
      if (!empty($template)) {
        printf($template);
      }
    }
  }

  /**
   * Form fields
   *
   * @param $tag
   */
  public function formFields($term)
  {
    
      if (is_object($term)) {
          $street_address = get_term_meta($term->term_id, 'wcmlim_street_address', true) ?: '';
          $city = get_term_meta($term->term_id, 'wcmlim_city', true) ?: '';
          $postcode = get_term_meta($term->term_id, 'wcmlim_postcode', true) ?: '';
          $country_state = get_term_meta($term->term_id, 'wcmlim_country_state', true) ?: '';
          $wcmlim_shipping_zone = get_term_meta($term->term_id, 'wcmlim_shipping_zone', true);
          $wcmlim_tax_location = get_term_meta($term->term_id, 'wcmlim_tax_locations', true);
          $wcmlim_payment_methods = get_term_meta($term->term_id, 'wcmlim_payment_methods', true);
          $wcmlim_dimension_unit = get_term_meta($term->term_id, 'wcmlim_dimension_unit', true);
          $streetNumber = get_term_meta($term->term_id, 'wcmlim_street_number', true) ?: '';
          $route = get_term_meta($term->term_id, 'wcmlim_route', true) ?: '';
          $locality = get_term_meta($term->term_id, 'wcmlim_locality', true) ?: '';
          $state = get_term_meta($term->term_id, 'wcmlim_administrative_area_level_1', true) ?: '';
          $postal_code = get_term_meta($term->term_id, 'wcmlim_postal_code', true) ?: '';
          $country = get_term_meta($term->term_id, 'wcmlim_country', true) ?: '';
          $locator = get_term_meta($term->term_id, 'wcmlim_locator', true) ?: '';
          $email = get_term_meta($term->term_id, 'wcmlim_email', true) ?: '';
          $phone = get_term_meta($term->term_id, 'wcmlim_phone', true) ?: '';
          $locPriority = get_term_meta($term->term_id, 'wcmlim_location_priority', true) ?: '';
          $start_time = get_term_meta($term->term_id, 'wcmlim_start_time', true) ?: '';
          $end_time = get_term_meta($term->term_id, 'wcmlim_end_time', true) ?: '';
          $lshopManager = get_term_meta($term->term_id, 'wcmlim_shop_manager', true) ?: '';
          $wcmlim_shipping_method = get_term_meta($term->term_id, 'wcmlim_shipping_method', true) ?: '';
          $wcmlim_pos_compatiblity = get_term_meta($term->term_id, 'wcmlim_pos_compatiblity', true) ?: '';
          $wcpos_selected_outlet = get_term_meta($term->term_id, 'wcmlim_wcpos_compatiblity', true) ?: '';
          $allow_pickup = get_term_meta($term->term_id, 'wcmlim_allow_pickup', true) ?: 'no';
          $location_radius = get_term_meta($term->term_id, 'wcmlim_service_radius_for_location', true) ?: '';
          $location_fee = get_term_meta($term->term_id, 'wcmlim_location_fee', true) ?: '';
          $get_direction = get_term_meta($term->term_id, 'wcmlim_get_direction_for_location', true) ?: '';
          $wcmlim_lat = get_term_meta($term->term_id, 'wcmlim_lat', true) ?: '';
          $wcmlim_lng = get_term_meta($term->term_id, 'wcmlim_lng', true) ?: '';
          $wcmlim_stockupp_pos = get_term_meta($term->term_id, 'wcmlim_stockupp_pos', true) ?: '';
          $wcmlim_linked_users = get_term_meta($term->term_id, 'wcmlim_linked_users', true) ?: '';
          $wcmlim_taxLocations_name = get_term_meta($term->term_id, 'wcmlim_taxLocations_name', true) ?: '';
          $wcmlim_taxLocation_rate = get_term_meta($term->term_id, 'wcmlim_taxLocations_rate', true) ?: '';
  
          ob_start();
          include_once plugin_dir_path(dirname(__FILE__)) . 'includes/views/taxonomy-fields-edit.php';
          $template = ob_get_contents();
          ob_end_clean();
          if (!empty($template)) {
              echo $template;
          }
      } else {
          ob_start();
          include_once plugin_dir_path(dirname(__FILE__)) . 'includes/views/taxonomy-fields-new.php';
          $template = ob_get_contents();
          ob_end_clean();
          if (!empty($template)) {
              echo $template;
          }
      }
  }
  
    /**
   * Save term meta
   *
   * @param $term_id
   */
  public function formSave_location_group($term_id)
  { 
    if (isset($_POST['wcmlim_email_regmanager'])) {
      update_term_meta($term_id, 'wcmlim_email_regmanager', sanitize_text_field($_POST['wcmlim_email_regmanager']));
    }
    if ($_POST) {
      $groupshopManager = isset($_POST['wcmlim_shop_regmanager']) ? (array) $_POST['wcmlim_shop_regmanager'] : array();
      $groupshopManager = array_map('esc_attr', $groupshopManager);
      update_term_meta($term_id, 'wcmlim_shop_regmanager', $groupshopManager);
       
  
        if (isset($_POST['wcmlim_location'])) {
          
          $wcmlim_location = get_term_meta($term_id, 'wcmlim_location', true);
          $wcmlim_location = is_array($wcmlim_location) ? $wcmlim_location : array();

            if (!empty($_POST['wcmlim_location']) && is_array($_POST['wcmlim_location'])) {
            $term_id_to_remove = array_diff($wcmlim_location, $_POST['wcmlim_location']);
              if(!empty($term_id_to_remove)){
                foreach ($term_id_to_remove as $removable_term_id) {
                  $sanitized_removable_term_id = sanitize_text_field($removable_term_id);
                  update_term_meta($sanitized_removable_term_id, 'wcmlim_locator', '');
                }
              }
            }
            else {
              $term_id_to_remove = array(); // Set an empty array if $_POST['wcmlim_location'] is not an array or is empty
            }

            $locations = array_map('sanitize_text_field', $_POST['wcmlim_location']);
            update_term_meta($term_id, 'wcmlim_location', $locations);
        
            foreach ($locations as $location_id) {
                $sanitized_location_id = sanitize_text_field($location_id);
                update_term_meta($sanitized_location_id, 'wcmlim_locator', $term_id);
            }
        } else {
            if(empty($_POST['wcmlim_location'])) {
              update_term_meta($term_id, 'wcmlim_location', '');
            }
        }
    }

    $wcmlim_shop_regmanager = get_term_meta($term_id, 'wcmlim_shop_regmanager', true);
    if ($_POST) {
      $term_meta = [
        'wcmlim_shop_regmanager' => $wcmlim_shop_regmanager,
      ];
    } else {
      $wcmlim_shop_regmanager = get_term_meta($term_id, 'wcmlim_shop_regmanager', true);
      $term_meta = [
        'wcmlim_shop_regmanager' => $wcmlim_shop_regmanager,
      ];
    }
    if (isset($term_meta)) {
      // Save the option array.
      update_option("taxonomy_$term_id", $term_meta, false);
    
      
    }



  }

  /**
   * Save term meta
   *
   * @param $term_id
   */
  public function formSave($term_id)
  {
   
    $autofill = get_option('wcmlim_enable_autocomplete_address');
    if ($_POST) {
      $existing_linked_users = get_term_meta($term_id, 'wcmlim_linked_users', true);
  
      if (!is_array($existing_linked_users)) {
          $existing_linked_users = array();
      }
  
      $shippingZone = isset($_POST['wcmlim_shipping_zone']) ? (array) $_POST['wcmlim_shipping_zone'] : array();
      $shippingZone = array_map('esc_attr', $shippingZone);
  
      $shippingMethod = isset($_POST['wcmlim_shipping_method']) ? (array) $_POST['wcmlim_shipping_method'] : array();
      $shippingMethod = array_map('esc_attr', $shippingMethod);
  
      $paymentMethods = isset($_POST['wcmlim_payment_methods']) ? (array) $_POST['wcmlim_payment_methods'] : array();
      $paymentMethods = array_map('esc_attr', $paymentMethods);
      $wcmlim_dimension_unit = isset($_POST['wcmlim_dimension_unit']) ? $_POST['wcmlim_dimension_unit'] : '';
  
      $shopManager = isset($_POST['wcmlim_shop_manager']) ? (array) $_POST['wcmlim_shop_manager'] : array();
      $shopManager = array_map('esc_attr', $shopManager);
  
      update_term_meta($term_id, 'wcmlim_street_number', isset($_POST['wcmlim_street_number']) ? sanitize_text_field($_POST['wcmlim_street_number']) : '' );
      update_term_meta($term_id, 'wcmlim_location', isset($_POST['wcmlim_locator']) ? sanitize_text_field($_POST['wcmlim_locator']) : '' );
      update_term_meta($term_id, 'wcmlim_route', isset($_POST['wcmlim_route']) ? sanitize_text_field($_POST['wcmlim_route']) : '' );
      update_term_meta($term_id, 'wcmlim_locality', isset($_POST['wcmlim_locality']) ? sanitize_text_field($_POST['wcmlim_locality']) : '' );
      update_term_meta($term_id, 'wcmlim_administrative_area_level_1', isset($_POST['wcmlim_administrative_area_level_1']) ? sanitize_text_field($_POST['wcmlim_administrative_area_level_1']) : '' );
      update_term_meta($term_id, 'wcmlim_postal_code', isset($_POST['wcmlim_postal_code']) ? sanitize_text_field($_POST['wcmlim_postal_code']) : '' );
      update_term_meta($term_id, 'wcmlim_country', isset($_POST['wcmlim_country']) ? sanitize_text_field($_POST['wcmlim_country']) : '' );
      update_term_meta($term_id, 'wcmlim_email', isset($_POST['wcmlim_email']) ? sanitize_text_field($_POST['wcmlim_email']) : '' );
      update_term_meta($term_id, 'wcmlim_phone', isset($_POST['wcmlim_phone']) ? sanitize_text_field($_POST['wcmlim_phone']) : '' );
      update_term_meta($term_id, 'wcmlim_location_priority', isset($_POST['wcmlim_location_priority']) ? sanitize_text_field($_POST['wcmlim_location_priority']) : '');
      update_term_meta($term_id, 'wcmlim_start_time', isset($_POST['wcmlim_start_time']) ? sanitize_text_field($_POST['wcmlim_start_time']) : '' );
      update_term_meta($term_id, 'wcmlim_end_time', isset($_POST['wcmlim_end_time']) ? sanitize_text_field($_POST['wcmlim_end_time']) : '' );
      update_term_meta($term_id, 'wcmlim_shipping_zone', $shippingZone);
      update_term_meta($term_id, 'wcmlim_payment_methods', $paymentMethods);
      update_term_meta($term_id, 'wcmlim_shop_manager', $shopManager);
      update_term_meta($term_id, 'wcmlim_pos_compatiblity', isset($_POST['wcmlim_pos_compatiblity']) ? sanitize_text_field($_POST['wcmlim_pos_compatiblity']) : '');
      update_term_meta($term_id, 'wcmlim_wcpos_compatiblity', isset($_POST['wcmlim_wcpos_compatiblity']) ? sanitize_text_field($_POST['wcmlim_wcpos_compatiblity']) : '');
      update_term_meta($term_id, 'wcmlim_shipping_method', $shippingMethod);
      update_term_meta($term_id, 'wcmlim_allow_pickup', isset($_POST['wcmlim_allow_pickup']) ? sanitize_text_field($_POST['wcmlim_allow_pickup']) : '');
      update_term_meta($term_id, 'wcmlim_service_radius_for_location', isset($_POST['wcmlim_service_radius']) ? sanitize_text_field($_POST['wcmlim_service_radius']) : '');
      update_term_meta($term_id, 'wcmlim_location_fee', isset($_POST['wcmlim_location_fee']) ? sanitize_text_field($_POST['wcmlim_location_fee']) : '');
      update_term_meta($term_id, 'wcmlim_dimension_unit', $wcmlim_dimension_unit);
      update_term_meta($term_id, 'wcmlim_lat', isset($_POST['wcmlim_lat']) ? sanitize_text_field($_POST['wcmlim_lat']) : '' );
      update_term_meta($term_id, 'wcmlim_lng', isset($_POST['wcmlim_lng']) ? sanitize_text_field($_POST['wcmlim_lng']) : '' );
      update_term_meta($term_id, 'wcmlim_stockupp_pos', isset($_POST['wcmlim_stockupp_pos']) ? sanitize_text_field($_POST['wcmlim_stockupp_pos']) : '');
      update_term_meta($term_id, 'wcmlim_locator', isset($_POST['wcmlim_locator']) ? sanitize_text_field($_POST['wcmlim_locator']) : '' );
      update_term_meta($term_id, 'wcmlim_radius', isset($_POST['wcmlim_radius']) ? sanitize_text_field($_POST['wcmlim_radius']) : '' );
      update_term_meta($term_id, 'wcmlim_location_note', isset($_POST['wcmlim_location_note']) ? sanitize_text_field($_POST['wcmlim_location_note']) : '' );
      update_term_meta($term_id, 'wcmlim_location_hide', isset($_POST['wcmlim_location_hide']) ? sanitize_text_field($_POST['wcmlim_location_hide']) : '' );
      if (isset($_POST['wcmlim_ruleshidden']) && $_POST['wcmlim_ruleshidden'] !== '') {
        update_term_meta($term_id, 'wcmlim_saved_rules', isset($_POST['wcmlim_ruleshidden']) ? sanitize_text_field($_POST['wcmlim_ruleshidden']) : '' );
      }
      update_term_meta($term_id, 'wcmlim_enable_rules', isset($_POST['wcmlim_enable_rules']) ? sanitize_text_field($_POST['wcmlim_enable_rules']) : '' );


      

      update_term_meta(sanitize_text_field($_POST['wcmlim_locator']), 'wcmlim_location', $term_id);
      update_term_meta($term_id, 'wcmlim_taxLocations_name', isset($_POST['wcmlim_taxLocations_name']) ? sanitize_text_field($_POST['wcmlim_taxLocations_name']) : '');
      update_term_meta($term_id, 'wcmlim_taxLocations_rate', isset($_POST['wcmlim_taxLocations_rate']) ? sanitize_text_field($_POST['wcmlim_taxLocations_rate']) : '');
  
      $linked_users = isset($_POST['wcmlim_linked_users']) ? (array) $_POST['wcmlim_linked_users'] : array();
      $serialized_linked_users = serialize($linked_users);
      update_term_meta($term_id, 'wcmlim_linked_users', $serialized_linked_users);
  
      $removed_users = array_diff($existing_linked_users, $linked_users);
      foreach ($removed_users as $removed_user) {
          delete_user_meta($removed_user, 'wcmlim_user_specific_location');
      }
  
      foreach ($linked_users as $user) {
          $locations = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false));
          foreach ($locations as $key => $value) {
              if ($value->term_id == $term_id) {
                $loc_key = $key;
                update_user_meta($user, 'wcmlim_user_specific_location', $term_id);
              }
          }
      }
  
      
  }
  

    if ($_POST && isset($_POST['wcmlim_street_address']) && isset($_POST['wcmlim_city']) && isset($_POST['wcmlim_postcode']) && isset($_POST['wcmlim_country_state'])) {
      update_term_meta($term_id, 'wcmlim_street_address', sanitize_text_field($_POST['wcmlim_street_address']));
      update_term_meta($term_id, 'wcmlim_city', sanitize_text_field($_POST['wcmlim_city']));
      update_term_meta($term_id, 'wcmlim_postcode', intval($_POST['wcmlim_postcode']));
      update_term_meta($term_id, 'wcmlim_country_state', sanitize_text_field($_POST['wcmlim_country_state']));
      update_term_meta($term_id, 'wcmlim_email', sanitize_text_field($_POST['wcmlim_email']));
      update_term_meta($term_id, 'wcmlim_phone', sanitize_text_field($_POST['wcmlim_phone']));
      update_term_meta($term_id, 'wcmlim_location_priority', sanitize_text_field($_POST['wcmlim_location_priority']));
      update_term_meta($term_id, 'wcmlim_start_time', sanitize_text_field($_POST['wcmlim_start_time']));
      update_term_meta($term_id, 'wcmlim_end_time', sanitize_text_field($_POST['wcmlim_end_time']));
      update_term_meta($term_id, 'wcmlim_dimension_unit', sanitize_text_field($_POST['wcmlim_dimension_unit']));      
      $pwsz = isset($_POST['wcmlim_shipping_zone']) ? (array) $_POST['wcmlim_shipping_zone'] : array();
      $pwsz = array_map('esc_attr', $pwsz);
      update_term_meta($term_id, 'wcmlim_shipping_zone', $pwsz);

      $pwsm  = isset($_POST['wcmlim_shipping_method']) ? (array) $_POST['wcmlim_shipping_method'] : array();
      $pwsm = array_map('esc_attr', $pwsm);
      update_term_meta($term_id, 'wcmlim_shipping_method', $pwsm);

      $pwpm = isset($_POST['wcmlim_payment_methods']) ? (array) $_POST['wcmlim_payment_methods'] : array();
      $pwpm = array_map('esc_attr', $pwpm);
      update_term_meta($term_id, 'wcmlim_payment_methods', $pwpm);
      $psm = isset($_POST['wcmlim_payment_methods']) ? (array) $_POST['wcmlim_shop_manager'] : array();
      $psm = array_map('esc_attr', $psm);
      update_term_meta($term_id, 'wcmlim_shop_manager', $psm);
      update_term_meta($term_id, 'wcmlim_pos_compatiblity', $_POST['wcmlim_pos_compatiblity']);
      update_term_meta($term_id, 'wcmlim_wcpos_compatiblity', $_POST['wcmlim_wcpos_compatiblity']);
      update_term_meta($term_id, 'wcmlim_allow_pickup', sanitize_text_field($_POST['wcmlim_allow_pickup']));
      update_term_meta($term_id, 'wcmlim_service_radius_for_location', sanitize_text_field($_POST['wcmlim_service_radius']));      
      update_term_meta($term_id, 'wcmlim_location_fee', sanitize_text_field($_POST['wcmlim_location_fee']));      
      update_term_meta($term_id, 'wcmlim_lat', sanitize_text_field($_POST['wcmlim_lat']));
      update_term_meta($term_id, 'wcmlim_lng', sanitize_text_field($_POST['wcmlim_lng']));
      update_term_meta($term_id, 'wcmlim_stockupp_pos', sanitize_text_field($_POST['wcmlim_stockupp_pos']));
    
    }
    
    
    $wsz = isset($_POST['wcmlim_shipping_zone']) ? (array) $_POST['wcmlim_shipping_zone'] : array();
    $wsz = array_map('esc_attr', $wsz);
    $wsm = isset($_POST['wcmlim_shipping_method']) ? (array) $_POST['wcmlim_shipping_method'] : array();
    $wsm = array_map('esc_attr', $wsm);
    $wst = isset($_POST['wcmlim_tax_locations']) ? (array) $_POST['wcmlim_tax_locations'] : array();
    $wst = array_map('esc_attr', $wst);
    $wpm = isset($_POST['wcmlim_payment_methods']) ? (array) $_POST['wcmlim_payment_methods'] : array();
    $wpm = array_map('esc_attr', $wpm);

    update_term_meta($term_id, 'wcmlim_shipping_zone', $wsz);
    update_term_meta($term_id, 'wcmlim_tax_locations', $wst);
    update_term_meta($term_id, 'wcmlim_payment_methods', $wpm);
    update_term_meta($term_id, 'wcmlim_shipping_method', $wsm);

    $wcmlim_payment_methods[] = get_term_meta($term_id, 'wcmlim_payment_methods', true);
    $wcmlim_shipping_zone[] = get_term_meta($term_id, 'wcmlim_shipping_zone', true);
    $wcmlim_tax_locations[] = get_term_meta($term_id, 'wcmlim_tax_locations', true);
    $wcmlim_shop_manager = get_term_meta($term_id, 'wcmlim_shop_manager', true);
    $wcmlim_linked_users = get_term_meta($term_id, 'wcmlim_linked_users', true);
    $wcmlim_shipping_method[] = get_term_meta($term_id, 'wcmlim_shipping_method', true);

    // Save SEO meta fields
    if (isset($_POST['wcmlim_meta_title'])) {
      update_term_meta($term_id, 'wcmlim_meta_title', sanitize_text_field($_POST['wcmlim_meta_title']));
    }
    if (isset($_POST['wcmlim_meta_description'])) {
      update_term_meta($term_id, 'wcmlim_meta_description', sanitize_textarea_field($_POST['wcmlim_meta_description']));
    }
    if (isset($_POST['wcmlim_schema_type'])) {
      update_term_meta($term_id, 'wcmlim_schema_type', sanitize_text_field($_POST['wcmlim_schema_type']));
    }
    if (isset($_POST['wcmlim_schema_price_range'])) {
      update_term_meta($term_id, 'wcmlim_schema_price_range', sanitize_text_field($_POST['wcmlim_schema_price_range']));
    }
    if (isset($_POST['wcmlim_openstreetmap_id'])) {
      update_term_meta($term_id, 'wcmlim_openstreetmap_id', sanitize_text_field($_POST['wcmlim_openstreetmap_id']));
    }
    if (isset($_POST['wcmlim_canonical_url'])) {
      update_term_meta($term_id, 'wcmlim_canonical_url', esc_url_raw($_POST['wcmlim_canonical_url']));
    }


    if ($_POST) {

      $streetNumber = get_term_meta($term_id, 'wcmlim_street_number', true);
      $locator = get_term_meta($term_id, 'wcmlim_locator', true);
      $route = get_term_meta($term_id, 'wcmlim_route', true);
      $locality = get_term_meta($term_id, 'wcmlim_locality', true);
      $state = get_term_meta($term_id, 'wcmlim_administrative_area_level_1', true);
      $postal_code = get_term_meta($term_id, 'wcmlim_postal_code', true);
      $country = get_term_meta($term_id, 'wcmlim_country', true);
      $wcmlim_pos_compatiblity = get_term_meta($term_id, 'wcmlim_pos_compatiblity', true);
      $wcpos_selected_outlet = get_term_meta($term_id, 'wcmlim_wcpos_compatiblity', true);
      $allow_pickup = get_term_meta($term_id, 'wcmlim_allow_pickup', true);
      $service_radius = get_term_meta( $term_id, 'wcmlim_service_radius_for_location' , true );
      $location_fee = get_term_meta( $term_id, 'wcmlim_location_fee' , true );
      
      $wcmlim_dimension_unit = get_term_meta( $term_id, 'wcmlim_dimension_unit' , true );
      $wcmlim_tax_locations = get_term_meta( $term_id, 'wcmlim_tax_locations' , true );
      $wcmlim_lat = get_term_meta( $term_id, 'wcmlim_lat' , true );
      $wcmlim_lng = get_term_meta( $term_id, 'wcmlim_lng' , true );
      $wcmlim_stockupp_pos = get_term_meta( $term_id, 'wcmlim_stockupp_pos' , true );
      $wcmlim_radius = get_term_meta($term_id, 'wcmlim_radius', true);
      $wcmlim_location_note = get_term_meta($term_id, 'wcmlim_location_note', true);
      $wcmlim_location_hide = get_term_meta($term_id, 'wcmlim_location_hide', true);
      $wcmlim_saved_rules = get_term_meta($term_id, 'wcmlim_saved_rules', true);
      $wcmlim_enable_rules = get_term_meta($term_id, 'wcmlim_enable_rules', true);




      $term_meta = [
        'wcmlim_street_number' => $streetNumber,
        'wcmlim_locator' => $locator,
        'wcmlim_route' => $route,
        'wcmlim_locality' => $locality,
        'wcmlim_administrative_area_level_1' => $state,
        'wcmlim_postal_code' => $postal_code,
        'wcmlim_shipping_zone' => $wcmlim_shipping_zone,
        'wcmlim_tax_locations' => $wcmlim_tax_locations,
        'wcmlim_payment_methods' => $wcmlim_payment_methods,
        'wcmlim_dimension_unit' => $wcmlim_dimension_unit,
        'wcmlim_country' => $country,
        'wcmlim_shop_manager' => $wcmlim_shop_manager,
        'wcmlim_pos_compatiblity' => $wcmlim_pos_compatiblity,
        'wcmlim_wcpos_compatiblity' => $wcpos_selected_outlet,
        'wcmlim_shipping_method' => $wcmlim_shipping_method,
        'wcmlim_stockupp_pos' => $wcmlim_stockupp_pos,
        'wcmlim_allow_pickup' => $allow_pickup,
        'wcmlim_service_radius' => $service_radius,
        'wcmlim_location_fee' => $location_fee,
        'wcmlim_lat' => $wcmlim_lat,
        'wcmlim_lng' => $wcmlim_lng,
        'wcmlim_linked_users'=> $wcmlim_linked_users,
        'wcmlim_radius' => $wcmlim_radius,
        'wcmlim_location_note' => $wcmlim_location_note,
        'wcmlim_location_hide' => $wcmlim_location_hide,
        'wcmlim_saved_rules' => $wcmlim_saved_rules,
        'wcmlim_enable_rules' => $wcmlim_enable_rules


      ];
    } else {
      $street_address = get_term_meta($term_id, 'wcmlim_street_address', true);
      $locator = get_term_meta($term_id, 'wcmlim_locator', true);
      $city = get_term_meta($term_id, 'wcmlim_city', true);
      $postcode = get_term_meta($term_id, 'wcmlim_postcode', true);
      $country_state = get_term_meta($term_id, 'wcmlim_country_state', true);
      $wcmlim_email = get_term_meta($term_id, 'wcmlim_email', true);
      $wcmlim_phone = get_term_meta($term_id, 'wcmlim_phone', true);
      $wcmlim_location_priority = get_term_meta($term_id, 'wcmlim_location_priority', true);
      $wcmlim_start_time = get_term_meta($term_id, 'wcmlim_start_time', true);
      $wcmlim_end_time = get_term_meta($term_id, 'wcmlim_end_time', true);
      $wcmlim_dimension_unit = get_term_meta($term_id, 'wcmlim_dimension_unit', true);
      $wcmlim_shipping_zone = array();
      $wcmlim_shipping_zone[] = get_term_meta($term_id, 'wcmlim_shipping_zone', true);
      $wcmlim_shipping_method = array();
      $wcmlim_shipping_method[] = get_term_meta($term_id, 'wcmlim_shipping_method', true);
      $wcmlim_tax_locations = array();
      $wcmlim_tax_locations[] = get_term_meta($term_id, 'wcmlim_tax_locations', true);
      $wcmlim_shop_manager = get_term_meta($term_id, 'wcmlim_shop_manager', true);
      $wcmlim_linked_users = get_term_meta($term_id, 'wcmlim_linked_users', true);
      $wcmlim_payment_methods = array();
      $wcmlim_payment_methods[] =  get_term_meta($term_id, 'wcmlim_payment_methods', true);
      $wcmlim_pos_compatiblity = get_term_meta($term_id, 'wcmlim_pos_compatiblity', true);
      $wcpos_selected_outlet = get_term_meta($term_id, 'wcmlim_wcpos_compatiblity', true);
      $wcmlim_lat = get_term_meta( $term_id, 'wcmlim_lat' , true );
      $wcmlim_lng = get_term_meta( $term_id, 'wcmlim_lng' , true );
      $wcmlim_stockupp_pos = get_term_meta( $term_id, 'wcmlim_stockupp_pos' , true );
      $wcmlim_radius = get_term_meta($term_id, 'wcmlim_radius', true);
      $wcmlim_location_note = get_term_meta($term_id, 'wcmlim_location_note', true);
      $wcmlim_location_hide = get_term_meta($term_id, 'wcmlim_location_hide', true);
      $wcmlim_saved_rules = get_term_meta($term_id, 'wcmlim_saved_rules', true);
      $wcmlim_enable_rules = get_term_meta($term_id, 'wcmlim_enable_rules', true);




      $allow_pickup = get_term_meta($term_id, 'wcmlim_allow_pickup', true);
      $service_radius = get_term_meta($term_id, 'wcmlim_service_radius_for_location', true);
      $term_meta = [
        'wcmlim_street_address' => $street_address,
        'wcmlim_locator' => $locator,
        'wcmlim_city' => $city,
        'wcmlim_postcode' => $postcode,
        'wcmlim_country_state' => $country_state,
        'wcmlim_shipping_zone' => $wcmlim_shipping_zone,
        'wcmlim_tax_locations' => $wcmlim_tax_locations,
        'wcmlim_payment_methods' => $wcmlim_payment_methods,
        'wcmlim_dimension_unit' => $wcmlim_dimension_unit,
        'wcmlim_email' => $wcmlim_email,
        'wcmlim_phone' => $wcmlim_phone,
        'wcmlim_location_priority' => $wcmlim_location_priority,
        'wcmlim_start_time' => $wcmlim_start_time,
        'wcmlim_end_time' => $wcmlim_end_time,
        'wcmlim_shop_manager' => $wcmlim_shop_manager,
        'wcmlim_pos_compatiblity' => $wcmlim_pos_compatiblity,
        'wcmlim_wcpos_compatiblity' => $wcpos_selected_outlet,
        'wcmlim_shipping_method' => $wcmlim_shipping_method,
        'wcmlim_stockupp_pos' => $wcmlim_stockupp_pos,
        'wcmlim_allow_pickup' => $allow_pickup,
        'wcmlim_lat' => $wcmlim_lat,
        'wcmlim_lng' => $wcmlim_lng,
        'wcmlim_service_radius' => $service_radius,
        'wcmlim_location_fee' => $wcmlim_location_fee,
        'wcmlim_linked_users' => $wcmlim_linked_users,
        'wcmlim_radius' => $wcmlim_radius,
        'wcmlim_location_note' => $wcmlim_location_note,
        'wcmlim_location_hide' => $wcmlim_location_hide,
        'wcmlim_saved_rules' => $wcmlim_saved_rules,
        'wcmlim_enable_rules' => $wcmlim_enable_rules


      ];
    }
    if (isset($term_meta)) {
      update_option("taxonomy_$term_id", $term_meta, false);
      

    }
  }

  /**
   * AJAX handler to get states by country
   */
  public function ajax_get_states() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'wcmlim_get_states_nonce')) {
      wp_die('Security check failed');
    }

    $country_code = sanitize_text_field($_POST['country']);
    
    if (empty($country_code)) {
      wp_send_json_error('Invalid country code');
    }

    // Get states using WooCommerce
    $countries_obj = WC()->countries;
    $states = $countries_obj->get_states($country_code);

    if (is_array($states) && !empty($states)) {
      wp_send_json_success($states);
    } else {
      wp_send_json_success(array()); // Return empty array if no states
    }
  }

}
