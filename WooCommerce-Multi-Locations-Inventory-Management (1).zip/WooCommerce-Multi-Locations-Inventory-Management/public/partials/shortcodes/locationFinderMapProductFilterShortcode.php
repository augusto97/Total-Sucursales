<?php
/**
 * Location Finder Map with Product Filter
 * Shows location sidebar with product search functionality
 * When a product is selected, shows locations with stock, price, and address details
 *
 * @link       http://www.techspawn.com
 * @since      3.0.0
 *
 * @package    Wcmlim
 * @subpackage Wcmlim/public/partials/shortcodes
 */

$default_map_color = get_option('wcmlim_default_map_color');
if (isset($default_map_color) && !empty($default_map_color)) {
	$default_map_color = $default_map_color;
} else {
	$default_map_color = '#187dc7';
}

$api_key = get_option('wcmlim_google_api_key');
$default_list_align = get_option('wcmlim_default_list_align');
$default_origin_center = get_option('wcmlim_default_origin_center');
$default_origin_center_modify = str_replace(' ', '+', $default_origin_center);

// Get origin coordinates
$curl = curl_init();
curl_setopt_array($curl, array(
	CURLOPT_URL => 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($default_origin_center_modify) . '&sensor=false&key=' . $api_key,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 0,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
));
$geocode = curl_exec($curl);
$output = json_decode($geocode);
curl_close($curl);

if (isset($output->results[0]->geometry->location->lat)) {
	$originlatitude = $output->results[0]->geometry->location->lat;
	$originlongitude = $output->results[0]->geometry->location->lng;
} else {
	$originlatitude = 0;
	$originlongitude = 0;
}

// Get all locations
$terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));

// Build store_on_map_arr for map markers
$store_on_map_arr = [];
$mapid = 1;

// Add origin point
$origin_store_on_map_str = array(
	"<div class='locator-store-block'><h4>" . $default_origin_center . "</h4></div>",
	floatval($originlatitude),
	floatval($originlongitude),
	intval($mapid),
	'origin'
);
array_push($store_on_map_arr, $origin_store_on_map_str);
$mapid = 2;

// Add each location
foreach ($terms as $k => $term) {
	$slug = $term->slug;
	$term_meta = get_option("taxonomy_$term->term_id");
	$term_meta = array_map(function ($term_val) {
		if (!is_array($term_val)) {
			return $term_val;
		}
	}, $term_meta);
	
	// Get cached coordinates
	$wcmlim_lat = get_term_meta($term->term_id, 'wcmlim_lat', true);
	$wcmlim_lng = get_term_meta($term->term_id, 'wcmlim_lng', true);
	
	if (!empty($wcmlim_lat) && !empty($wcmlim_lng)) {
		$latitude = floatval($wcmlim_lat);
		$longitude = floatval($wcmlim_lng);
	} else {
		$latitude = 0;
		$longitude = 0;
	}
	
	$__street_number = isset($term_meta['wcmlim_street_number']) ? $term_meta['wcmlim_street_number'] : "";
	$__route = isset($term_meta['wcmlim_route']) ? $term_meta['wcmlim_route'] : "";
	$__locality = isset($term_meta['wcmlim_locality']) ? $term_meta['wcmlim_locality'] : "";
	$__admin_level1 = isset($term_meta['wcmlim_administrative_area_level_1']) ? $term_meta['wcmlim_administrative_area_level_1'] : "";
	$__country = isset($term_meta['wcmlim_country']) ? $term_meta['wcmlim_country'] : "";
	$__postal_code = isset($term_meta['wcmlim_postal_code']) ? $term_meta['wcmlim_postal_code'] : "";
	$get_address = $__street_number . ' ' . $__route . ' ' . $__locality . ' ' . $__admin_level1 . ',' . $__country . ' - ' . $__postal_code;
	$wcmlim_email = get_term_meta($term->term_id, 'wcmlim_email', true);
	
	$store_info = "<div class='locator-store-block'>";
	$store_info .= "<h4>" . $term->name . "</h4>";
	$store_info .= "<p><span class='far fa-building'></span> " . $get_address . "</p>";
	if (!empty($wcmlim_email)) {
		$store_info .= "<p><span class='far fa-envelope-open'></span> " . $wcmlim_email . "</p>";
	}
	$store_info .= "</div>";
	
	$store_on_map_str = array(
		$store_info,
		floatval($latitude),
		floatval($longitude),
		intval($mapid),
		intval($term->term_id)
	);
	array_push($store_on_map_arr, $store_on_map_str);
	$mapid++;
}

// Store the map data
update_option("store_on_map_arr", json_encode($store_on_map_arr));
?>

<style>
	.marker-btn-1 {
		background: <?php echo $default_map_color; ?>!important;
	}

	.marker-btn-2 {
		background: <?php echo $default_map_color; ?>!important;
	}

	.locator-store-block h4 {
		background: <?php echo $default_map_color; ?>!important;
	}

	.wcmlim-map-sidebar-list button {
		background: <?php echo $default_map_color; ?>!important;
	}

	.wcmlim-top-map-widgets {
		background: <?php echo $default_map_color; ?>!important;
	}

	.wcmlim-map-sidebar-list h4 {
		color: <?php echo $default_map_color; ?>!important;
	}
	
	/* Product Search Styles - Integrated in Top Widget */
	.wcmlim-product-search-container {
		margin-bottom: 15px;
	}
	
	.wcmlim-top-map-widgets .wcmlim-product-search-container label {
		color: #f9f9f9;
		font-size: 16px;
		display: block;
		margin-bottom: 10px;
	}
	
	.wcmlim-product-search-wrapper {
		position: relative;
	}
	
	#wcmlim-product-search-input {
		width: 100%;
		padding: 12px 40px 12px 15px;
		border: 2px solid #ddd;
		border-radius: 6px;
		font-size: 14px;
		box-sizing: border-box;
		transition: border-color 0.3s;
	}
	
	#wcmlim-product-search-input:focus {
		outline: none;
		border-color: <?php echo $default_map_color; ?>;
	}
	
	#wcmlim-product-search-input.has-selection {
		background-color: #f0f8ff;
		border-color: <?php echo $default_map_color; ?>;
		font-weight: 600;
	}
	
	.wcmlim-search-clear {
		position: absolute;
		right: 12px;
		top: 50%;
		transform: translateY(-50%);
		background: none;
		border: none;
		color: #999;
		cursor: pointer;
		font-size: 18px;
		padding: 5px;
		display: none;
	}
	
	.wcmlim-search-clear.visible {
		display: block;
	}
	
	.wcmlim-search-clear:hover {
		color: #333;
	}
	
	.wcmlim-product-suggestions {
		position: absolute;
		top: 100%;
		left: 0;
		right: 0;
		background: white;
		border: 2px solid #ddd;
		border-top: none;
		border-radius: 0 0 6px 6px;
		max-height: 300px;
		overflow-y: auto;
		display: none;
		z-index: 1000;
		box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
	}
	
	.wcmlim-product-suggestions.visible {
		display: block;
	}
	
	.wcmlim-suggestion-item {
		padding: 12px 15px;
		cursor: pointer;
		border-bottom: 1px solid #f0f0f0;
		display: flex;
		align-items: center;
		gap: 12px;
		transition: background-color 0.2s;
	}
	
	.wcmlim-suggestion-item:last-child {
		border-bottom: none;
	}
	
	.wcmlim-suggestion-item:hover {
		background-color: #f8f8f8;
	}
	
	.wcmlim-suggestion-item img {
		width: 40px;
		height: 40px;
		object-fit: cover;
		border-radius: 4px;
	}
	
	.wcmlim-suggestion-info {
		flex: 1;
	}
	
	.wcmlim-suggestion-info h5 {
		margin: 0 0 4px 0;
		font-size: 14px;
		color: #333;
	}
	
	.wcmlim-suggestion-info .price {
		font-size: 13px;
		color: #666;
		font-weight: 600;
	}
	
	.wcmlim-no-suggestions {
		padding: 15px;
		text-align: center;
		color: #999;
		font-size: 14px;
	}
	
	/* Stock and Price Display */
	.wcmlim-location-stock {
		margin: 8px 0;
		padding: 8px 12px;
		background: #f8f9fa;
		border-radius: 4px;
		font-size: 13px;
	}
	
	.wcmlim-stock-info {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 4px;
	}
	
	.wcmlim-stock-info .label {
		color: #666;
		font-weight: 600;
	}
	
	.wcmlim-stock-info .value {
		font-weight: 700;
	}
	
	.wcmlim-stock-info .value.in-stock {
		color: #28a745;
	}
	
	.wcmlim-stock-info .value.out-of-stock {
		color: #dc3545;
	}
	
	.wcmlim-price-info {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	
	.wcmlim-price-info .label {
		color: #666;
		font-weight: 600;
	}
	
	.wcmlim-price-info .value {
		color: <?php echo $default_map_color; ?>;
		font-weight: 700;
		font-size: 14px;
	}
	
	/* Enhanced Marker Info Window Styles */
	.wcmlim-marker-info {
		max-width: 320px;
		padding: 15px;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
	}

	.wcmlim-marker-info h4 {
		margin: 0 0 12px 0;
		font-size: 18px;
		color: #2c3e50;
		border-bottom: 3px solid <?php echo $default_map_color; ?>;
		padding-bottom: 8px;
		font-weight: 700;
	}

	.wcmlim-marker-details p {
		margin: 0 0 10px 0;
		font-size: 14px;
		color: #555;
		line-height: 1.6;
	}

	.wcmlim-marker-details p:last-child {
		margin-bottom: 0;
	}

	.wcmlim-marker-info .wcmlim-stock-info .in-stock {
		color: #11998e;
		font-weight: 700;
	}

	.wcmlim-marker-info .wcmlim-stock-info .out-of-stock {
		color: #eb3349;
		font-weight: 700;
	}

	.wcmlim-marker-info .wcmlim-price-info {
		font-weight: 700;
		font-size: 16px;
		color: <?php echo $default_map_color; ?>;
	}

	.wcmlim-marker-info .wcmlim-address-info i,
	.wcmlim-marker-info .wcmlim-email-info i {
		margin-right: 8px;
		color: <?php echo $default_map_color; ?>;
	}

	.wcmlim-marker-actions {
		display: flex;
		gap: 10px;
		margin-top: 12px;
		padding-top: 10px;
		border-top: 1px solid #e0e0e0;
	}

	.wcmlim-marker-actions a {
		flex: 1;
		padding: 8px 12px;
		background: linear-gradient(135deg, <?php echo $default_map_color; ?> 0%, <?php echo $default_map_color; ?>dd 100%);
		color: white !important;
		text-decoration: none;
		text-align: center;
		border-radius: 6px;
		font-size: 13px;
		font-weight: 600;
		transition: all 0.3s ease;
		display: inline-block;
	}

	.wcmlim-marker-actions a:hover {
		transform: translateY(-2px);
		box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
		background: <?php echo $default_map_color; ?>;
	}
	
	/* No Locations Message */
	.wcmlim-no-locations-message {
		animation: fadeIn 0.5s ease-in;
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(-10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}
</style>

<div class="wcmlim_shortcode_block">
	<div class="wcmlim-map-widgets map-view-locations">
		<!-- Product Search at Top -->
		<div class="wcmlim-top-map-widgets">
			<div class="wcmlim-product-search-container">
				<div class="wcmlim-product-search-wrapper">
					<label><?php _e('Search Products', 'wcmlim'); ?></label>
					<input type="text" 
						   id="wcmlim-product-search-input" 
						   placeholder="<?php _e('Start typing to search products...', 'wcmlim'); ?>" 
						   autocomplete="off">
					<button class="wcmlim-search-clear" id="wcmlim-search-clear">×</button>
					<div class="wcmlim-product-suggestions" id="wcmlim-product-suggestions"></div>
				</div>
			</div>
		</div>
		
		<!-- Map Section (66.5% width) -->
		<div class="block-1"<?php
							if (isset($default_list_align) && !empty($default_list_align)) {
								if ($default_list_align == 'left') {
									echo " style='float: right;'";
								}
							}
							?>>
			<div id="map" style="width: 100%; height: 452px;"></div>
		</div>
		
		<!-- Locations Sidebar (29.9% width) -->
		<div class="wcmlim-map-sidebar-widgets block-2">
			<div class="filter-form">
				<div class="form-control" id="wcmlim-locations-container">
				<?php
				foreach ($terms as $k => $term) {
					$term_meta = get_option("taxonomy_$term->term_id");
					$term_meta = array_map(function ($term) {
						if (!is_array($term)) {
							return $term;
						}
					}, $term_meta);
					$slug = $term->slug;
					$__street_number = isset($term_meta['wcmlim_street_number']) ? $term_meta['wcmlim_street_number'] : "";
					$__route = isset($term_meta['wcmlim_route']) ? $term_meta['wcmlim_route'] : "";
					$__locality = isset($term_meta['wcmlim_locality']) ? $term_meta['wcmlim_locality'] : "";
					$__admin_level1 = isset($term_meta['wcmlim_administrative_area_level_1']) ? $term_meta['wcmlim_administrative_area_level_1'] : "";
					$__country = isset($term_meta['wcmlim_country']) ? $term_meta['wcmlim_country'] : "";
					$__postal_code = isset($term_meta['wcmlim_postal_code']) ? $term_meta['wcmlim_postal_code'] : "";

					$get_address = $__street_number . ' ' . $__route . ' ' . $__locality . ' ' . $__admin_level1 . ',' . $__country . ' - ' . $__postal_code;
					$get_address_dir = str_replace(' ', '+', $get_address);
					$wcmlim_email = get_term_meta($term->term_id, 'wcmlim_email', true);

				?>
					<div class="wcmlim-map-sidebar-list" id="<?php echo $term->term_id; ?>" data-location-id="<?php echo $term->term_id; ?>">
						<h4>
							<?php echo $term->name; ?>
						</h4>
						<p class="location-address">
							<span class='far fa-building'></span>
							<span>
								<?php echo $get_address; ?>
							</span>
							<br />
							<?php
							if (isset($wcmlim_email) && !empty($wcmlim_email)) {
							?>
								<span class='far fa-envelope-open'></span>
								<span>
									<?php echo $wcmlim_email; ?>
								</span>
							<?php
							}
							?>
						</p>
						<div class="wcmlim-location-stock" style="display:none;"></div>
						<button class="btn btn-primary" onclick="window.open('https://www.google.com/maps/dir//<?php echo $get_address_dir; ?>', '_blank');">
							<?php echo _e('Direction', 'wcmlim'); ?></button>
						<button class="btn btn-primary wcmlim-shop-now-btn" style="display:none;">
							<?php echo _e('Shop Now', 'wcmlim'); ?></button>
					</div>
				<?php
				}
				?>
			</div>
		</div>
	</div>
	</div>
</div>

<input type="hidden" id="wcmlim-origin-lat" value="<?php echo $originlatitude; ?>">
<input type="hidden" id="wcmlim-origin-lng" value="<?php echo $originlongitude; ?>">
<input type="hidden" id="wcmlim-google-api-key" value="<?php echo $api_key; ?>">
<input type="hidden" id="wcmlim-ajax-url" value="<?php echo admin_url('admin-ajax.php'); ?>">
<input type="hidden" id="wcmlim-ajax-nonce" value="<?php echo wp_create_nonce('wcmlim_product_filter_nonce'); ?>">
<input type="hidden" id="wcmlim-selected-product-id" value="">

<?php
$isEditor = wp_get_referer();
if (strpos($isEditor, 'action=edit') || strpos($isEditor, 'post-new.php')) {
	return ob_get_clean();
} else {
	return;
}
?>
