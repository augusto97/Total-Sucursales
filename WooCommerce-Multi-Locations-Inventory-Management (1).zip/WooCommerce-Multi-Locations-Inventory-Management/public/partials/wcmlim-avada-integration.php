<?php
/**
 * Integration functions for Avada theme compatibility
 *
 * @link       http://www.techspawn.com
 * @since      3.1.3
 * @package    Wcmlim
 * @subpackage Wcmlim/public/partials
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Add shortcode to Avada header
 * Use this function in your Avada child theme's functions.php file
 */
function wcmlim_add_shortcode_to_avada_header() {
    // Check if Avada theme is active
    if (defined('AVADA_VERSION')) {
        // Register a new menu item for the location switcher
        add_action('avada_add_fusion_element', 'wcmlim_register_avada_menu_element', 20);
    }
}
add_action('wp', 'wcmlim_add_shortcode_to_avada_header');

/**
 * Register a custom menu element for Avada
 */
function wcmlim_register_avada_menu_element() {
    if (function_exists('fusion_menu_element_add_custom_item')) {
        fusion_menu_element_add_custom_item(
            array(
                'name' => __('WooCommerce Location Switcher', 'wcmlim'),
                'content_override' => do_shortcode('[wcmlim_avada_location_switch]'),
                'menu_item_id' => 'wcmlim-location-switcher',
                'order' => 0,
            )
        );
    }
}

/**
 * Add Avada-specific styling
 */
function wcmlim_avada_enqueue_styles() {
    if (defined('AVADA_VERSION')) {
        $inline_css = "
        .wcmlim-avada-location-switcher {
            display: inline-block;
        }
        .fusion-main-menu .wcmlim-avada-location-switcher {
            float: none;
            padding-left: 20px;
        }
        .fusion-header-v4 .wcmlim-avada-location-switcher {
            margin-top: 10px;
        }
        ";
        wp_add_inline_style('avada-stylesheet', $inline_css);
    }
}
add_action('wp_enqueue_scripts', 'wcmlim_avada_enqueue_styles', 100);
