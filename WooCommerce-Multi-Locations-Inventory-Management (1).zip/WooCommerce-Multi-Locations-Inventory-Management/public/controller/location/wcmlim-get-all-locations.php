<?php
$isLocEx = get_option("wcmlim_exclude_locations_from_frontend");
$excludeArray = !empty($isLocEx) ? $isLocEx : [];

// Get all locations first
$terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));

$result = [];
$i = 0;

foreach ($terms as $index => $term) {
    // Skip if term is in exclude list
    if (in_array($term->term_id, $excludeArray)) {
        continue;
    }
    
    $term_meta = get_option("taxonomy_$term->term_id");
    $term_locator = get_term_meta($term->term_id, 'wcmlim_locator', true);
    
    // Ensure $term_meta is an array before using array_map
    if (!is_array($term_meta)) {
        $term_meta = [];
    }
    
    $term_meta = array_map(function ($term) {
        if (!is_array($term)) {
            return $term;
        }
    }, $term_meta);
    
    $result[$i]['location_address'] = implode(" ", array_filter($term_meta));
    $result[$i]['location_name'] = $term->name;
    $result[$i]['location_slug'] = $term->slug;
    $result[$i]['location_storeid'] = $term_locator;
    $result[$i]['location_termid'] = $term->term_id;
    $result[$i]['location_index'] = $index; // Added location_index
    $i++;
}

return $result;
wp_die();