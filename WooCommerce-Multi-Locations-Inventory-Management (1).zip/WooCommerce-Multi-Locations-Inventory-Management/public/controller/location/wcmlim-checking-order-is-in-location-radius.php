<?php
global $woocommerce;
$rates_arr = array();
$google_api_key = get_option('wcmlim_google_api_key');
$destination = '';

$country = $package['destination']['country'];
$state = $package['destination']['state'];
$postcode = $package['destination']['postcode'];
$city = $package['destination']['city'];

$destination = $country . "+" . $state . "+" . $postcode . "+" . $city;

$cart = $woocommerce->cart->cart_contents;
if (!empty($cart)) {
    // Get all terms once
    $terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false));
    
    // Create a mapping of location names to term data
    $location_map = array();
    foreach ($terms as $term) {
        $location_map[$term->name] = $term;
    }
    
    $outside_service_area = false;
    
    foreach ($cart as $array_item) {
        if (isset($array_item['select_location']['location_name'])) {
            $location_name = $array_item['select_location']['location_name'];
            
            if (isset($location_map[$location_name])) {
                $term = $location_map[$location_name];
                $_locRadius = get_term_meta($term->term_id, 'wcmlim_service_radius_for_location', true);
                $term_meta = get_option("taxonomy_$term->term_id");
                
                $term_meta = array_map(function ($term) {
                    if (!is_array($term)) {
                        return $term;
                    }
                }, $term_meta);
                
                $__spare = implode(" ", array_filter($term_meta));
                $origins = str_replace(" ", "+", $__spare);
                
                if (!empty($origins)) {
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://maps.googleapis.com/maps/api/distancematrix/json?units=metrics&origins=" . $origins . "&destinations=" . $destination . "&key={$google_api_key}",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "GET",
                    ));
                    
                    $response = curl_exec($curl);
                    
                    if ($response !== false) {
                        $response_arr = json_decode($response);
                        curl_close($curl);
                        
                        if (isset($response_arr->rows[0]->elements[0]) && $response_arr->rows[0]->elements[0]->status == "OK") {
                            $distance_text = $response_arr->rows[0]->elements[0]->distance->text;
                            $dis = explode(" ", $distance_text);
                            
                            if ($_locRadius < $dis[0]) {
                                $outside_service_area = true;
                                break; // Exit early as we found an item outside service area
                            }
                        }
                    } else {
                        // Handle curl error
                        curl_close($curl);
                    }
                }
            }
        }
    }
    
    // Set notice only once after checking all items
    wc_clear_notices();
    if ($outside_service_area) {
        wc_add_notice("We are not serving this area...", "error");
    }
}
return $rates;