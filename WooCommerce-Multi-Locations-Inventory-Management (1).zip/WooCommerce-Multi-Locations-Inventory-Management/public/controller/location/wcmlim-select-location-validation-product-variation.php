<?php

$product = new WC_Product( $product_id );

$selected_store = getLocation('wcmlim_selected_location');
$cookie_termId = getLocation('wcmlim_selected_location_termid');

if((!empty($selected_store)) || (empty(!$cookie_termId))){

if(!empty($variation_id)){

$locations = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));



    foreach($locations as $key => $term){     
		
        if($key == $selected_store){
			$term_slug = $term->slug;
			$term_id = $term->term_id;

        }
	}


 $stock_meta_key = 'wcmlim_stock_at_' . $term_id;
$backorder_meta_key = 'wcmlim_allow_backorder_at_' . $term_id;




$get_stock = get_post_meta($variation_id, $stock_meta_key, true);
$allowed_backorder = get_post_meta($variation_id, $backorder_meta_key, true);


if((empty($allowed_backorder)) || ($allowed_backorder == "No")){

    

if((empty($get_stock)) || ($get_stock == "0")){

    $passed = false;
    
}else{

    $passed = true;

}

}else{

    $passed = true;
}




}else{
	
	$passed = true;
}
	
}else{
	
	$passed = false;
}



return $passed;

?>