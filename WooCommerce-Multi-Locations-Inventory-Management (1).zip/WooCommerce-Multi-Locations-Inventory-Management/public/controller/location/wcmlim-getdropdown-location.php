<?php

$termselect = isset($_POST['selectedstoreValue']) ? intval($_POST['selectedstoreValue']) : "";
$termselectocid = isset($_POST['termidExists']) ? intval($_POST['termidExists']) : "";
$selected_location = $this->get_selected_location();
$group_on = get_option('wcmlim_enable_location_group');
if(empty($selected_location))
{
    $selected_location = $termselectocid;
}

$isLocEx = get_option("wcmlim_exclude_locations_from_frontend");
$term_args = array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0);
if (!empty($isLocEx)) {
    $term_args['exclude'] = $isLocEx;
}
$terms = get_terms($term_args);

$result = array();
$current_user = wp_get_current_user();
$current_user_id = get_current_user_id();
$current_ui = isset($current_user_id) ? $current_user_id : "";
$user_selected_location = get_user_meta($current_ui, 'wcmlim_user_specific_location', true);
$restricUsers = get_option('wcmlim_enable_userspecific_location');
$roles = $current_user->roles;

if ($restricUsers == 'on' && $roles[0] == 'customer' && !empty($user_selected_location)) {
    // For restricted users, only process the specific allowed location
    foreach ($terms as $i => $term) {
        if ($user_selected_location == $i) {
            $regeionid = get_term_meta($term->term_id, 'wcmlim_locator', true);
            $term_locator = get_term_meta($term->term_id, 'wcmlim_locator', true);
            $area_name = get_term_meta($term->term_id, 'wcmlim_areaname', true);
            $result[$i] = array(
                'regeionid' => $regeionid,
                'selected' => $selected_location,
                'term_id' => strval($term->term_id),
                'classname' => 'wclimloc_' . $term->slug . ' wclimstoreloc_' . $term_locator,
                'vkey' => $i,
                'location_name' => strval($term->name),
                'location_slug' => strval($term->slug),
                'location_storeid' => $term_locator,
                'wcmlim_areaname' => $area_name
            );
            break; // Exit loop after finding the user's location
        }
    }
} else {
    // For non-restricted users
    foreach ($terms as $i => $term) {
        $regeionid = get_term_meta($term->term_id, 'wcmlim_locator', true);
        
        // Skip if group filtering is on and this term doesn't match
        if ($group_on == "on" && $termselect != $regeionid) {
            continue;
        }

        if ($regeionid) {
            $term_locator = get_term_meta($term->term_id, 'wcmlim_locator', true);
            $area_name = get_term_meta($term->term_id, 'wcmlim_areaname', true);
            $selected = "";
            if (preg_match('/^\d+$/', $selected_location) && $selected_location == $i) {
                $selected = 'selected';
            }
            
            $result[$i] = array(
                'regeionid' => $regeionid,
                'selected' => $selected_location,
                'term_id' => strval($term->term_id),
                'classname' => 'wclimloc_' . $term->slug . ' wclimstoreloc_' . $term_locator,
                'vkey' => $i,
                'location_name' => strval($term->name),
                'location_slug' => strval($term->slug),
                'location_storeid' => $term_locator,
                'wcmlim_areaname' => $area_name
            );
        }
    }
}
                        
echo json_encode($result);									
die();