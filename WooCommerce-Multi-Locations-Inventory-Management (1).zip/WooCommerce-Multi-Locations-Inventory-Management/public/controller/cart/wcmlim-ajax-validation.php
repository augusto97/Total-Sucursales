<?php
global $woocommerce;
$product_id = $_POST['product_id'];
$manage_stock = get_post_meta($product_id, '_manage_stock', true);
$response = '0';

if ($manage_stock == "yes") {
    $current_stock = get_post_meta($product_id, '_stock', true);
    $response = ($current_stock > 0) ? '1' : '0';
} else {
    $current_stock_status = get_post_meta($product_id, '_stock_status', true);
    $response = ($current_stock_status == 'instock') ? '1' : '0';
}

echo $response;
wp_die();