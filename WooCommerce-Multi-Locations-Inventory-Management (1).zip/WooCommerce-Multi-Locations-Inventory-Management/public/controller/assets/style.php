<?php

wp_enqueue_style($this->plugin_name . '_chosen_css_public', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/chosen.min.css', array(), $this->version . rand(), 'all');
wp_enqueue_style($this->plugin_name, plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-public.css', array(), $this->version . rand(), 'all');

    // theme is equal to reychild
    $current_theme = wp_get_theme();

    // Get theme name
    $theme_name = $current_theme->get('Name');
 
    if($theme_name == 'Rey Child') {
        wp_enqueue_style($this->plugin_name . '-reychild.min.css', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-reychild.min.css', array(), $this->version . rand(), 'all');
    }
    if($theme_name == 'Woodmart Child') {
        wp_enqueue_style($this->plugin_name . '-woodmart.min.css', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-reychild.min.css', array(), $this->version . rand(), 'all');
    }
 
    wp_enqueue_style($this->plugin_name."-popup-css", plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-popup-min.css', array(), $this->version . rand(), 'all');
 

    wp_enqueue_style($this->plugin_name . '_frontview_css', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-frontview-min.css', array(), $this->version . rand(), 'all');

$advanceListView = get_option('wcmlim_radio_loc_format');
$optiontype_loc = get_option('wcmlim_select_or_dropdown');
if ($advanceListView == "advanced_list_view"  && $optiontype_loc == 'on') {
wp_enqueue_style($this->plugin_name. '_list_view_pro', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-list-view-pro-min.css', array(), $this->version . rand(), 'all');
$theme = wp_get_theme();
if ($theme['Name'] == 'Astra') {
   wp_enqueue_style($this->plugin_name. '_list_view_pro_astra', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/wcmlim-astra-list-view-min.css', array(), $this->version . rand(), 'all');
}

}
$theme = wp_get_theme();
if ($theme['Name'] == 'Flatsome') {
    wp_enqueue_style($this->plugin_name . '_flatsome_css_public', plugin_dir_path(plugin_dir_url(__DIR__)) . 'css/flatsome_css_public-min.css', array(), $this->version . rand(), 'all');
    // Add any specific scripts for Flatsome theme here
    wp_enqueue_script(
        'wcmlim-flatsome-fixes',
        plugin_dir_path(plugin_dir_url(__DIR__)) . 'js/flatsome-fixes.js',
        array('jquery'),
        $this->version . rand(),
        true
    );
}

// Create dedicated file for Woodmart theme fixes to be loaded with high priority
if ($theme['Name'] == 'Woodmart Child') {
    // Register a dedicated style for Woodmart theme
    wp_register_style(
        'wcmlim-woodmart-fixes', 
        false,
        array(),
        $this->version . rand()
    );
    wp_enqueue_style('wcmlim-woodmart-fixes');
    
    // Add our fixes with higher specificity and !important flags
    wp_add_inline_style('wcmlim-woodmart-fixes', '
        /* Woodmart Theme - Quantity Selector Fix with higher specificity */
        body.theme-woodmart .woocommerce div.product form.cart .quantity,
        body.theme-woodmart.woocommerce div.product form.cart .quantity,
        body.theme-woodmart .woocommerce-page div.product form.cart .quantity,
        body.theme-woodmart .woocommerce .cart .quantity,
        body.theme-woodmart.woocommerce .cart .quantity {
            display: inline-flex !important;
            vertical-align: middle !important;
            margin-right: 10px !important;
            width: auto !important;
            flex: 0 0 auto !important;
            flex-direction: row !important;
        }
        
        body.theme-woodmart .woocommerce .quantity input[type=button],
        body.theme-woodmart .woocommerce .quantity input[type=number],
        body.theme-woodmart.woocommerce .quantity input[type=button],
        body.theme-woodmart.woocommerce .quantity input[type=number] {
            height: 42px !important;
            width: 45px !important;
            font-size: 14px !important;
            border-radius: 0 !important;
            box-shadow: none !important;
            padding: 0 5px !important;
            -webkit-appearance: none !important;
            -moz-appearance: textfield !important;
        }
        
        body.theme-woodmart .woocommerce .quantity.buttons_added .plus,
        body.theme-woodmart .woocommerce .quantity.buttons_added .minus,
        body.theme-woodmart.woocommerce .quantity.buttons_added .plus,
        body.theme-woodmart.woocommerce .quantity.buttons_added .minus {
            background-color: #f9f9f9 !important;
            color: #333 !important;
            display: inline-block !important;
            width: 30px !important;
            height: 42px !important;
            border: 1px solid #e6e6e6 !important;
            font-size: 16px !important;
            padding: 0 !important;
            text-align: center !important;
        }
        
        /* Cart page specific fixes */
        body.theme-woodmart.woocommerce-cart table.cart .quantity,
        body.theme-woodmart .woocommerce-cart table.cart .quantity,
        body.theme-woodmart .woocommerce-cart-form__cart-item .quantity {
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: center !important;
            max-width: 120px !important;
            width: auto !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }

        /* Woodmart Cart Sidebar/Drawer Fix */
        body.theme-woodmart .woodmart-cart-sidebar .quantity,
        body.theme-woodmart .wd-side-cart .quantity,
        body.theme-woodmart .woodmart-widget-shopping-cart .quantity,
        body.theme-woodmart .woocommerce-mini-cart-item .quantity,
        body.theme-woodmart .cart-widget-side .quantity {
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: flex-start !important;
            width: 100% !important;
            max-width: none !important;
            margin: 5px 0 !important;
        }

        /* Target all mini-cart quantity elements regardless of parent class */
        body.theme-woodmart .mini_cart_item .quantity,
        body.theme-woodmart .woocommerce-mini-cart .quantity {
            display: flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            width: 100% !important;
        }

        /* Control the buttons in mini cart */
        body.theme-woodmart .mini_cart_item .quantity .plus,
        body.theme-woodmart .mini_cart_item .quantity .minus,
        body.theme-woodmart .woocommerce-mini-cart .quantity .plus,
        body.theme-woodmart .woocommerce-mini-cart .quantity .minus {
            position: static !important;
            transform: none !important;
            margin: 0 !important;
        }
        
        /* Force horizontal layout for cart buttons */
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added {
            display: inline-flex !important;
            flex-direction: row !important;
            flex-wrap: nowrap !important;
            align-items: stretch !important;
        }
        
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added .minus,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added .minus,
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added .plus,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added .plus {
            order: initial !important;
            position: static !important;
            transform: none !important;
            margin: 0 !important;
            height: 42px !important;
        }
        
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added .minus,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added .minus {
            border-right: 0 !important;
            border-top-right-radius: 0 !important;
            border-bottom-right-radius: 0 !important;
        }
        
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added .plus,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added .plus {
            border-left: 0 !important;
            border-top-left-radius: 0 !important;
            border-bottom-left-radius: 0 !important;
        }
        
        body.theme-woodmart.woocommerce-cart .quantity.buttons_added .qty,
        body.theme-woodmart .woocommerce-cart .quantity.buttons_added .qty {
            border-radius: 0 !important;
            border-left: 1px solid #e6e6e6 !important;
            border-right: 1px solid #e6e6e6 !important;
        }
        
        /* Checkout page fixes */
        body.theme-woodmart.woocommerce-checkout .quantity {
            margin-right: 0 !important;
            margin-left: 0 !important;
            display: inline-flex !important;
        }
        
        /* Force input number to behave */
        body.theme-woodmart .woocommerce input.qty,
        body.theme-woodmart.woocommerce input.qty,
        body.theme-woodmart .quantity input[type="number"].qty {
            width: 45px !important;
            height: 42px !important;
            text-align: center !important;
            padding: 0 5px !important;
            margin: 0 !important;
            border-left: none !important;
            border-right: none !important;
            background-color: #fff !important;
            -moz-appearance: textfield !important;
        }
        
        /* Remove arrows from number input */
        body.theme-woodmart .woocommerce input.qty::-webkit-outer-spin-button,
        body.theme-woodmart .woocommerce input.qty::-webkit-inner-spin-button,
        body.theme-woodmart.woocommerce input.qty::-webkit-outer-spin-button,
        body.theme-woodmart.woocommerce input.qty::-webkit-inner-spin-button {
            -webkit-appearance: none !important;
            margin: 0 !important;
        }
    ');
    
    // Add body class and re-apply styles after a delay to ensure they persist after theme JS
    wp_add_inline_script('jquery', '
        jQuery(document).ready(function($){
            // Add body class immediately
            $("body").addClass("theme-woodmart");
            
            // Apply fixes initially
            applyWoodmartFixes();
            
            // Then reapply after a delay to handle cases where theme JS modifies styles later
            setTimeout(applyWoodmartFixes, 500);
            setTimeout(applyWoodmartFixes, 1000); // Apply again after 1 second for cart page
            
            // Also apply on any ajax completion
            $(document).ajaxComplete(function() {
                setTimeout(applyWoodmartFixes, 100);
            });
            
            // Handle any dynamic quantity changes
            $(document).on("change", ".qty", function() {
                setTimeout(applyWoodmartFixes, 100);
            });
            
            // Watch for drawer cart opening
            $(document).on("click", ".woodmart-cart-icon, .cart-widget-opener", function() {
                setTimeout(applyWoodmartFixes, 300);
                setTimeout(applyWoodmartFixes, 600);
            });
            
            // Monitor cart page quantity elements for changes
            if ($(".woocommerce-cart").length) {
                var observer = new MutationObserver(function() {
                    applyWoodmartFixes();
                });
                
                $(".woocommerce-cart-form").each(function() {
                    observer.observe(this, { 
                        childList: true, 
                        subtree: true,
                        attributes: true
                    });
                });
            }
            
            // Monitor the body for the drawer cart being added
            var bodyObserver = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.addedNodes.length) {
                        for (var i = 0; i < mutation.addedNodes.length; i++) {
                            var node = mutation.addedNodes[i];
                            if (node.nodeType === 1 && 
                                (node.classList.contains("woodmart-cart-sidebar") || 
                                 node.classList.contains("wd-side-cart") ||
                                 node.classList.contains("cart-widget-side"))) {
                                setTimeout(applyWoodmartFixes, 100);
                            }
                        }
                    }
                });
            });
            
            bodyObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
            
            function applyWoodmartFixes() {
                // Regular quantity fields
                $(".woocommerce .quantity, .woocommerce-page .quantity").css({
                    "display": "inline-flex",
                    "vertical-align": "middle",
                    "width": "auto",
                    "flex-direction": "row"
                });
                
                $(".woocommerce .quantity input[type=number], .woocommerce-page .quantity input[type=number]").css({
                    "height": "42px",
                    "width": "45px",
                    "text-align": "center"
                });
                
                $(".woocommerce .quantity.buttons_added .plus, .woocommerce .quantity.buttons_added .minus").css({
                    "display": "inline-block",
                    "width": "30px",
                    "height": "42px",
                    "position": "static",
                    "transform": "none"
                });
                
                // Cart-specific fixes
                if ($(".woocommerce-cart").length) {
                    $(".woocommerce-cart-form .quantity.buttons_added").css({
                        "display": "inline-flex",
                        "flex-direction": "row",
                        "flex-wrap": "nowrap"
                    });
                }
                
                // Mini-cart / Drawer cart fixes
                $(".woodmart-cart-sidebar .quantity, .wd-side-cart .quantity, .cart-widget-side .quantity, .woocommerce-mini-cart-item .quantity").css({
                    "display": "flex",
                    "flex-direction": "row",
                    "width": "100%",
                    "max-width": "none"
                });
                
                $(".woodmart-cart-sidebar .quantity .plus, .woodmart-cart-sidebar .quantity .minus, .wd-side-cart .quantity .plus, .wd-side-cart .quantity .minus").css({
                    "position": "static",
                    "transform": "none"
                });
            }
        });
    ');
}



//-----Be Theme Fixes Compatibility-----//
// Create dedicated fixes for Be theme with improved detection
if (strpos(strtolower($theme['Name']), 'be') !== false || 
    strpos(strtolower($theme['Template']), 'be') !== false || 
    $theme['TextDomain'] === 'betheme') {
    
   
    // Register a dedicated style for Be theme
    wp_register_style(
        'wcmlim-be-theme-fixes', 
        false,
        array(),
        $this->version . rand()
    );
    wp_enqueue_style('wcmlim-be-theme-fixes');
    
    // Add our fixes with higher specificity and !important flags
    wp_add_inline_style('wcmlim-be-theme-fixes', '
        /* ===== COMMON FIXES FOR ALL PRODUCT TYPES ===== */
        
        /* Common location selector styling for all product types */
        .wcmlim-location-selector {
            clear: both !important;
            margin: 15px 0 !important;
            padding: 12px !important;
            border: 1px solid #e5e5e5 !important;
            background-color: #f8f8f8 !important;
            border-radius: 4px !important;
            position: relative !important;
            width: 100% !important;
            box-sizing: border-box !important;
            float: none !important;
            display: block !important;
        }
        
        /* Common select styling for all product types */
        .wcmlim-location-selector select {
            width: 100% !important;
            max-width: 100% !important;
            height: 40px !important;
            padding: 0 15px !important;
            border: 1px solid #ddd !important;
            border-radius: 3px !important;
            background-color: #fff !important;
            box-shadow: none !important;
            font-size: 14px !important;
            line-height: 38px !important;
            margin: 0 !important;
            display: block !important;
            box-sizing: border-box !important;
            float: none !important;
        }
        
        /* Fix location labels for all product types */
        .wcmlim-location-selector label {
            display: block !important;
            margin-bottom: 8px !important;
            font-weight: 600 !important;
            color: #333 !important;
            width: 100% !important;
        }
        
        /* Common form styling for all product types */
        form.cart {
            clear: both !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
            width: 100% !important;
            box-sizing: border-box !important;
        }
        
        /* Common quantity styling for all product types */
        form.cart .quantity {
            float: left !important;
            margin-right: 10px !important;
            margin-bottom: 10px !important;
        }
        
        /* Common button styling for all product types */
        .single_add_to_cart_button {
            margin-top: 0 !important;
        }
        
        /* ===== SIMPLE PRODUCT SPECIFIC FIXES ===== */
        
        /* Form container for simple products */
        form.cart:not(.variations_form) {
            display: flex !important;
            flex-wrap: wrap !important;
            align-items: center !important;
        }
        
        /* Location selector in simple products */
        form.cart:not(.variations_form) .wcmlim-location-selector {
            flex-basis: 100% !important;
            margin: 0 0 15px 0 !important;
        }
        
        /* Quantity input in simple products */
        form.cart:not(.variations_form) .quantity {
            margin-right: 10px !important;
            margin-bottom: 0 !important;
        }
        
        /* Add to cart button in simple products */
        form.cart:not(.variations_form) .single_add_to_cart_button {
            flex: 0 0 auto !important;
            clear: none !important;
        }
        
        /* ===== VARIABLE PRODUCT SPECIFIC FIXES ===== */
        
        /* Form container for variable products */
        .variations_form.cart {
            width: 100% !important;
            margin: 0 0 15px 0 !important;
            padding: 0 !important;
            float: none !important;
            clear: both !important;
            display: block !important;
            box-sizing: border-box !important;
        }
        
        /* Variations table in variable products */
        .variations_form .variations {
            width: 100% !important;
            margin: 0 0 15px 0 !important;
            padding: 0 !important;
            border: none !important;
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            float: none !important;
            clear: both !important;
        }
        
        /* Table rows in variable products */
        .variations_form .variations tr {
            display: block !important;
            margin-bottom: 10px !important;
            width: 100% !important;
            border: none !important;
        }
        
        /* Label cells in variable products */
        .variations_form .variations td.label,
        .variations_form .variations th.label {
            display: block !important;
            width: 100% !important;
            padding: 0 0 5px 0 !important;
            text-align: left !important;
            background: none !important;
            border: none !important;
        }
        
        /* Value cells in variable products */
        .variations_form .variations td.value,
        .variations_form .variations th.value {
            display: block !important;
            width: 100% !important;
            padding: 0 !important;
            text-align: left !important;
            background: none !important;
            border: none !important;
        }
        
        /* Labels in variable products */
        .variations_form .variations label {
            font-weight: 600 !important;
            margin: 0 0 5px 0 !important;
            display: block !important;
            font-size: 14px !important;
        }
        
        /* Select dropdowns in variable products */
        .variations_form .variations select {
            display: block !important;
            width: 100% !important;
            max-width: 100% !important;
            height: 40px !important;
            padding: 0 15px !important;
            margin: 0 0 10px 0 !important;
            border: 1px solid #ddd !important;
            border-radius: 3px !important;
            background-color: #fff !important;
            box-shadow: none !important;
            float: none !important;
        }
        
        /* Reset variations link */
        .variations_form .reset_variations {
            display: inline-block !important;
            margin: 5px 0 15px !important;
            clear: both !important;
            visibility: visible !important;
            float: none !important;
            background-color: #f5f5f5 !important;
            padding: 3px 8px !important;
            border-radius: 3px !important;
            font-size: 12px !important;
        }
        
        /* Variation price */
        .variations_form .woocommerce-variation-price {
            width: 100% !important;
            margin-bottom: 10px !important;
            float: none !important;
            clear: both !important;
        }
        
        /* Variation description */
        .variations_form .woocommerce-variation-description {
            width: 100% !important;
            margin-bottom: 10px !important;
            float: none !important;
            clear: both !important;
        }
        
        /* Variation availability */
        .variations_form .woocommerce-variation-availability {
            width: 100% !important;
            margin-bottom: 10px !important;
            float: none !important;
            clear: both !important;
        }
        
        /* Variation wrapper */
        .variations_form .woocommerce-variation {
            padding: 10px !important;
            border: 1px solid #f0f0f0 !important;
            margin-bottom: 15px !important;
            width: 100% !important;
            clear: both !important;
            float: none !important;
            display: block !important;
            box-sizing: border-box !important;
        }
        
        /* Single variation wrap */
        .variations_form .single_variation_wrap {
            width: 100% !important;
            float: none !important;
            clear: both !important;
            margin: 15px 0 0 0 !important;
            padding: 0 !important;
            display: block !important;
        }
        
        /* Location selector in variable products */
        .variations_form .wcmlim-location-selector {
            margin-top: 20px !important;
            clear: both !important;
            float: none !important;
            width: 100% !important;
        }
        
        /* Add to cart area in variable products */
        .variations_form .woocommerce-variation-add-to-cart {
            display: flex !important;
            flex-wrap: wrap !important;
            align-items: center !important;
            width: 100% !important;
            float: none !important;
            clear: both !important;
        }
        
        /* Quantity in variable products */
        .variations_form .woocommerce-variation-add-to-cart .quantity {
            float: left !important;
            margin-right: 10px !important;
            margin-bottom: 10px !important;
        }
        
        /* Add to cart button in variable products */
        .variations_form .woocommerce-variation-add-to-cart .single_add_to_cart_button {
            flex: 0 0 auto !important;
            float: left !important;
            clear: none !important;
            margin-top: 0 !important;
        }
        
        /* ===== LAYOUT TYPE FIXES ===== */
        
        /* 2 Column Layout */
        .column.one-second .wcmlim-location-selector,
        .columns.one-second .wcmlim-location-selector,
        .column.one-half .wcmlim-location-selector,
        .columns.one-half .wcmlim-location-selector,
        .grid .column-1-2 .wcmlim-location-selector,
        .grid .column-50 .wcmlim-location-selector {
            width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }
        
        /* 3 Column Layout */
        .column.one-third .wcmlim-location-selector,
        .columns.one-third .wcmlim-location-selector,
        .grid .column-1-3 .wcmlim-location-selector,
        .grid .column-33 .wcmlim-location-selector {
            width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }
        
        /* List View */
        .products.list .product .wcmlim-location-selector,
        .products.list li .wcmlim-location-selector {
            width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }
        
        /* Card View */
        .products .product .wcmlim-location-selector,
        .product-item .wcmlim-location-selector {
            width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }
        
        /* Table View */
        table.shop_table .wcmlim-location-selector,
        .shop_table .wcmlim-location-selector {
            width: 100% !important;
            margin: 10px 0 !important;
        }
        
        /* Expanded View */
        .woocommerce-product-gallery--with-images + .summary .wcmlim-location-selector {
            width: 100% !important;
            clear: both !important;
        }
        
        /* Drawer/Popup View */
        .popup-content .wcmlim-location-selector,
        .drawer-content .wcmlim-location-selector,
        .modal-content .wcmlim-location-selector {
            width: 100% !important;
            margin: 10px 0 !important;
        }
        
        /* Add a clear fix after forms to prevent layout issues */
        form.cart:after,
        .variations_form:after {
            content: "" !important;
            display: table !important;
            clear: both !important;
        }
        
        /* Responsive Mobile Fixes */
        @media (max-width: 768px) {
            /* Common mobile fixes */
            .wcmlim-location-selector,
            .wcmlim-location-selector select {
                width: 100% !important;
                max-width: 100% !important;
            }
            
            /* Simple product mobile fixes */
            form.cart:not(.variations_form) {
                flex-direction: column !important;
                align-items: stretch !important;
            }
            
            form.cart:not(.variations_form) .quantity,
            form.cart:not(.variations_form) .single_add_to_cart_button {
                width: 100% !important;
                margin-right: 0 !important;
                margin-bottom: 10px !important;
            }
            
            /* Variable product mobile fixes */
            .variations_form .woocommerce-variation-add-to-cart {
                flex-direction: column !important;
                align-items: stretch !important;
            }
            
            .variations_form .woocommerce-variation-add-to-cart .quantity,
            .variations_form .woocommerce-variation-add-to-cart .single_add_to_cart_button {
                width: 100% !important;
                margin-right: 0 !important;
                margin-bottom: 10px !important;
                margin-left: 0 !important;
                float: none !important;
            }
        }
    ');
}
