<?php
if(is_shop()) {
// Get selected location once
$setLocation = getLocation('wcmlim_selected_location') ?: (isset($_COOKIE['wcmlim_selected_location']) ? $_COOKIE['wcmlim_selected_location'] : "");
$terms = get_terms(['taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0]);
$price_html = '';
$sel_term_id = null;

// Find the selected term ID early
if (!empty($setLocation)) {
    foreach ($terms as $key => $term) {
        if ($key == $setLocation) {
            $sel_term_id = $term->term_id;
            break;
        }
    }
}
// Process simple products
if ($product->get_type() == 'simple') {
    $hasCustomPrice = false;
    foreach ($terms as $k => $term) { 
        if ($setLocation == $k) {
            $locRP = get_post_meta($product->get_id(), "wcmlim_regular_price_at_{$term->term_id}", true);
            $locSP = get_post_meta($product->get_id(), "wcmlim_sale_price_at_{$term->term_id}", true);
            if ( function_exists( 'wmc_get_price' ) ) {
                $wRP = wmc_get_price( $locRP );
                $wSP = wmc_get_price( $locSP );
            } else {
                $wRP = wc_price($locRP);
                $wSP = wc_price($locSP);
            }
            if (!empty($locSP)) {
                $price_html = "<del>{$wRP}</del><ins>{$wSP}</ins>";
                $hasCustomPrice = true;
            } elseif (!empty($locRP)) {
                $price_html = $wRP;
                $hasCustomPrice = true;
            }
            break;
        }
    }
    if (!$hasCustomPrice) {
        // Fallback for simple product: use WooCommerce's price methods and format with wc_price
        $sale = $product->get_sale_price();
        $regular = $product->get_price();
        if (!empty($sale)) {
            $price_html = '<del>' . wc_price($regular) . '</del><ins>' . wc_price($sale) . '</ins>';
        } elseif (!empty($regular)) {
            $price_html = wc_price($regular);
        } else {
            $price_html = '';
        }
    }
}

// 6068 show default variation price at locations on shop page code init
$default_var_price = get_option('wcmlim_enable_location_onshop_variable');
if ($default_var_price == 'on') {
    // Process variable products with default attributes
    if ($product->get_type() == 'variable') {
        if (!empty($product->get_default_attributes())) {
            $_var_id = null;
            $default_attributes = $product->get_default_attributes();
            
            // Find default variation ID
            foreach ($product->get_available_variations() as $variation_values) {
                $is_default_variation = true;
                foreach ($variation_values['attributes'] as $key => $attribute_value) {
                    $attribute_name = str_replace('attribute_', '', $key);
                    $default_value = $product->get_variation_default_attribute($attribute_name);
                    if ($default_value != $attribute_value) {
                        $is_default_variation = false;
                        break;
                    }
                }
                if ($is_default_variation) {
                    $_var_id = $variation_values['variation_id'];
                    break;
                }
            }
            // Get price for default variation at selected location
            if ($_var_id && $sel_term_id) {
                $locRP = get_post_meta($_var_id, "wcmlim_regular_price_at_{$sel_term_id}", true);
                $locSP = get_post_meta($_var_id, "wcmlim_sale_price_at_{$sel_term_id}", true);
                if ( function_exists( 'wmc_get_price' ) ) {
                    $wRP = wmc_get_price( $locRP );
                    $wSP = wmc_get_price( $locSP );
                }  else {
                    $wRP = wc_price($locRP);
                    $wSP = wc_price($locSP);
                }
                if (!empty($locSP)) {
                    $price_html = "<del>{$wRP}</del><ins>{$wSP}</ins>";
                } elseif (!empty($locRP)) {
                    $price_html = $wRP;
                } else {
                    $variation = wc_get_product($_var_id);
                    if ($variation) {
                        $price_html = $variation->get_price_html();
                    } else {
                        $price_html = $product->get_price_html();
                    }
                }
            } else {
                // Fallback for variable product with default attributes: min-max price range
                $prices = $product->get_variation_prices();
                if (!empty($prices['regular_price'])) {
                    $min = min($prices['regular_price']);
                    $max = max($prices['regular_price']);
                    if ($min != $max) {
                        $price_html = wc_price($min) . ' - ' . wc_price($max);
                    } else {
                        $price_html = wc_price($min);
                    }
                } else {
                    $price_html = '';
                }
            }
        } 
        // Process variable products without default attributes
        else {
            if ($sel_term_id) {
                $variations = $product->get_available_variations();
                $variations_id = wp_list_pluck($variations, 'variation_id');
                
                $locRP = array();
                $locSP = array();
                foreach ($variations_id as $var_id) {
                    $rp = get_post_meta($var_id, "wcmlim_regular_price_at_{$sel_term_id}", true);
                    $sp = get_post_meta($var_id, "wcmlim_sale_price_at_{$sel_term_id}", true);
                    
                    if (!empty($rp)) $locRP[] = $rp;
                    if (!empty($sp)) $locSP[] = $sp;
                }
                
                if (!empty($locRP)) {
                    $locRP = array_unique($locRP);
                    sort($locRP);
                    $cp = (int)count($locRP) - 1;
                    if ( function_exists( 'wmc_get_price' ) ) {
                        $rminPrice = wmc_get_price( $locRP[0] );
                        $rmaxPrice = wmc_get_price( $locRP[$cp] );
                    }  else {
                        $rminPrice = wc_price($locRP[0]);
                        $rmaxPrice = wc_price($locRP[$cp]);
                    }
                    if (!empty($locSP)) {
                        $locSP = array_unique($locSP);
                        sort($locSP);
                        $cps = (int)count($locSP) - 1;
                        if ( function_exists( 'wmc_get_price' ) ) {
                            $sminPrice = wmc_get_price( $locSP[0] );
                            $smaxPrice = wmc_get_price( $locSP[$cps] );
                        }  else {
                            $sminPrice = wc_price($locSP[0]);
                            $smaxPrice = wc_price($locSP[$cps]);
                        }
                        $price_html = "<del>{$rminPrice} - {$rmaxPrice}</del>  <ins>{$sminPrice} - {$smaxPrice}</ins>";
                    } else {
                        $price_html = "<ins>{$rminPrice} - {$rmaxPrice}</ins>";
                    }
                } else {
                    // Fallback for variable product without default attributes: min-max price range
                    $prices = $product->get_variation_prices();
                    if (!empty($prices['regular_price'])) {
                        $min = min($prices['regular_price']);
                        $max = max($prices['regular_price']);
                        if ($min != $max) {
                            $price_html = wc_price($min) . ' - ' . wc_price($max);
                        } else {
                            $price_html = wc_price($min);
                        }
                    } else {
                        $price_html = '';
                    }
                }
            } else {
                $price_html = $product->get_price_html();
            }
        }
    }
}
}
return $price_html;