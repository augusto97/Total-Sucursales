<?php
ob_start();
		
		// Get options and settings - reusing same settings as original shortcode
		$Inline_title = get_option("wcmlim_txt_inline_location", true);									
		$geolocation = get_option('wcmlim_geo_location');
		$useLc = get_option('wcmlim_enable_autodetect_location');
		$autodetect_by_maxmind = get_option('wcmlim_enable_autodetect_location_by_maxmind');
		$uspecLoc = get_option('wcmlim_enable_userspecific_location');
		$restrictGuest = get_option('wcmlim_enable_restrict_guestuser_location');
		$show_in_popup = get_option("wcmlim_show_in_popup");
		$isLocationsGroup = get_option('wcmlim_enable_location_group');
		$current_user = wp_get_current_user();
		
		// Get selected location, but ensure empty cookie returns null
		$selected_location = $this->get_selected_location();
		// Check if cookie exists and has value
		if (!isset($_COOKIE['wcmlim_selected_location'])) {
			$selected_location = null; // Ensure null for empty cookie value
		}

		// Check for editor URL
		$isEditor = wp_get_referer();
		if(strpos($isEditor, 'action=edit') || strpos($isEditor, 'post-new.php')){
			return;
		}
		
		// Get locations list
		$locations_list = $this->wcmlim_get_all_locations();
		$storelocator_list = array();
		if ($isLocationsGroup == 'on') {
			$storelocator_list = $this->wcmlim_get_all_store();		
		}
		
		// Generate Avada-specific markup
		?>
		<div class="wcmlim-avada-location-switcher">
			<form id="avada-lc-switch-form" class="wcmlim-avada-form fusion-search-form" method="post">
				<div class="wcmlim-avada-form-content fusion-search-form-content">
					<div class="wcmlim-avada-select-wrapper fusion-select-wrapper">
						<label class="screen-reader-text" for="wcmlim-avada-change-lc-select">
							<?php _e('Select Location', 'wcmlim'); ?>
						</label>
						<span class="wcmlim-avada-location-label fusion-custom-menu-item-title">
							<?php 
							if ($Inline_title) {
								echo $Inline_title;
							} else {
								_e('Location: ', 'wcmlim');
							}
							?>
						</span>
						<select name="wcmlim_change_lc_to" class="wcmlim-avada-lc-select fusion-select-dropdown" id="wcmlim-avada-change-lc-select" onchange="document.getElementById('wcmlim_location_term_id').value = this.options[this.selectedIndex].getAttribute('data-lc-term'); this.form.submit();">
							<option value="-1" <?php if (!$selected_location || !isset($selected_location)) echo "selected='selected'"; ?>><?php _e('Select', 'wcmlim') ?></option>
							<?php
							foreach ($locations_list as $key => $loc) {
							?>
								<option 
									class="<?php echo 'wclimloc_'.$loc['location_slug']; ?>" 
									value="<?php echo $key; ?>" 
									data-lc-address="<?php echo base64_encode($loc['location_address']); ?>"
									data-lc-term="<?php echo $loc['location_termid']; ?>" 
									<?php if (isset($selected_location) && preg_match('/^\d+$/', $selected_location) && $selected_location == $key) echo "selected='selected'"; ?>>
									<?php echo ucfirst($loc['location_name']); ?>
								</option>
							<?php } ?>
						</select>
						<div class="er_location fusion-error-message"></div>
					</div>
					
					<?php if ($geolocation == "on" || (is_array($show_in_popup) && in_array('location_finder_in_popup', $show_in_popup))): ?>
						<div class="wcmlim-avada-postcode-checker fusion-search-field">
							<?php
							$globpin = getLocation('wcmlim_nearby_location');
							$loc_dis_un = get_option('wcmlim_location_distance');
							?>
							<input type="text" placeholder="<?php _e('Enter Pincode/Zipcode', 'wcmlim'); ?>" 
								   required class="class_post_code_global fusion-search-field-input" 
								   name="post_code_global" 
								   value="<?php if($globpin != 0) echo esc_html($globpin); ?>" 
								   id="avada-elementIdGlobal">
							<button type="button" class="fusion-search-button" id="avada_submit_postcode_global">
								<i class="fusion-icon-search"></i>
								<span class="screen-reader-text"><?php _e('Apply', 'wcmlim'); ?></span>
							</button>
							<input type="hidden" name="global_postal_check" id="avada-global-postal-check" value="true">
							<input type="hidden" name="global_postal_location" id="avada-global-postal-location" value="<?php esc_html_e($globpin); ?>">
							<input type="hidden" name="product_location_distance" id="avada-product-location-distance" value="<?php esc_html_e($loc_dis_un); ?>">
							
							<?php if ($useLc == "on"): ?>
								<div class="wcmlim-avada-locsearch fusion-custom-link">
									<a id="avada-currentLoc" class="currentLoc fusion-custom-menu-item">
										<i class="fas fa-crosshairs"></i>
										<span><?php _e('Use Current Location', 'wcmlim'); ?></span>
									</a>
								</div>
							<?php endif; ?>
							
							<div class="wcmlim-avada-search-response">
								<div class="postcode-checker-response"></div>
							</div>
							<div class="postcode-location-distance"></div>
						</div>
					<?php endif; ?>
				</div>
				<?php wp_nonce_field('wcmlim_change_lc', 'wcmlim_change_lc_nonce'); ?>
				<input type="hidden" name="wcmlim_location_term_id" id="wcmlim_location_term_id" value="">
				<input type="hidden" name="action" value="wcmlim_location_change">
			</form>
		</div>

		<script>
		// Set the initial term ID for the currently selected option (if any)
		document.addEventListener('DOMContentLoaded', function() {
			var select = document.getElementById('wcmlim-avada-change-lc-select');
			if(select && select.selectedIndex > 0) {
				document.getElementById('wcmlim_location_term_id').value = 
					select.options[select.selectedIndex].getAttribute('data-lc-term');
			}
		});
		</script>
		
		<style>
		.wcmlim-avada-location-switcher {
			margin: 0;
			padding: 0;
			display: inline-flex;
			align-items: center;
			height: 100%;
			vertical-align: middle;
		}
		.fusion-header-wrapper .wcmlim-avada-location-switcher {
			height: auto;
			display: flex;
			align-items: center;
		}
		.fusion-secondary-menu > ul > li .wcmlim-avada-location-switcher,
		.fusion-main-menu > ul > li .wcmlim-avada-location-switcher {
			height: auto;
		}
		.wcmlim-avada-form {
			display: flex;
			align-items: center;
			margin: 0;
			height: 100%;
		}
		.wcmlim-avada-form-content {
			display: flex;
			align-items: center;
			flex-wrap: nowrap;
			height: 100%;
		}
		.wcmlim-avada-select-wrapper {
			position: relative;
			margin-right: 10px;
			display: flex;
			align-items: center;
		}
		.wcmlim-avada-location-label {
			display: inline-flex;
			margin-right: 5px;
			color: var(--awb-menu_typography-color, inherit);
			font-size: var(--awb-menu_typography-font-size, 14px);
			font-family: var(--awb-menu_typography-font-family, inherit);
			line-height: normal;
			align-items: center;
			height: 100%;
		}
		.wcmlim-avada-lc-select {
			height: 32px;
			line-height: 32px;
			min-width: 120px;
			border-radius: 0;
			font-size: var(--awb-menu_typography-font-size, 14px);
			border: 1px solid var(--awb-color3, #e2e2e2);
			padding: 0 5px;
			vertical-align: middle;
			margin-top: 0;
			margin-bottom: 0;
		}
		.fusion-menu-element-wrapper .wcmlim-avada-location-switcher {
			align-items: center;
			height: auto;
		}
		/* For menu items that contain our location switcher */
		.fusion-menu-element-wrapper .fusion-menu-element-list > li.menu-item:has(.wcmlim-avada-location-switcher) {
			align-items: center;
		}
		/* Responsive styling */
		@media only screen and (max-width: 800px) {
			.wcmlim-avada-location-switcher {
				padding: 5px 0;
			}
		}
		/* Match inline spacing with standard Avada elements */
		.fusion-header .fusion-main-menu > ul > li {
			padding-right: 0;
		}
		/* Fix for fusion header v7 layout */
		.fusion-header-v7 .fusion-middle-logo-ul li .wcmlim-avada-location-switcher {
			padding-top: 0;
			padding-bottom: 0;
			display: inline-flex;
			vertical-align: middle;
		}
		</style>
		<?php
		return ob_get_clean();
	

    ?>