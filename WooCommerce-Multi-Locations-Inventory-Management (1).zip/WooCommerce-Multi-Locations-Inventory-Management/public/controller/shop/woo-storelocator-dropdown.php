<?php

global $post;
$Inline_title = get_option("wcmlim_txt_inline_location", true);									
$geolocation = get_option('wcmlim_geo_location');
$useLc = get_option('wcmlim_enable_autodetect_location');
$uspecLoc = get_option('wcmlim_enable_userspecific_location');
$show_in_popup = get_option("wcmlim_show_in_popup");
$product = wc_get_product($post->ID);
$storelocator_list = $this->wcmlim_get_all_store();
$locations_list = $this->wcmlim_get_all_locations();										
$selected_location = $this->get_selected_location();
$terms = get_terms(array('taxonomy' => 'location_group', 'hide_empty' => false, 'parent' => 0));

// Get the placeholder text from query var
$placeholder = get_query_var('wcmlim_dropdown_placeholder', '- Select Location -');

if (sizeof($locations_list) > 0) { 
    // Variable product handling
    if ($product instanceof WC_Product && $product->is_type('variable') && !$product->is_downloadable() && !$product->is_virtual()) { ?>
        <select class="sel_location Wcmlim_sel_loc" name="sel_location">
            <option value="" selected><?php echo esc_html($placeholder); ?></option>
        </select>
        <div class="wcmlim-lcswitch" style="display:none;" >
    <?php } else { ?>
        <div class="wcmlim-lcswitch">
    <?php } ?>
        
        <div class="wcmlim_sel_location wcmlim_storeloc">
            <select name="wcmlim_change_sl_to" class="wcmlim_changesl" id="wcmlim-change-sl-select">
            <?php 
            if (empty($terms)) { ?>
                <option value="-1"><?php _e('No group found', 'wcmlim'); ?></option>
            <?php } else { ?>
                <option value="" selected><?php echo esc_html($placeholder); ?></option>
                <?php
                // Build store options in one go
                foreach ($storelocator_list as $loc) {
                    printf(
                        '<option class="wclimstore_%s" value="%s">%s</option>',
                        esc_attr($loc['store_id']),
                        esc_attr($loc['store_id']),
                        esc_html(ucfirst($loc['store_name']))
                    );
                }
            } ?>
            </select>
                                        
            <select class="wcmlim_lcselect" name="wcmlim_change_lc_to" id="wcmlim-change-lcselect">
                <option value="-1" <?php selected(empty($selected_location)); ?>><?php _e('Please Select', 'wcmlim'); ?></option>
            </select>
        </div>	
    </div>
    
    <script type="text/javascript"> 
    jQuery(document).ready(function() {
        var regiExists = <?php echo json_encode(getLocation('wcmlim_selected_location_regid')); ?>;  
        var termiExists = <?php echo json_encode(getLocation('wcmlim_selected_location_termid')); ?>;  
        
        if (regiExists) {
            jQuery('.wcmlim_changesl option[value=' + regiExists + ']').prop("selected", true);
        }
        if (termiExists) {
            jQuery('.wcmlim_lcselect option[data-lc-term=' + termiExists + ']').prop("selected", true);
        }
    });
    </script>
<?php } ?>