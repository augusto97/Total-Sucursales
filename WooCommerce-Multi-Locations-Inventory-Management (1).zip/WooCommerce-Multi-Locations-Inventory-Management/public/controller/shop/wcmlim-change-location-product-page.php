<?php


$location_key = $_POST['loc_key'] ?? '';
$cookieindays = get_option('wcmlim_set_location_cookie_time');

setLocation("wcmlim_selected_location", $location_key, 86400 * $cookieindays);

$locations = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));
foreach($locations as $key => $term){     
    if($key == $location_key){
		$term_slug = $term->slug;
		$term_id = $term->term_id;
    }
}

$term_id = isset($term_id) ? $term_id : "";
setLocation("wcmlim_selected_location_termid", $term_id, 36000);

// Using getLocation() for fetching cookies
$selected_store = getLocation('wcmlim_selected_location');
$cookie_termId = getLocation('wcmlim_selected_location_termid');

$return = "success";
wp_send_json_success($return);



