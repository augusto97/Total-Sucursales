<?php
/**
 * Template: Select View (Dropdown)
 * This file handles the front-end rendering when using a select (dropdown) view.
 */

// Ensure dashicons are loaded in frontend
// Helper function wrapper - delegates to class method to avoid duplicate declaration
if (!function_exists('wcmlim_get_loactionaddress')) {
    function wcmlim_get_loactionaddress($termid)
    {
        $streetNumber = get_term_meta($termid, 'wcmlim_street_number', true);
        $route = get_term_meta($termid, 'wcmlim_route', true);
        $locality = get_term_meta($termid, 'wcmlim_locality', true);
        $state = get_term_meta($termid, 'wcmlim_administrative_area_level_1', true);
        $postal_code = get_term_meta($termid, 'wcmlim_postal_code', true);
        $country = get_term_meta($termid, 'wcmlim_country', true);
        return $streetNumber . " " . $route . " " . $locality . " " . $state . " " . $postal_code . " " . $country;
    }
}

wp_enqueue_style('dashicons');
$selected_location_termid = isset($_COOKIE['wcmlim_selected_location']) ? intval($_COOKIE['wcmlim_selected_location']) : null;
$wcmlim_selected_location_termid = isset($_COOKIE['wcmlim_selected_location_termid']) ? intval($_COOKIE['wcmlim_selected_location_termid']) : null;

?>
<div class="Wcmlim_container wcmlim_product wcmlim-select_view">
    <div class="Wcmlim_box_wrapper">
        <div class="Wcmlim_box_content select_location-wrapper">
            <div class="Wcmlim_box_header">
                <h4 class="Wcmlim_box_title">
                    <?php
                    $display_text = get_option('wcmlim_location_display_heading_setting');
                    if ($hideDropdown != "on" && !empty($terms)) {
                        echo $display_text;
                    }
                    ?>
                </h4>
            </div>
            <div class="Wcmlim_prefloc_box">
                <?php if ($hideDropdown == "on") { ?>
                    <div class="loc_dd Wcmlim_prefloc_sel" style="display: none;">
                <?php } else { ?>
                    <div class="loc_dd Wcmlim_prefloc_sel">
                <?php } ?>
                   
                    <i class="wc_locmap fa fa-map-marker-alt" style="font-size: 18px;"></i>
                    <?php if ($isLocationsGroup == 'on') { ?>
                        <div class="wclim_select_location" style="display: inline-block;">
                            <?php echo do_shortcode('[wcmlim_loc_storedropdown]'); ?>
                        </div>
                        <style>
                            .loc_dd.Wcmlim_prefloc_sel .select_location { display: none !important; }
                        </style>
                        <select class="select_location" name="select_location" id="select_location">
                    <?php } else { ?> 
                        <select class="select_location Wcmlim_sel_loc" name="select_location" id="select_location" required>
                    <?php } ?>
                    <option data-lc-qty="" value="-1"><?php echo esc_html('- Select Location -', 'wcmlim'); ?></option>
                        
                        <?php

                        // ...existing code...
                        foreach ($filtered_terms as $k => $term) {

                            /**
                             * Retrieve location index by term ID
                             * 
                             * This code fetches all location terms and then identifies the array key (index)
                             * of the specific location that matches the current term ID. This ensures we 
                             * maintain the correct reference index for the location term even when term order
                             * or values have been modified in the database, which could otherwise affect results.
                             * 
                             * @since 4.2.1
                             */
                            $locations = get_terms([
                                'taxonomy' => 'locations',
                                'hide_empty' => false,
                            ]);

                            // Match current term with location to set key
                            foreach ($locations as $location_key => $location) {
                                if ($location->term_id == $term->term_id) {
                                    $k = $location_key;
                                    break;
                                }
                            }
                            $hide_ind_location = get_term_meta($term->term_id, 'wcmlim_location_hide', true);
                            if($hide_ind_location == "yes") {
                                continue; // Skip this location if it is set to hide
                            }

                            // (For variable and simple products the option markup is nearly identical.)
                            $stock_location_quantity = get_post_meta($post->ID, "wcmlim_stock_at_{$term->term_id}", true);
                            $stock_regular_price = get_post_meta($post->ID, "wcmlim_regular_price_at_{$term->term_id}", true);
                            $stock_sale_price = get_post_meta($post->ID, "wcmlim_sale_price_at_{$term->term_id}", true);
                            if ($stock_regular_price == '' || $stock_regular_price == '0.00') {
                                $stock_regular_price = wc_price($product->get_regular_price());
                                $stock_sale_price = wc_price($product->get_sale_price());
                            }
                            if ( function_exists( 'wmc_get_price' ) ) {
                                    $stock_regular_price = wmc_get_price( $stock_regular_price );
                                    $stock_sale_price = wmc_get_price( $stock_sale_price );
                                }
                            
                            $allow_specific_location = 'on';
                                if ($allow_specific_location == 'on') {
                                    $allow_specific_location = get_post_meta($post->ID, 'wcmlim_allow_specific_location_at_' . $term->term_id, true);
                                    $allow_specific_location = empty($allow_specific_location) ? 'Yes' : $allow_specific_location;
                                } else {
                                    $allow_specific_location = 'Yes';
                                }
                            if ($product->is_type('variable')) {
                                $variation_backorder = '';
                                $isBackorderEnabled = get_post_meta($post->ID, "wcmlim_allow_backorder_at_$term->term_id", true);
                                $allow_backorder_each_location = 'on';
                                $rl = wcmlim_get_loactionaddress($term->term_id);
                                $price = ($enable_price == "on") ? "on" : "off";
                                $d_location = get_option('wcmlim_enable_default_location');
                                $selDefLoc = get_post_meta($post->ID, "wcmlim_default_location", true);
                                if ( function_exists( 'wmc_get_price' ) ) {
                                    $stock_regular_price = wmc_get_price( $stock_regular_price );
                                    $stock_sale_price = wmc_get_price( $stock_sale_price );
                                }
                                
                                if ($stock_location_quantity !== '') {
                                    if (isset($stock_location_quantity)) {
                                        if ($allow_specific_location == 'Yes') {
                                            $current_user = wp_get_current_user();
                                            $user_specific_location = is_user_logged_in() ? get_user_meta($current_user->ID, 'wcmlim_user_specific_location', true) : "No";
                                            if ($user_specific_location == $k || $user_specific_location == "No" || $user_specific_location == "-1") {
                                                ?>
                                                <option
                                                    <?php
                                                    
                                                    if (($product->backorders_allowed()) && ($isBackorderEnabled == "Yes" && $allow_backorder_each_location == "on")) {
                                                        $variation_backorder = 'yes';
                                                    } else {
                                                        $variation_backorder = 'no';
                                                    }
                                                    ?>
                                                    <?php echo isset($selected_location_termid) && $selected_location_termid == $k ? 'selected' : ''; ?>
                                                    value="<?php echo $k; ?>"
                                                    data-lc-backorder="<?php echo $variation_backorder; ?>"
                                                    data-lc-termid ="<?php echo $term->term_id; ?>"
                                                    data-lc-qty="<?php echo ($stock_location_quantity); ?>"
                                                    data-lc-address="<?php echo esc_attr(base64_encode($rl)); ?>"
                                                    data-lc-regular-price="<?php echo esc_attr(($stock_regular_price)); ?>"
                                                    data-lc-sale-price="<?php echo esc_attr(($stock_sale_price)); ?>"
                                                    class="<?php echo 'wclimloc_' . $term->slug; ?>"
                                                    style="<?php echo ($allow_specific_location == 'No' ? 'display:none' : ''); ?>"
                                                    
                                                >
                                                    <?php
                                                    if ($product->backorders_allowed()) {
                                                        if (($isBackorderEnabled == "yes" || $isBackorderEnabled == "Yes") && $allow_backorder_each_location == "on") {
                                                            echo ($preffLocation == $k) ? ucfirst($term->name) : ucfirst($term->name) . ' - ' . __($backorderbuttontext, 'woocommerce');
                                                        } else if (empty($stock_location_quantity) || $stock_location_quantity < 0) {
                                                            echo ucfirst($term->name) . ' - ' . __($soldout_btntxt, 'wcmlim');
                                                        } else {
                                                            echo ucfirst($term->name) . ' - ' . __($instock_btntxt, 'wcmlim');
                                                        }
                                                    } else {
                                                        if (empty($stock_location_quantity) || $stock_location_quantity < 0) {
                                                            echo ucfirst($term->name) . ' - ' . __($soldout_btntxt, 'wcmlim');
                                                        } else {
                                                            echo ucfirst($term->name) . ' - ' . __($instock_btntxt, 'wcmlim');
                                                        }
                                                    }
                                                    ?>
                                                </option>
                                                <?php
                                            }
                                        }
                                    }
                                } else {
                                    if (!$product->managing_stock() && $product->is_in_stock()) {
                                        $stock_status = $product->get_stock_status();
                                        $optionname = ($stock_status == "instock")
                                            ? ucfirst($term->name) . ' - ' . __($instock_btntxt, 'wcmlim')
                                            : (($stock_status == "outofstock")
                                                ? ucfirst($term->name) . ' - ' . __($soldout_btntxt, 'wcmlim')
                                                : ucfirst($term->name) . ' - ' . __($backorderbuttontext, 'woocommerce'));
                                        ?>
                                        <option 
                                                <?php /* Remove this condition to prevent auto-selection: if ((string)$preffLocation === (string)$k) echo "selected='selected'"; */ ?>
                                                class="<?php echo 'wclimloc_' . $term->slug; ?>"
                                                <?php echo isset($selected_location_termid) && $selected_location_termid == $k ? 'selected' : ''; ?>
                                                value="<?php echo $k; ?>"
                                                data-lc-address="<?php esc_attr_e(base64_encode($rl)); ?>"
                                                data-lc-regular-price="<?php esc_attr_e(wc_price($stock_regular_price)); ?>"
                                                data-lc-sale-price="<?php echo (!empty($stock_sale_price)) ? esc_attr(wc_price($stock_sale_price)) : __("undefined", "wcmlim"); ?>"
                                                data-lc-stockstatus="<?php echo $stock_status; ?>"
                                                style="<?php echo ($allow_specific_location == 'No' ? 'display:none' : ''); ?>"
                                                
                                        >
                                            <?php echo $optionname; ?>
                                        </option>
                                        <?php
                                    }
                                }

                            } else {
                                // For simple products.
                                $productOnBackorder = $product->backorders_allowed();
                                $product_id = $product->get_id();
                                $manage_stock = get_post_meta($product_id, '_manage_stock', true);
                                $stock_status = get_post_meta($product_id, '_stock_status', true);
                                $stock_location_quantity = get_post_meta($product_id, "wcmlim_stock_at_{$term->term_id}", true);
                                $stock_regular_price = get_post_meta($product_id, "wcmlim_regular_price_at_{$term->term_id}", true);
                                $rl = wcmlim_get_loactionaddress($term->term_id);
                                $wcmlim_hide_out_of_stock_location = get_option('wcmlim_hide_out_of_stock_location');
                                if ( function_exists( 'wmc_get_price' ) ) {
                                    $stock_regular_price = wmc_get_price( $stock_regular_price );
                                    $stock_sale_price = wmc_get_price( $stock_sale_price );
                                }
                                if (($wcmlim_hide_out_of_stock_location !== 'on' && $stock_location_quantity !== '') || ($stock_location_quantity !== '' && $wcmlim_hide_out_of_stock_location == 'on' && $stock_location_quantity > 0)) {
                                    ?>
                                    <option
                                        <?php
                                        
                                        $variation_backorder = ($productOnBackorder && get_post_meta($product_id, "wcmlim_allow_backorder_at_$term->term_id", true) == "Yes") ? 'yes' : 'no';
                                        ?>
                                         <?php echo isset($selected_location_termid) && $selected_location_termid == $k ? 'selected' : ''; ?>
                                        value="<?php echo $k; ?>"
                                        data-lc-backorder="<?php echo $variation_backorder; ?>"
                                        data-lc-termid ="<?php echo $term->term_id; ?>"
                                        data-lc-qty="<?php echo esc_attr((($stock_location_quantity))); ?>"
                                        data-lc-address="<?php echo esc_attr(base64_encode($rl)); ?>"
                                        data-lc-regular-price="<?php echo esc_attr(($stock_regular_price)); ?>"
                                         data-lc-sale-price="<?php echo esc_attr(($stock_sale_price)); ?>"
                                        class="<?php echo 'wclimloc_' . $term->slug; ?>"
                                        style="<?php echo ($allow_specific_location == 'No' ? 'display:none' : ''); ?>"
                                       
                                    >   
                                        <?php
                                        if ($productOnBackorder) {
                                            if (get_post_meta($product_id, "wcmlim_allow_backorder_at_$term->term_id", true) == "Yes") {
                                                echo ucfirst($term->name) . ' - ' . __($backorderbuttontext, 'woocommerce');
                                            } else if ($stock_location_quantity < 0) {
                                                echo ucfirst($term->name) . ' - ' . __($soldout_btntxt, 'wcmlim');
                                            } else {
                                                echo ucfirst($term->name) . ' - ' . __($instock_btntxt, 'wcmlim');
                                            }
                                        } else {
                                            if ($stock_location_quantity <= 0) {
                                                echo  ' ' . ucfirst($term->name) . ' - ' . __($soldout_btntxt, 'wcmlim');
                                            } else {
                                                echo  ' ' . ucfirst($term->name) . ' - ' . __($instock_btntxt, 'wcmlim');
                                                
                                            }
                                        }
                                        ?>
                                    </option>

                                    <?php                                   
                                }
                            }
                        }
                        ?>
                        <input type="hidden" id="data-lc-backorder-text" value="<?php echo $backorderbuttontext; ?>">
                    </select>
                    <!-- Start of the select view location details code -->
                    <?php
                        $locations_data = array();

                        if ($preffLocation !== '') {
                            foreach ($filtered_terms as $k => $term) {
                                /**
                                 * Retrieve location index by term ID
                                 * 
                                 * This code fetches all location terms and then identifies the array key (index)
                                 * of the specific location that matches the current term ID. This ensures we 
                                 * maintain the correct reference index for the location term even when term order
                                 * or values have been modified in the database, which could otherwise affect results.
                                 * 
                                 * @since 4.2.1
                                 */
                                $locations = get_terms([
                                    'taxonomy' => 'locations',
                                    'hide_empty' => false,
                                ]);

                                // Match current term with location to set key
                                foreach ($locations as $location_key => $location) {
                                    if ($location->term_id == $term->term_id) {
                                        $k = $location_key;
                                        break;
                                    }
                                }
                                $hide_ind_location = get_term_meta($term->term_id, 'wcmlim_location_hide', true);
                                if($hide_ind_location == "yes") {
                                    continue; // Skip this location if it is set to hide
                                }
                                $data = array();
                                // loop through the field order and display the location information
                                foreach ($field_order as $field) {
                                    if ($field === 'postcode') {
                                        $field = 'postal_code';
                                    }
                                    $field_value = get_term_meta($term->term_id, 'wcmlim_' . $field, true);
                                    if ($field_value) {
                                        $data[$field] = $field_value;
                                    }
                                }
                                $locations_data[$k] = $data;
                            }
                        }

                        //show the div when the location is selected
                        if($preffLocation !== ''){
                        ?>
                            <div id="locationDetails" style="display: <?php echo ($preffLocation !== '' ? 'block' : 'none'); ?>;">
                        <?php
                        if ($preffLocation !== '' && isset($locations_data[$preffLocation])) {
                            foreach ($locations_data[$preffLocation] as $field => $value) {
                                //check postal code and replace underscore with space
                                ?>
                                <div>
                                <i class="dashicons dashicons-admin-home"></i>
                                    <?php
                                        if ($field === 'postcode') {
                                            echo '<span class="multiloca_postal_code">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'address') {
                                            echo '<span class="multiloca_address"> ' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'country') {
                                            echo '<span class="multiloca_country">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'street_number') {
                                            echo '<span class="multiloca_street_number">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'route') {
                                            echo '<span class="multiloca_route">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'locality') {
                                            echo '<span class="multiloca_locality">' . esc_html($value) . '</span><br>';
                                        }
                                    ?>
                                </div>
                                <div>
                                <i class="dashicons dashicons-email"></i>
                                    <?php
                                        if ($field === 'email') {
                                            echo '<span class="multiloca_email">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'phone') {
                                            echo '<span class="multiloca_phone">' . esc_html($value) . '</span><br>';
                                        }
                                    ?>
                                </div>
                                <div>
                                <i class="dashicons dashicons-clock"></i>
                                    <?php
                                        if ($field === 'start_time') {
                                            echo '<span class="multiloca_start_time">' . esc_html($value) . '</span>, ';
                                        }
                                        if ($field === 'end_time') {
                                            echo '<span class="multiloca_end_time">' . esc_html($value) . '</span><br>';
                                        }
                                    ?>
                                </div>
                                <?php
                               
                                
                                
                                

                            }
                        }
                        ?>
                        </div><?php } ?>

                        <!-- JavaScript to update the details when the location is changed -->
                        <script>
                            var locationData = <?php echo json_encode($locations_data); ?>;

                            function updateLocationDetails(locationKey) {
                                var detailsDiv = document.getElementById('locationDetails');
                                // If no valid location is selected, hide the div and exit.
                                if (!locationKey) {
                                    detailsDiv.innerHTML = '';
                                    detailsDiv.style.display = 'none';
                                    return;
                                } else {
                                    detailsDiv.style.display = 'block';
                                }

                                var data = locationData[locationKey];
                                var html = '';

                                if (data) {
                                    // Initialize main container div
                                    html += '<div>';

                                    // Group address fields together
                                    var addressFields = [];
                                    if (data['address']) {
                                        addressFields.push(data['address']);
                                    }
                                    if (data['street_number']) {
                                        addressFields.push(data['street_number']);
                                    }
                                    if (data['route']) {
                                        addressFields.push(data['route']);
                                    }
                                    if (data['locality']) {
                                        addressFields.push(data['locality']);
                                    }
                                    if (data['postal_code']) {
                                        addressFields.push(data['postal_code']);
                                    }
                                    if (data['country']) {
                                        addressFields.push(data['country']);
                                    }
                                    if (addressFields.length > 0) {
                                        html += '<div class="address-fields"><span class="dashicons dashicons-admin-home" style="vertical-align: sub;"></span>' + addressFields.join(', ') + '</div>';
                                    }

                                    // Group email and phone together
                                    var contactFields = [];
                                    if (data['email']) {
                                        contactFields.push(data['email']);
                                    }
                                    if (data['phone']) {
                                        contactFields.push(data['phone']);
                                    }
                                    if (contactFields.length > 0) {
                                        html += '<div class="contact-fields"><span class="dashicons dashicons-email" style="vertical-align: sub;"></span>' + contactFields.join(' , ') + '</div>';
                                    }

                                    // Group start and end time together
                                    var timingFields = [];
                                    if (data['start_time'] && data['end_time']) {
                                        timingFields.push(data['start_time'] + ' - ' + data['end_time']);
                                    } else if (data['start_time']) {
                                        timingFields.push(data['start_time']);
                                    } else if (data['end_time']) {
                                        timingFields.push(data['end_time']);
                                    }
                                    if (timingFields.length > 0) {
                                        html += '<div class="timing-fields"><span class="dashicons dashicons-clock" style="vertical-align: sub;"></span>' + timingFields.join(' , ') + '</div>';
                                    }

                                    // Close the main container div
                                    html += '</div>';
                                }

                                detailsDiv.innerHTML = html;
                            }



                            document.getElementById('select_location').addEventListener('change', function() {
                                updateLocationDetails(this.value);
                            });

                            // Initialize details on page load.
                            updateLocationDetails(document.getElementById('select_location').value);
                        </script>
                    <!-- End of the select view location details code -->
                    
                    <?php if ($isLocationsGroup == null || $isLocationsGroup == false) { ?>
                        <div class="wcmlradio_box rselect_location"></div>
                        <div class="wc_scrolldown">
                            <p>Scroll Location</p>
                            <i class="fas fa-chevron-circle-down"></i>												
                        </div>
                    <?php } ?>
                </div><!-- .loc_dd -->
                <?php
                // Replace this line:
                // if ($preffLocation) {
                if ($preffLocation !== '') {
                    foreach ($filtered_terms as $k => $term) {

                        /**
                         * Retrieve location index by term ID
                         * 
                         * This code fetches all location terms and then identifies the array key (index)
                         * of the specific location that matches the current term ID. This ensures we 
                         * maintain the correct reference index for the location term even when term order
                         * or values have been modified in the database, which could otherwise affect results.
                         * 
                         * @since 4.2.1
                         */
                        $locations = get_terms([
                            'taxonomy' => 'locations',
                            'hide_empty' => false,
                        ]);
                        // Match current term with location to set key
                        foreach ($locations as $location_key => $location) {
                            if ($location->term_id == $term->term_id) {
                                $k = $location_key;
                                break;
                            }
                        }
                        $hide_ind_location = get_term_meta($term->term_id, 'wcmlim_location_hide', true);
                        if($hide_ind_location == "yes") {
                            continue; // Skip this location if it is set to hide
                        }
                        $stock_location_quantity = get_post_meta($post->ID, "wcmlim_stock_at_{$term->term_id}", true);
                        if (isset($stock_location_quantity) && (string)$preffLocation === (string)$k) {
                            if ($stock_display_format == "no_amount") {
                                echo '<p id="globMsg">' . __($instock_btntxt, 'wcmlim') . '</p>';
                            } elseif (empty($stock_display_format)) {
                                // NEW: Replace raw stock count with threshold text if enabled.
                                $enable_threshold = get_option('wcmlim_enable_location_thresholds');
                                if ($enable_threshold == "on") {
                                    $thresholds = maybe_unserialize(get_option('wcmlim_location_thresholds'));
                                    $display_text = $stock_location_quantity;
                                    if (is_array($thresholds)) {
                                        foreach ($thresholds as $threshold) {
                                            if ($stock_location_quantity >= $threshold['min'] && $stock_location_quantity <= $threshold['max']) {
                                                $display_text = $threshold['text'];
                                                break;
                                            }
                                        }
                                    }
                                } else {
                                    $display_text = $stock_location_quantity;
                                }
                                echo '<p id="globMsg"><b>' . $display_text . ' </b></p>';
                            }
                        }
                    }
                }
                ?>
            </div><!-- .Wcmlim_prefloc_box -->
            <?php
            $geolocation = get_option('wcmlim_geo_location');
            if ($geolocation == "on") :
            ?>
                <div class="postcode-checker">
                    <p class="postcode-checker-title">
                        <strong>
                            <?php echo $txt_nearest ? $txt_nearest : __('Check your nearest stock location :', 'wcmlim'); ?>
                        </strong>
                    </p>
                    <div class="postcode-checker-div postcode-checker-div-show">
                        <?php
                        $globpin = getLocation('wcmlim_nearby_location') ?: "";
                        $loc_dis_un = get_option('wcmlim_location_distance');
                        ?>
                        <input type="text" placeholder="<?php _e('Enter Location', 'wcmlim'); ?>" class="class_post_code" name="post_code" value="<?php esc_html_e(getLocation('wcmlim_nearby_location') ?: ""); ?>" id="elementId">
                        <button class="button" type="button" id="submit_postcode_product" style="line-height: 1.4;border: 0;">
                            <i class="fa fa-map-marker-alt"></i>
                            <?php echo $oncheck_btntxt ? $oncheck_btntxt : __('Check', 'wcmlim'); ?>
                        </button>
                        <input type="hidden" name="global_postal_check" id="global-postal-check" value="true">
                        <input type="hidden" name="product_postal_location" id="product-postal-location" value="<?php esc_html_e($globpin); ?>">
                        <input type="hidden" name="product_location_distance" id="product-location-distance" value="<?php esc_html_e($loc_dis_un); ?>">
                    </div>
                    <div class="search_rep" style="display: inline-flex;">
                        <div class="postcode-checker-response"></div>
                        <a class="postcode-checker-change postcode-checker-change-show" href="#" data-wpzc-form-open="" style="display: none;">
                            <i class="fa fa-edit" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="Wcmlim_loc_label">
                        <div class="Wcmlim_locadd">
                            <div class="selected_location_detail"></div>
                            <div class="postcode-location-distance"></div>
                        </div>
                        <div class="Wcmlim_locstock"></div>
                    </div>
                    <?php if ($showNxtLoc == "on") { ?>
                        <div class="Wcmlim_nextloc_label">
                            <div class="Wcmlim_nextlocadd">
                                <div class="next_closest_location_detail"></div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="Wcmlim_messageerror"></div>
                </div>
            <?php
            endif;
            ?>
            <input type="hidden" id="lc_regular_price" name="location_regular_price" value="">
            <input type="hidden" id="lc_sale_price" name="location_sale_price" value="">
            <input type="hidden" id="lc_qty" name="location_qty" value="">
            <input type="hidden" id="wcstdis_format" name="stock_display_format" value="<?php esc_attr_e($stock_display_format); ?>">
            <input type="hidden" id="productOrgPrice" name="product_original_price" value="<?php esc_attr_e($product->get_price_html()); ?>">
            <?php $backorderAllowed = $product->backorders_allowed(); ?>
<input type="hidden" id="backorderAllowed" name="backorder_allowed" value="<?php echo esc_attr($backorderAllowed); ?>">

        </div>
    </div>
</div>

<style>
    .wcmlim-select_view .dashicons {
        width: 24px;
        height: 24px;
        font-size: 18px;
        display: inline;
        line-height: unset;
    }
    .Wcmlim_box_wrapper {
        margin-bottom: 30px;
    }
</style>

<script>
// Select view functionality has been moved to views.js in the setupSelectView() function
// Keeping this script block for PHP variable output

// Output the location data for views.js to use
var allLocationsData = <?php echo json_encode($locations_data ?? []); ?>;
var wcmlim_selectview_is_variable = <?php echo json_encode($product->is_type('variable')); ?>;
</script>

<!-- Ensure there's always a placeholder for location details -->
<div id="locationDetails" style="display: none;"></div>

<?php
// Make sure views.js is loaded
wp_enqueue_script('wcmlim-views-script');


