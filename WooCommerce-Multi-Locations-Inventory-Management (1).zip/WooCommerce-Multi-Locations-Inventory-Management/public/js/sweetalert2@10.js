!(function (t, e) {
    "object" == typeof exports && "undefined" != typeof module ? (module.exports = e()) : "function" == typeof define && define.amd ? define(e) : ((t = t || self).Sweetalert2 = e());
})(this, function () {
    "use strict";
    function r(t) {
        return (r =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (t) {
                      return typeof t;
                  }
                : function (t) {
                      return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                  })(t);
    }
    function a(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
    }
    function o(t, e) {
        for (var n = 0; n < e.length; n++) {
            var o = e[n];
            (o.enumerable = o.enumerable || !1), (o.configurable = !0), "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o);
        }
    }
    function s(t, e, n) {
        return e && o(t.prototype, e), n && o(t, n), t;
    }
    function c() {
        return (c =
            Object.assign ||
            function (t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n,
                        o = arguments[e];
                    for (n in o) Object.prototype.hasOwnProperty.call(o, n) && (t[n] = o[n]);
                }
                return t;
            }).apply(this, arguments);
    }
    function u(t) {
        return (u = Object.setPrototypeOf
            ? Object.getPrototypeOf
            : function (t) {
                  return t.__proto__ || Object.getPrototypeOf(t);
              })(t);
    }
    function l(t, e) {
        return (l =
            Object.setPrototypeOf ||
            function (t, e) {
                return (t.__proto__ = e), t;
            })(t, e);
    }
    function d() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Date.prototype.toString.call(Reflect.construct(Date, [], function () {})), !0;
        } catch (t) {
            return !1;
        }
    }
    function i(t, e, n) {
        return (i = d()
            ? Reflect.construct
            : function (t, e, n) {
                  var o = [null];
                  o.push.apply(o, e);
                  o = new (Function.bind.apply(t, o))();
                  return n && l(o, n.prototype), o;
              }).apply(null, arguments);
    }
    function p(t, e) {
        return !e || ("object" != typeof e && "function" != typeof e)
            ? (function (t) {
                  if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                  return t;
              })(t)
            : e;
    }
    function f(t, e, n) {
        return (f =
            "undefined" != typeof Reflect && Reflect.get
                ? Reflect.get
                : function (t, e, n) {
                      t = (function (t, e) {
                          for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = u(t)); );
                          return t;
                      })(t, e);
                      if (t) {
                          e = Object.getOwnPropertyDescriptor(t, e);
                          return e.get ? e.get.call(n) : e.value;
                      }
                  })(t, e, n || t);
    }
    function m(e) {
        return Object.keys(e).map(function (t) {
            return e[t];
        });
    }
    function h(t) {
        return Array.prototype.slice.call(t);
    }
    function g(t, e) {
        (e = '"'.concat(t, '" is deprecated and will be removed in the next major release. Please use "').concat(e, '" instead.')), -1 === K.indexOf(e) && (K.push(e), z(e));
    }
    function v(t) {
        return t && "function" == typeof t.toPromise;
    }
    function y(t) {
        return v(t) ? t.toPromise() : Promise.resolve(t);
    }
    function b(t) {
        return t && Promise.resolve(t) === t;
    }
    function w(t) {
        return t instanceof Element || ("object" === r((t = t)) && t.jquery);
    }
    function C() {
        return document.body.querySelector(".".concat($.container));
    }
    function k(t) {
        var e = C();
        return e ? e.querySelector(t) : null;
    }
    function t(t) {
        return k(".".concat(t));
    }
    function x() {
        return t($.popup);
    }
    function n() {
        var t = x();
        return h(t.querySelectorAll(".".concat($.icon)));
    }
    function B() {
        var t = n().filter(function (t) {
            return bt(t);
        });
        return t.length ? t[0] : null;
    }
    function P() {
        return t($.title);
    }
    function A() {
        return t($.content);
    }
    function E() {
        return t($.image);
    }
    function O() {
        return t($["progress-steps"]);
    }
    function S() {
        return t($["validation-message"]);
    }
    function T() {
        return k(".".concat($.actions, " .").concat($.confirm));
    }
    function L() {
        return k(".".concat($.actions, " .").concat($.deny));
    }
    function D() {
        return k(".".concat($.loader));
    }
    function I() {
        return k(".".concat($.actions, " .").concat($.cancel));
    }
    function q() {
        return t($.actions);
    }
    function j() {
        return t($.header);
    }
    function M() {
        return t($.footer);
    }
    function V() {
        return t($["timer-progress-bar"]);
    }
    function H() {
        return t($.close);
    }
    function R() {
        var t = h(x().querySelectorAll('[tabindex]:not([tabindex="-1"]):not([tabindex="0"])')).sort(function (t, e) {
                return (t = parseInt(t.getAttribute("tabindex"))), (e = parseInt(e.getAttribute("tabindex"))) < t ? 1 : t < e ? -1 : 0;
            }),
            e = h(
                x().querySelectorAll(
                    '\n  a[href],\n  area[href],\n  input:not([disabled]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls],\n  summary\n'
                )
            ).filter(function (t) {
                return "-1" !== t.getAttribute("tabindex");
            });
        return (function (t) {
            for (var e = [], n = 0; n < t.length; n++) -1 === e.indexOf(t[n]) && e.push(t[n]);
            return e;
        })(t.concat(e)).filter(function (t) {
            return bt(t);
        });
    }
    function N() {
        return !X() && !document.body.classList.contains($["no-backdrop"]);
    }
    function U(e, t) {
        (e.textContent = ""),
            t &&
                ((t = new DOMParser().parseFromString(t, "text/html")),
                h(t.querySelector("head").childNodes).forEach(function (t) {
                    e.appendChild(t);
                }),
                h(t.querySelector("body").childNodes).forEach(function (t) {
                    e.appendChild(t);
                }));
    }
    function _(t, e) {
        if (e) {
            for (var n = e.split(/\s+/), o = 0; o < n.length; o++) if (!t.classList.contains(n[o])) return;
            return 1;
        }
    }
    function F(t, e, n) {
        var o, i;
        if (
            ((i = e),
            h((o = t).classList).forEach(function (t) {
                -1 === m($).indexOf(t) && -1 === m(J).indexOf(t) && -1 === m(i.showClass).indexOf(t) && o.classList.remove(t);
            }),
            e.customClass && e.customClass[n])
        ) {
            if ("string" != typeof e.customClass[n] && !e.customClass[n].forEach) return z("Invalid type of customClass.".concat(n, '! Expected string or iterable object, got "').concat(r(e.customClass[n]), '"'));
            gt(t, e.customClass[n]);
        }
    }
    var e = "SweetAlert2:",
        z = function (t) {
            console.warn("".concat(e, " ").concat(t));
        },
        W = function (t) {
            console.error("".concat(e, " ").concat(t));
        },
        K = [],
        Y = function (t) {
            return "function" == typeof t ? t() : t;
        },
        Z = Object.freeze({ cancel: "cancel", backdrop: "backdrop", close: "close", esc: "esc", timer: "timer" }),
        Q = function (t) {
            var e,
                n = {};
            for (e in t) n[t[e]] = "swal2-" + t[e];
            return n;
        },
        $ = Q([
            "container",
            "shown",
            "height-auto",
            "iosfix",
            "popup",
            "modal",
            "no-backdrop",
            "no-transition",
            "toast",
            "toast-shown",
            "toast-column",
            "show",
            "hide",
            "close",
            "title",
            "header",
            "content",
            "html-container",
            "actions",
            "confirm",
            "deny",
            "cancel",
            "footer",
            "icon",
            "icon-content",
            "image",
            "input",
            "file",
            "range",
            "select",
            "radio",
            "checkbox",
            "label",
            "textarea",
            "inputerror",
            "input-label",
            "validation-message",
            "progress-steps",
            "active-progress-step",
            "progress-step",
            "progress-step-line",
            "loader",
            "loading",
            "styled",
            "top",
            "top-start",
            "top-end",
            "top-left",
            "top-right",
            "center",
            "center-start",
            "center-end",
            "center-left",
            "center-right",
            "bottom",
            "bottom-start",
            "bottom-end",
            "bottom-left",
            "bottom-right",
            "grow-row",
            "grow-column",
            "grow-fullscreen",
            "rtl",
            "timer-progress-bar",
            "timer-progress-bar-container",
            "scrollbar-measure",
            "icon-success",
            "icon-warning",
            "icon-info",
            "icon-question",
            "icon-error",
        ]),
        J = Q(["success", "warning", "info", "question", "error"]),
        X = function () {
            return document.body.classList.contains($["toast-shown"]);
        },
        G = { previousBodyPadding: null };
    function tt(t, e) {
        if (!e) return null;
        switch (e) {
            case "select":
            case "textarea":
            case "file":
                return yt(t, $[e]);
            case "checkbox":
                return t.querySelector(".".concat($.checkbox, " input"));
            case "radio":
                return t.querySelector(".".concat($.radio, " input:checked")) || t.querySelector(".".concat($.radio, " input:first-child"));
            case "range":
                return t.querySelector(".".concat($.range, " input"));
            default:
                return yt(t, $.input);
        }
    }
    function et(t) {
        var e;
        t.focus(), "file" !== t.type && ((e = t.value), (t.value = ""), (t.value = e));
    }
    function nt(t, e, n) {
        t &&
            e &&
            ("string" == typeof e && (e = e.split(/\s+/).filter(Boolean)),
            e.forEach(function (e) {
                t.forEach
                    ? t.forEach(function (t) {
                          n ? t.classList.add(e) : t.classList.remove(e);
                      })
                    : n
                    ? t.classList.add(e)
                    : t.classList.remove(e);
            }));
    }
    function ot(t, e, n) {
        n || 0 === parseInt(n) ? (t.style[e] = "number" == typeof n ? "".concat(n, "px") : n) : t.style.removeProperty(e);
    }
    function it(t, e) {
        (e = 1 < arguments.length && void 0 !== e ? e : "flex"), (t.style.display = e);
    }
    function rt(t) {
        t.style.display = "none";
    }
    function at(t, e, n, o) {
        (e = t.querySelector(e)) && (e.style[n] = o);
    }
    function st(t, e, n) {
        e ? it(t, n) : rt(t);
    }
    function ct(t) {
        return !!(t.scrollHeight > t.clientHeight);
    }
    function ut(t) {
        var e = window.getComputedStyle(t),
            t = parseFloat(e.getPropertyValue("animation-duration") || "0"),
            e = parseFloat(e.getPropertyValue("transition-duration") || "0");
        return 0 < t || 0 < e;
    }
    function lt(t, e) {
        var e = 1 < arguments.length && void 0 !== e && e,
            n = V();
        bt(n) &&
            (e && ((n.style.transition = "none"), (n.style.width = "100%")),
            setTimeout(function () {
                (n.style.transition = "width ".concat(t / 1e3, "s linear")), (n.style.width = "0%");
            }, 10));
    }
    function dt() {
        return "undefined" == typeof window || "undefined" == typeof document;
    }
    function pt(t) {
        wn.isVisible() && ht !== t.target.value && wn.resetValidationMessage(), (ht = t.target.value);
    }
    function ft(t, e) {
        t instanceof HTMLElement ? e.appendChild(t) : "object" === r(t) ? kt(t, e) : t && U(e, t);
    }
    function mt(t, e) {
        var n = q(),
            o = D(),
            i = T(),
            r = L(),
            a = I();
        e.showConfirmButton || e.showDenyButton || e.showCancelButton || rt(n),
            F(n, e, "actions"),
            Pt(i, "confirm", e),
            Pt(r, "deny", e),
            Pt(a, "cancel", e),
            (function (t, e, n, o) {
                if (!o.buttonsStyling) return vt([t, e, n], $.styled);
                gt([t, e, n], $.styled), o.confirmButtonColor && (t.style.backgroundColor = o.confirmButtonColor);
                o.denyButtonColor && (e.style.backgroundColor = o.denyButtonColor);
                o.cancelButtonColor && (n.style.backgroundColor = o.cancelButtonColor);
            })(i, r, a, e),
            e.reverseButtons && (n.insertBefore(a, o), n.insertBefore(r, o), n.insertBefore(i, o)),
            (o.innerHTML = e.loaderHtml),
            F(o, e, "loader");
    }
    var ht,
        gt = function (t, e) {
            nt(t, e, !0);
        },
        vt = function (t, e) {
            nt(t, e, !1);
        },
        yt = function (t, e) {
            for (var n = 0; n < t.childNodes.length; n++) if (_(t.childNodes[n], e)) return t.childNodes[n];
        },
        bt = function (t) {
            return !(!t || !(t.offsetWidth || t.offsetHeight || t.getClientRects().length));
        },
        wt = '\n <div aria-labelledby="'
            .concat($.title, '" aria-describedby="')
            .concat($.content, '" class="')
            .concat($.popup, '" tabindex="-1">\n   <div class="')
            .concat($.header, '">\n     <ul class="')
            .concat($["progress-steps"], '"></ul>\n     <div class="')
            .concat($.icon, " ")
            .concat(J.error, '"></div>\n     <div class="')
            .concat($.icon, " ")
            .concat(J.question, '"></div>\n     <div class="')
            .concat($.icon, " ")
            .concat(J.warning, '"></div>\n     <div class="')
            .concat($.icon, " ")
            .concat(J.info, '"></div>\n     <div class="')
            .concat($.icon, " ")
            .concat(J.success, '"></div>\n     <img class="')
            .concat($.image, '" />\n     <h2 class="')
            .concat($.title, '" id="')
            .concat($.title, '"></h2>\n     <button type="button" class="')
            .concat($.close, '"></button>\n   </div>\n   <div class="')
            .concat($.content, '">\n     <div id="')
            .concat($.content, '" class="')
            .concat($["html-container"], '"></div>\n     <input class="')
            .concat($.input, '" />\n     <input type="file" class="')
            .concat($.file, '" />\n     <div class="')
            .concat($.range, '">\n       <input type="range" />\n       <output></output>\n     </div>\n     <select class="')
            .concat($.select, '"></select>\n     <div class="')
            .concat($.radio, '"></div>\n     <label for="')
            .concat($.checkbox, '" class="')
            .concat($.checkbox, '">\n       <input type="checkbox" />\n       <span class="')
            .concat($.label, '"></span>\n     </label>\n     <textarea class="')
            .concat($.textarea, '"></textarea>\n     <div class="')
            .concat($["validation-message"], '" id="')
            .concat($["validation-message"], '"></div>\n   </div>\n   <div class="')
            .concat($.actions, '">\n     <div class="')
            .concat($.loader, '"></div>\n     <button type="button" class="')
            .concat($.confirm, '"></button>\n     <button type="button" class="')
            .concat($.deny, '"></button>\n     <button type="button" class="')
            .concat($.cancel, '"></button>\n   </div>\n   <div class="')
            .concat($.footer, '"></div>\n   <div class="')
            .concat($["timer-progress-bar-container"], '">\n     <div class="')
            .concat($["timer-progress-bar"], '"></div>\n   </div>\n </div>\n')
            .replace(/(^|\n)\s*/g, ""),
        Ct = function (t) {
            var e,
                n,
                o,
                i,
                r,
                a = !!(i = C()) && (i.parentNode.removeChild(i), vt([document.documentElement, document.body], [$["no-backdrop"], $["toast-shown"], $["has-column"]]), !0);
            dt()
                ? W("SweetAlert2 requires document to initialize")
                : (((r = document.createElement("div")).className = $.container),
                  a && gt(r, $["no-transition"]),
                  U(r, wt),
                  (i = "string" == typeof (e = t.target) ? document.querySelector(e) : e).appendChild(r),
                  (a = t),
                  (e = x()).setAttribute("role", a.toast ? "alert" : "dialog"),
                  e.setAttribute("aria-live", a.toast ? "polite" : "assertive"),
                  a.toast || e.setAttribute("aria-modal", "true"),
                  (r = i),
                  "rtl" === window.getComputedStyle(r).direction && gt(C(), $.rtl),
                  (t = A()),
                  (a = yt(t, $.input)),
                  (e = yt(t, $.file)),
                  (n = t.querySelector(".".concat($.range, " input"))),
                  (o = t.querySelector(".".concat($.range, " output"))),
                  (i = yt(t, $.select)),
                  (r = t.querySelector(".".concat($.checkbox, " input"))),
                  (t = yt(t, $.textarea)),
                  (a.oninput = pt),
                  (e.onchange = pt),
                  (i.onchange = pt),
                  (r.onchange = pt),
                  (t.oninput = pt),
                  (n.oninput = function (t) {
                      pt(t), (o.value = n.value);
                  }),
                  (n.onchange = function (t) {
                      pt(t), (n.nextSibling.value = n.value);
                  }));
        },
        kt = function (t, e) {
            t.jquery ? xt(e, t) : U(e, t.toString());
        },
        xt = function (t, e) {
            if (((t.textContent = ""), 0 in e)) for (var n = 0; n in e; n++) t.appendChild(e[n].cloneNode(!0));
            else t.appendChild(e.cloneNode(!0));
        },
        Bt = (function () {
            if (dt()) return !1;
            var t,
                e = document.createElement("div"),
                n = { WebkitAnimation: "webkitAnimationEnd", OAnimation: "oAnimationEnd oanimationend", animation: "animationend" };
            for (t in n) if (Object.prototype.hasOwnProperty.call(n, t) && void 0 !== e.style[t]) return n[t];
            return !1;
        })();
    function Pt(t, e, n) {
        var o;
        st(t, n["show".concat((o = e).charAt(0).toUpperCase() + o.slice(1), "Button")], "inline-block"),
            U(t, n["".concat(e, "ButtonText")]),
            t.setAttribute("aria-label", n["".concat(e, "ButtonAriaLabel")]),
            (t.className = $[e]),
            F(t, n, "".concat(e, "Button")),
            gt(t, n["".concat(e, "ButtonClass")]);
    }
    function At(t, e) {
        var n,
            o,
            i = C();
        i &&
            ((o = i),
            "string" == typeof (n = e.backdrop) ? (o.style.background = n) : n || gt([document.documentElement, document.body], $["no-backdrop"]),
            !e.backdrop && e.allowOutsideClick && z('"allowOutsideClick" parameter requires `backdrop` parameter to be set to `true`'),
            (o = i),
            (n = e.position) in $ ? gt(o, $[n]) : (z('The "position" parameter is not valid, defaulting to "center"'), gt(o, $.center)),
            (n = i),
            !(o = e.grow) || "string" != typeof o || ((o = "grow-".concat(o)) in $ && gt(n, $[o])),
            F(i, e, "container"),
            (e = document.body.getAttribute("data-swal2-queue-step")) && (i.setAttribute("data-queue-step", e), document.body.removeAttribute("data-swal2-queue-step")));
    }
    function Et(t, e) {
        (t.placeholder && !e.inputPlaceholder) || (t.placeholder = e.inputPlaceholder);
    }
    function Ot(t, e, n) {
        var o, i;
        n.inputLabel && ((t.id = $.input), (o = document.createElement("label")), (i = $["input-label"]), o.setAttribute("for", t.id), (o.className = i), (o.innerText = n.inputLabel), e.insertAdjacentElement("beforebegin", o));
    }
    var St = { promise: new WeakMap(), innerParams: new WeakMap(), domCache: new WeakMap() },
        Tt = ["input", "file", "range", "select", "radio", "checkbox", "textarea"],
        Lt = function (t) {
            if (!jt[t.input]) return W('Unexpected type of input! Expected "text", "email", "password", "number", "tel", "select", "radio", "checkbox", "textarea", "file" or "url", got "'.concat(t.input, '"'));
            var e = qt(t.input),
                n = jt[t.input](e, t);
            it(n),
                setTimeout(function () {
                    et(n);
                });
        },
        Dt = function (t, e) {
            var n = tt(A(), t);
            if (n)
                for (var o in (!(function (t) {
                    for (var e = 0; e < t.attributes.length; e++) {
                        var n = t.attributes[e].name;
                        -1 === ["type", "value", "style"].indexOf(n) && t.removeAttribute(n);
                    }
                })(n),
                e))
                    ("range" === t && "placeholder" === o) || n.setAttribute(o, e[o]);
        },
        It = function (t) {
            var e = qt(t.input);
            t.customClass && gt(e, t.customClass.input);
        },
        qt = function (t) {
            t = $[t] || $.input;
            return yt(A(), t);
        },
        jt = {};
    (jt.text = jt.email = jt.password = jt.number = jt.tel = jt.url = function (t, e) {
        return (
            "string" == typeof e.inputValue || "number" == typeof e.inputValue ? (t.value = e.inputValue) : b(e.inputValue) || z('Unexpected type of inputValue! Expected "string", "number" or "Promise", got "'.concat(r(e.inputValue), '"')),
            Ot(t, t, e),
            Et(t, e),
            (t.type = e.input),
            t
        );
    }),
        (jt.file = function (t, e) {
            return Ot(t, t, e), Et(t, e), t;
        }),
        (jt.range = function (t, e) {
            var n = t.querySelector("input"),
                o = t.querySelector("output");
            return (n.value = e.inputValue), (n.type = e.input), (o.value = e.inputValue), Ot(n, t, e), t;
        }),
        (jt.select = function (t, e) {
            var n;
            return (t.textContent = ""), e.inputPlaceholder && ((n = document.createElement("option")), U(n, e.inputPlaceholder), (n.value = ""), (n.disabled = !0), (n.selected = !0), t.appendChild(n)), Ot(t, t, e), t;
        }),
        (jt.radio = function (t) {
            return (t.textContent = ""), t;
        }),
        (jt.checkbox = function (t, e) {
            var n = tt(A(), "checkbox");
            (n.value = 1), (n.id = $.checkbox), (n.checked = Boolean(e.inputValue));
            n = t.querySelector("span");
            return U(n, e.inputPlaceholder), t;
        }),
        (jt.textarea = function (e, t) {
            var n, o;
            return (
                (e.value = t.inputValue),
                Et(e, t),
                Ot(e, e, t),
                "MutationObserver" in window &&
                    ((n = parseInt(window.getComputedStyle(x()).width)),
                    (o = parseInt(window.getComputedStyle(x()).paddingLeft) + parseInt(window.getComputedStyle(x()).paddingRight)),
                    new MutationObserver(function () {
                        var t = e.offsetWidth + o;
                        x().style.width = n < t ? "".concat(t, "px") : null;
                    }).observe(e, { attributes: !0, attributeFilter: ["style"] })),
                e
            );
        });
    function Mt(t, e) {
        var o,
            i,
            r,
            n = A().querySelector("#".concat($.content));
        e.html ? (ft(e.html, n), it(n, "block")) : e.text ? ((n.textContent = e.text), it(n, "block")) : rt(n),
            (t = t),
            (o = e),
            (i = A()),
            (t = St.innerParams.get(t)),
            (r = !t || o.input !== t.input),
            Tt.forEach(function (t) {
                var e = $[t],
                    n = yt(i, e);
                Dt(t, o.inputAttributes), (n.className = e), r && rt(n);
            }),
            o.input && (r && Lt(o), It(o)),
            F(A(), e, "content");
    }
    function Vt() {
        return C() && C().getAttribute("data-queue-step");
    }
    function Ht(t, o) {
        var i = O();
        if (!o.progressSteps || 0 === o.progressSteps.length) return rt(i), 0;
        it(i), (i.textContent = "");
        var r = parseInt(void 0 === o.currentProgressStep ? Vt() : o.currentProgressStep);
        r >= o.progressSteps.length && z("Invalid currentProgressStep parameter, it should be less than progressSteps.length (currentProgressStep like JS arrays starts from 0)"),
            o.progressSteps.forEach(function (t, e) {
                var n,
                    t = ((n = t), (t = document.createElement("li")), gt(t, $["progress-step"]), U(t, n), t);
                i.appendChild(t),
                    e === r && gt(t, $["active-progress-step"]),
                    e !== o.progressSteps.length - 1 && ((t = o), (e = document.createElement("li")), gt(e, $["progress-step-line"]), t.progressStepsDistance && (e.style.width = t.progressStepsDistance), (e = e), i.appendChild(e));
            });
    }
    function Rt(t, e) {
        var n = j();
        F(n, e, "header"),
            Ht(0, e),
            (function (t, e) {
                t = St.innerParams.get(t);
                t && e.icon === t.icon && B()
                    ? Ft(B(), e)
                    : (_t(),
                      e.icon &&
                          (-1 !== Object.keys(J).indexOf(e.icon)
                              ? ((t = k(".".concat($.icon, ".").concat(J[e.icon]))), it(t), Wt(t, e), Ft(t, e), gt(t, e.showClass.icon))
                              : W('Unknown icon! Expected "success", "error", "warning", "info" or "question", got "'.concat(e.icon, '"'))));
            })(t, e),
            (function (t) {
                var e = E();
                if (!t.imageUrl) return rt(e);
                it(e, ""), e.setAttribute("src", t.imageUrl), e.setAttribute("alt", t.imageAlt), ot(e, "width", t.imageWidth), ot(e, "height", t.imageHeight), (e.className = $.image), F(e, t, "image");
            })(e),
            (n = e),
            (t = P()),
            st(t, n.title || n.titleText),
            n.title && ft(n.title, t),
            n.titleText && (t.innerText = n.titleText),
            F(t, n, "title"),
            (n = e),
            (e = H()),
            U(e, n.closeButtonHtml),
            F(e, n, "closeButton"),
            st(e, n.showCloseButton),
            e.setAttribute("aria-label", n.closeButtonAriaLabel);
    }
    function Nt(t, e) {
        var n, o;
        (o = e),
            (n = x()),
            ot(n, "width", o.width),
            ot(n, "padding", o.padding),
            o.background && (n.style.background = o.background),
            Qt(n, o),
            At(0, e),
            Rt(t, e),
            Mt(t, e),
            mt(0, e),
            (o = e),
            (t = M()),
            st(t, o.footer),
            o.footer && ft(o.footer, t),
            F(t, o, "footer"),
            "function" == typeof e.didRender ? e.didRender(x()) : "function" == typeof e.onRender && e.onRender(x());
    }
    function Ut() {
        return T() && T().click();
    }
    var _t = function () {
            for (var t = n(), e = 0; e < t.length; e++) rt(t[e]);
        },
        Ft = function (t, e) {
            Kt(t, e), zt(), F(t, e, "icon");
        },
        zt = function () {
            for (var t = x(), e = window.getComputedStyle(t).getPropertyValue("background-color"), n = t.querySelectorAll("[class^=swal2-success-circular-line], .swal2-success-fix"), o = 0; o < n.length; o++) n[o].style.backgroundColor = e;
        },
        Wt = function (t, e) {
            (t.textContent = ""),
                e.iconHtml
                    ? U(t, Yt(e.iconHtml))
                    : "success" === e.icon
                    ? U(
                          t,
                          '\n      <div class="swal2-success-circular-line-left"></div>\n      <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>\n      <div class="swal2-success-ring"></div> <div class="swal2-success-fix"></div>\n      <div class="swal2-success-circular-line-right"></div>\n    '
                      )
                    : "error" === e.icon
                    ? U(t, '\n      <span class="swal2-x-mark">\n        <span class="swal2-x-mark-line-left"></span>\n        <span class="swal2-x-mark-line-right"></span>\n      </span>\n    ')
                    : U(t, Yt({ question: "?", warning: "!", info: "i" }[e.icon]));
        },
        Kt = function (t, e) {
            if (e.iconColor) {
                (t.style.color = e.iconColor), (t.style.borderColor = e.iconColor);
                for (var n = 0, o = [".swal2-success-line-tip", ".swal2-success-line-long", ".swal2-x-mark-line-left", ".swal2-x-mark-line-right"]; n < o.length; n++) at(t, o[n], "backgroundColor", e.iconColor);
                at(t, ".swal2-success-ring", "borderColor", e.iconColor);
            }
        },
        Yt = function (t) {
            return '<div class="'.concat($["icon-content"], '">').concat(t, "</div>");
        },
        Zt = [],
        Qt = function (t, e) {
            (t.className = "".concat($.popup, " ").concat(bt(t) ? e.showClass.popup : "")),
                e.toast ? (gt([document.documentElement, document.body], $["toast-shown"]), gt(t, $.toast)) : gt(t, $.modal),
                F(t, e, "popup"),
                "string" == typeof e.customClass && gt(t, e.customClass),
                e.icon && gt(t, $["icon-".concat(e.icon)]);
        };
    function $t() {
        var t = x();
        t || wn.fire(), (t = x());
        var e = q(),
            n = T(),
            o = D();
        it(e), rt(n), gt([t, e], $.loading), it(o), t.setAttribute("data-loading", !0), t.setAttribute("aria-busy", !0), t.focus();
    }
    function Jt() {
        return new Promise(function (t) {
            var e = window.scrollX,
                n = window.scrollY;
            (oe.restoreFocusTimeout = setTimeout(function () {
                oe.previousActiveElement && oe.previousActiveElement.focus ? (oe.previousActiveElement.focus(), (oe.previousActiveElement = null)) : document.body && document.body.focus(), t();
            }, 100)),
                void 0 !== e && void 0 !== n && window.scrollTo(e, n);
        });
    }
    function Xt() {
        if (oe.timeout)
            return (
                (function () {
                    var t = V(),
                        e = parseInt(window.getComputedStyle(t).width);
                    t.style.removeProperty("transition"), (t.style.width = "100%");
                    var n = parseInt(window.getComputedStyle(t).width),
                        n = parseInt((e / n) * 100);
                    t.style.removeProperty("transition"), (t.style.width = "".concat(n, "%"));
                })(),
                oe.timeout.stop()
            );
    }
    function Gt() {
        if (oe.timeout) {
            var t = oe.timeout.start();
            return lt(t), t;
        }
    }
    function te(t) {
        return Object.prototype.hasOwnProperty.call(ie, t);
    }
    function ee(t) {
        return ae[t];
    }
    function ne(t) {
        for (var e in t) te((o = e)) || z('Unknown parameter "'.concat(o, '"')), t.toast && ((n = e), -1 !== se.indexOf(n) && z('The parameter "'.concat(n, '" is incompatible with toasts'))), ee((n = e)) && g(n, ee(n));
        var n, o;
    }
    var oe = {},
        ie = {
            title: "",
            titleText: "",
            text: "",
            html: "",
            footer: "",
            icon: void 0,
            iconColor: void 0,
            iconHtml: void 0,
            toast: !1,
            animation: !0,
            showClass: { popup: "swal2-show", backdrop: "swal2-backdrop-show", icon: "swal2-icon-show" },
            hideClass: { popup: "swal2-hide", backdrop: "swal2-backdrop-hide", icon: "swal2-icon-hide" },
            customClass: void 0,
            target: "body",
            backdrop: !0,
            heightAuto: !0,
            allowOutsideClick: !0,
            allowEscapeKey: !0,
            allowEnterKey: !0,
            stopKeydownPropagation: !0,
            keydownListenerCapture: !1,
            showConfirmButton: !0,
            showDenyButton: !1,
            showCancelButton: !1,
            preConfirm: void 0,
            preDeny: void 0,
            confirmButtonText: "OK",
            confirmButtonAriaLabel: "",
            confirmButtonColor: void 0,
            denyButtonText: "No",
            denyButtonAriaLabel: "",
            denyButtonColor: void 0,
            cancelButtonText: "Cancel",
            cancelButtonAriaLabel: "",
            cancelButtonColor: void 0,
            buttonsStyling: !0,
            reverseButtons: !1,
            focusConfirm: !0,
            focusDeny: !1,
            focusCancel: !1,
            showCloseButton: !1,
            closeButtonHtml: "&times;",
            closeButtonAriaLabel: "Close this dialog",
            loaderHtml: "",
            showLoaderOnConfirm: !1,
            imageUrl: void 0,
            imageWidth: void 0,
            imageHeight: void 0,
            imageAlt: "",
            timer: void 0,
            timerProgressBar: !1,
            width: void 0,
            padding: void 0,
            background: void 0,
            input: void 0,
            inputPlaceholder: "",
            inputLabel: "",
            inputValue: "",
            inputOptions: {},
            inputAutoTrim: !0,
            inputAttributes: {},
            inputValidator: void 0,
            returnInputValueOnDeny: !1,
            validationMessage: void 0,
            grow: !1,
            position: "center",
            progressSteps: [],
            currentProgressStep: void 0,
            progressStepsDistance: void 0,
            onBeforeOpen: void 0,
            onOpen: void 0,
            willOpen: void 0,
            didOpen: void 0,
            onRender: void 0,
            didRender: void 0,
            onClose: void 0,
            onAfterClose: void 0,
            willClose: void 0,
            didClose: void 0,
            onDestroy: void 0,
            didDestroy: void 0,
            scrollbarPadding: !0,
        },
        re = [
            "allowEscapeKey",
            "allowOutsideClick",
            "background",
            "buttonsStyling",
            "cancelButtonAriaLabel",
            "cancelButtonColor",
            "cancelButtonText",
            "closeButtonAriaLabel",
            "closeButtonHtml",
            "confirmButtonAriaLabel",
            "confirmButtonColor",
            "confirmButtonText",
            "currentProgressStep",
            "customClass",
            "denyButtonAriaLabel",
            "denyButtonColor",
            "denyButtonText",
            "didClose",
            "didDestroy",
            "footer",
            "hideClass",
            "html",
            "icon",
            "iconColor",
            "imageAlt",
            "imageHeight",
            "imageUrl",
            "imageWidth",
            "onAfterClose",
            "onClose",
            "onDestroy",
            "progressSteps",
            "reverseButtons",
            "showCancelButton",
            "showCloseButton",
            "showConfirmButton",
            "showDenyButton",
            "text",
            "title",
            "titleText",
            "willClose",
        ],
        ae = { animation: 'showClass" and "hideClass', onBeforeOpen: "willOpen", onOpen: "didOpen", onRender: "didRender", onClose: "willClose", onAfterClose: "didClose", onDestroy: "didDestroy" },
        se = ["allowOutsideClick", "allowEnterKey", "backdrop", "focusConfirm", "focusDeny", "focusCancel", "heightAuto", "keydownListenerCapture"],
        ce = Object.freeze({
            isValidParameter: te,
            isUpdatableParameter: function (t) {
                return -1 !== re.indexOf(t);
            },
            isDeprecatedParameter: ee,
            argsToParams: function (n) {
                var o = {};
                return (
                    "object" !== r(n[0]) || w(n[0])
                        ? ["title", "html", "icon"].forEach(function (t, e) {
                              e = n[e];
                              "string" == typeof e || w(e) ? (o[t] = e) : void 0 !== e && W("Unexpected type of ".concat(t, '! Expected "string" or "Element", got ').concat(r(e)));
                          })
                        : c(o, n[0]),
                    o
                );
            },
            isVisible: function () {
                return bt(x());
            },
            clickConfirm: Ut,
            clickDeny: function () {
                return L() && L().click();
            },
            clickCancel: function () {
                return I() && I().click();
            },
            getContainer: C,
            getPopup: x,
            getTitle: P,
            getContent: A,
            getHtmlContainer: function () {
                return t($["html-container"]);
            },
            getImage: E,
            getIcon: B,
            getIcons: n,
            getInputLabel: function () {
                return t($["input-label"]);
            },
            getCloseButton: H,
            getActions: q,
            getConfirmButton: T,
            getDenyButton: L,
            getCancelButton: I,
            getLoader: D,
            getHeader: j,
            getFooter: M,
            getTimerProgressBar: V,
            getFocusableElements: R,
            getValidationMessage: S,
            isLoading: function () {
                return x().hasAttribute("data-loading");
            },
            fire: function () {
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return i(this, e);
            },
            mixin: function (r) {
                return (function (t) {
                    !(function (t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        (t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } })), e && l(t, e);
                    })(i, t);
                    var n,
                        o,
                        e =
                            ((n = i),
                            (o = d()),
                            function () {
                                var t,
                                    e = u(n);
                                return p(this, o ? ((t = u(this).constructor), Reflect.construct(e, arguments, t)) : e.apply(this, arguments));
                            });
                    function i() {
                        return a(this, i), e.apply(this, arguments);
                    }
                    return (
                        s(i, [
                            {
                                key: "_main",
                                value: function (t) {
                                    return f(u(i.prototype), "_main", this).call(this, c({}, r, t));
                                },
                            },
                        ]),
                        i
                    );
                })(this);
            },
            queue: function (t) {
                var r = this;
                Zt = t;
                function a(t, e) {
                    (Zt = []), t(e);
                }
                var s = [];
                return new Promise(function (i) {
                    !(function e(n, o) {
                        n < Zt.length
                            ? (document.body.setAttribute("data-swal2-queue-step", n),
                              r.fire(Zt[n]).then(function (t) {
                                  void 0 !== t.value ? (s.push(t.value), e(n + 1, o)) : a(i, { dismiss: t.dismiss });
                              }))
                            : a(i, { value: s });
                    })(0);
                });
            },
            getQueueStep: Vt,
            insertQueueStep: function (t, e) {
                return e && e < Zt.length ? Zt.splice(e, 0, t) : Zt.push(t);
            },
            deleteQueueStep: function (t) {
                void 0 !== Zt[t] && Zt.splice(t, 1);
            },
            showLoading: $t,
            enableLoading: $t,
            getTimerLeft: function () {
                return oe.timeout && oe.timeout.getTimerLeft();
            },
            stopTimer: Xt,
            resumeTimer: Gt,
            toggleTimer: function () {
                var t = oe.timeout;
                return t && (t.running ? Xt : Gt)();
            },
            increaseTimer: function (t) {
                if (oe.timeout) {
                    t = oe.timeout.increase(t);
                    return lt(t, !0), t;
                }
            },
            isTimerRunning: function () {
                return oe.timeout && oe.timeout.isRunning();
            },
        });
    function ue() {
        var t,
            e = St.innerParams.get(this);
        e &&
            ((t = St.domCache.get(this)),
            rt(t.loader),
            e.showConfirmButton ? it(t.confirmButton, "inline-block") : e.showConfirmButton || e.showCancelButton || rt(t.actions),
            vt([t.popup, t.actions], $.loading),
            t.popup.removeAttribute("aria-busy"),
            t.popup.removeAttribute("data-loading"),
            (t.confirmButton.disabled = !1),
            (t.denyButton.disabled = !1),
            (t.cancelButton.disabled = !1));
    }
    function le() {
        null === G.previousBodyPadding &&
            document.body.scrollHeight > window.innerHeight &&
            ((G.previousBodyPadding = parseInt(window.getComputedStyle(document.body).getPropertyValue("padding-right"))),
            (document.body.style.paddingRight = "".concat(
                G.previousBodyPadding +
                    (function () {
                        var t = document.createElement("div");
                        (t.className = $["scrollbar-measure"]), document.body.appendChild(t);
                        var e = t.getBoundingClientRect().width - t.clientWidth;
                        return document.body.removeChild(t), e;
                    })(),
                "px"
            )));
    }
    function de() {
        return !!window.MSInputMethodContext && !!document.documentMode;
    }
    function pe() {
        var t = C(),
            e = x();
        t.style.removeProperty("align-items"), e.offsetTop < 0 && (t.style.alignItems = "flex-start");
    }
    var fe = function () {
            navigator.userAgent.match(/(CriOS|FxiOS|EdgiOS|YaBrowser|UCBrowser)/i) || (x().scrollHeight > window.innerHeight - 44 && (C().style.paddingBottom = "".concat(44, "px")));
        },
        me = function () {
            var e,
                t = C();
            (t.ontouchstart = function (t) {
                e = he(t);
            }),
                (t.ontouchmove = function (t) {
                    e && (t.preventDefault(), t.stopPropagation());
                });
        },
        he = function (t) {
            var e = t.target,
                n = C();
            return (!t.touches || !t.touches.length || "stylus" !== t.touches[0].touchType) && (e === n || !(ct(n) || "INPUT" === e.tagName || (ct(A()) && A().contains(e))));
        },
        ge = { swalPromiseResolve: new WeakMap() };
    function ve(t, e, n, o) {
        n
            ? xe(t, o)
            : (Jt().then(function () {
                  return xe(t, o);
              }),
              oe.keydownTarget.removeEventListener("keydown", oe.keydownHandler, { capture: oe.keydownListenerCapture }),
              (oe.keydownHandlerAdded = !1)),
            e.parentNode && !document.body.getAttribute("data-swal2-queue-step") && e.parentNode.removeChild(e),
            N() &&
                (null !== G.previousBodyPadding && ((document.body.style.paddingRight = "".concat(G.previousBodyPadding, "px")), (G.previousBodyPadding = null)),
                _(document.body, $.iosfix) && ((e = parseInt(document.body.style.top, 10)), vt(document.body, $.iosfix), (document.body.style.top = ""), (document.body.scrollTop = -1 * e)),
                "undefined" != typeof window && de() && window.removeEventListener("resize", pe),
                h(document.body.children).forEach(function (t) {
                    t.hasAttribute("data-previous-aria-hidden") ? (t.setAttribute("aria-hidden", t.getAttribute("data-previous-aria-hidden")), t.removeAttribute("data-previous-aria-hidden")) : t.removeAttribute("aria-hidden");
                })),
            vt([document.documentElement, document.body], [$.shown, $["height-auto"], $["no-backdrop"], $["toast-shown"], $["toast-column"]]);
    }
    function ye(t) {
        var e,
            n,
            o,
            i = x();
        i &&
            ((t = be(t)),
            (e = St.innerParams.get(this)) &&
                !_(i, e.hideClass.popup) &&
                ((n = ge.swalPromiseResolve.get(this)), vt(i, e.showClass.popup), gt(i, e.hideClass.popup), (o = C()), vt(o, e.showClass.backdrop), gt(o, e.hideClass.backdrop), we(this, i, e), n(t)));
    }
    function be(t) {
        return void 0 === t ? { isConfirmed: !1, isDenied: !1, isDismissed: !0 } : c({ isConfirmed: !1, isDenied: !1, isDismissed: !1 }, t);
    }
    function we(t, e, n) {
        var o = C(),
            i = Bt && ut(e),
            r = n.onClose,
            a = n.onAfterClose,
            s = n.willClose,
            n = n.didClose;
        Ce(e, s, r), i ? ke(t, e, o, n || a) : ve(t, o, X(), n || a);
    }
    var Ce = function (t, e, n) {
            null !== e && "function" == typeof e ? e(t) : null !== n && "function" == typeof n && n(t);
        },
        ke = function (t, e, n, o) {
            (oe.swalCloseEventFinishedCallback = ve.bind(null, t, n, X(), o)),
                e.addEventListener(Bt, function (t) {
                    t.target === e && (oe.swalCloseEventFinishedCallback(), delete oe.swalCloseEventFinishedCallback);
                });
        },
        xe = function (t, e) {
            setTimeout(function () {
                "function" == typeof e && e(), t._destroy();
            });
        };
    function Be(t, e, n) {
        var o = St.domCache.get(t);
        e.forEach(function (t) {
            o[t].disabled = n;
        });
    }
    function Pe(t, e) {
        if (!t) return !1;
        if ("radio" === t.type) for (var n = t.parentNode.parentNode.querySelectorAll("input"), o = 0; o < n.length; o++) n[o].disabled = e;
        else t.disabled = e;
    }
    var Ae = (function () {
            function n(t, e) {
                a(this, n), (this.callback = t), (this.remaining = e), (this.running = !1), this.start();
            }
            return (
                s(n, [
                    {
                        key: "start",
                        value: function () {
                            return this.running || ((this.running = !0), (this.started = new Date()), (this.id = setTimeout(this.callback, this.remaining))), this.remaining;
                        },
                    },
                    {
                        key: "stop",
                        value: function () {
                            return this.running && ((this.running = !1), clearTimeout(this.id), (this.remaining -= new Date() - this.started)), this.remaining;
                        },
                    },
                    {
                        key: "increase",
                        value: function (t) {
                            var e = this.running;
                            return e && this.stop(), (this.remaining += t), e && this.start(), this.remaining;
                        },
                    },
                    {
                        key: "getTimerLeft",
                        value: function () {
                            return this.running && (this.stop(), this.start()), this.remaining;
                        },
                    },
                    {
                        key: "isRunning",
                        value: function () {
                            return this.running;
                        },
                    },
                ]),
                n
            );
        })(),
        Ee = {
            email: function (t, e) {
                return /^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9-]{2,24}$/.test(t) ? Promise.resolve() : Promise.resolve(e || "Invalid email address");
            },
            url: function (t, e) {
                return /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)$/.test(t) ? Promise.resolve() : Promise.resolve(e || "Invalid URL");
            },
        };
    function Oe(t) {
        var e, n;
        (e = t).inputValidator ||
            Object.keys(Ee).forEach(function (t) {
                e.input === t && (e.inputValidator = Ee[t]);
            }),
            t.showLoaderOnConfirm &&
                !t.preConfirm &&
                z("showLoaderOnConfirm is set to true, but preConfirm is not defined.\nshowLoaderOnConfirm should be used together with preConfirm, see usage example:\nhttps://sweetalert2.github.io/#ajax-request"),
            (t.animation = Y(t.animation)),
            ((n = t).target && ("string" != typeof n.target || document.querySelector(n.target)) && ("string" == typeof n.target || n.target.appendChild)) || (z('Target parameter is not valid, defaulting to "body"'), (n.target = "body")),
            "string" == typeof t.title && (t.title = t.title.split("\n").join("<br />")),
            Ct(t);
    }
    function Se(t) {
        var e = C(),
            n = x();
        "function" == typeof t.willOpen ? t.willOpen(n) : "function" == typeof t.onBeforeOpen && t.onBeforeOpen(n);
        var o = window.getComputedStyle(document.body).overflowY;
        Me(e, n, t),
            setTimeout(function () {
                qe(e, n);
            }, 10),
            N() &&
                (je(e, t.scrollbarPadding, o),
                h(document.body.children).forEach(function (t) {
                    t === C() ||
                        (function (t, e) {
                            if ("function" == typeof t.contains) return t.contains(e);
                        })(t, C()) ||
                        (t.hasAttribute("aria-hidden") && t.setAttribute("data-previous-aria-hidden", t.getAttribute("aria-hidden")), t.setAttribute("aria-hidden", "true"));
                })),
            X() || oe.previousActiveElement || (oe.previousActiveElement = document.activeElement),
            Ie(n, t),
            vt(e, $["no-transition"]);
    }
    function Te(t) {
        var e = x();
        t.target === e && ((t = C()), e.removeEventListener(Bt, Te), (t.style.overflowY = "auto"));
    }
    function Le(t, e) {
        t.closePopup({ isConfirmed: !0, value: e });
    }
    function De(t, e, n) {
        var o = R(),
            i = 0;
        if (i < o.length) return (e += n) === o.length ? (e = 0) : -1 === e && (e = o.length - 1), o[e].focus();
        x().focus();
    }
    var Ie = function (t, e) {
            "function" == typeof e.didOpen
                ? setTimeout(function () {
                      return e.didOpen(t);
                  })
                : "function" == typeof e.onOpen &&
                  setTimeout(function () {
                      return e.onOpen(t);
                  });
        },
        qe = function (t, e) {
            Bt && ut(e) ? ((t.style.overflowY = "hidden"), e.addEventListener(Bt, Te)) : (t.style.overflowY = "auto");
        },
        je = function (t, e, n) {
            var o;
            ((/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) || ("MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints)) &&
                !_(document.body, $.iosfix) &&
                ((o = document.body.scrollTop), (document.body.style.top = "".concat(-1 * o, "px")), gt(document.body, $.iosfix), me(), fe()),
                "undefined" != typeof window && de() && (pe(), window.addEventListener("resize", pe)),
                e && "hidden" !== n && le(),
                setTimeout(function () {
                    t.scrollTop = 0;
                });
        },
        Me = function (t, e, n) {
            gt(t, n.showClass.backdrop),
                e.style.setProperty("opacity", "0", "important"),
                it(e),
                setTimeout(function () {
                    gt(e, n.showClass.popup), e.style.removeProperty("opacity");
                }, 10),
                gt([document.documentElement, document.body], $.shown),
                n.heightAuto && n.backdrop && !n.toast && gt([document.documentElement, document.body], $["height-auto"]);
        },
        Ve = function (t) {
            return t.checked ? 1 : 0;
        },
        He = function (t) {
            return t.checked ? t.value : null;
        },
        Re = function (t) {
            return t.files.length ? (null !== t.getAttribute("multiple") ? t.files : t.files[0]) : null;
        },
        Ne = function (e, n) {
            function o(t) {
                return _e[n.input](i, Fe(t), n);
            }
            var i = A();
            v(n.inputOptions) || b(n.inputOptions)
                ? ($t(),
                  y(n.inputOptions).then(function (t) {
                      e.hideLoading(), o(t);
                  }))
                : "object" === r(n.inputOptions)
                ? o(n.inputOptions)
                : W("Unexpected type of inputOptions! Expected object, Map or Promise, got ".concat(r(n.inputOptions)));
        },
        Ue = function (e, n) {
            var o = e.getInput();
            rt(o),
                y(n.inputValue)
                    .then(function (t) {
                        (o.value = "number" === n.input ? parseFloat(t) || 0 : "".concat(t)), it(o), o.focus(), e.hideLoading();
                    })
                    .catch(function (t) {
                        W("Error in inputValue promise: ".concat(t)), (o.value = ""), it(o), o.focus(), e.hideLoading();
                    });
        },
        _e = {
            select: function (t, e, i) {
                function o(t, e, n) {
                    var o = document.createElement("option");
                    (o.value = n), U(o, e), i.inputValue.toString() === n.toString() && (o.selected = !0), t.appendChild(o);
                }
                var r = yt(t, $.select);
                e.forEach(function (t) {
                    var e,
                        n = t[0],
                        t = t[1];
                    Array.isArray(t)
                        ? (((e = document.createElement("optgroup")).label = n),
                          (e.disabled = !1),
                          r.appendChild(e),
                          t.forEach(function (t) {
                              return o(e, t[1], t[0]);
                          }))
                        : o(r, t, n);
                }),
                    r.focus();
            },
            radio: function (t, e, i) {
                var r = yt(t, $.radio);
                e.forEach(function (t) {
                    var e = t[0],
                        n = t[1],
                        o = document.createElement("input"),
                        t = document.createElement("label");
                    (o.type = "radio"), (o.name = $.radio), (o.value = e), i.inputValue.toString() === e.toString() && (o.checked = !0);
                    e = document.createElement("span");
                    U(e, n), (e.className = $.label), t.appendChild(o), t.appendChild(e), r.appendChild(t);
                });
                e = r.querySelectorAll("input");
                e.length && e[0].focus();
            },
        },
        Fe = function n(o) {
            var i = [];
            return (
                "undefined" != typeof Map && o instanceof Map
                    ? o.forEach(function (t, e) {
                          "object" === r(t) && (t = n(t)), i.push([e, t]);
                      })
                    : Object.keys(o).forEach(function (t) {
                          var e = o[t];
                          "object" === r(e) && (e = n(e)), i.push([t, e]);
                      }),
                i
            );
        },
        ze = function (t, e, n) {
            var o = (function (t, e) {
                t = t.getInput();
                if (!t) return null;
                switch (e.input) {
                    case "checkbox":
                        return Ve(t);
                    case "radio":
                        return He(t);
                    case "file":
                        return Re(t);
                    default:
                        return e.inputAutoTrim ? t.value.trim() : t.value;
                }
            })(t, e);
            e.inputValidator ? We(t, e, o) : t.getInput().checkValidity() ? ("deny" === n ? Ke : Ye)(t, e, o) : (t.enableButtons(), t.showValidationMessage(e.validationMessage));
        },
        We = function (e, n, o) {
            e.disableInput(),
                Promise.resolve()
                    .then(function () {
                        return y(n.inputValidator(o, n.validationMessage));
                    })
                    .then(function (t) {
                        e.enableButtons(), e.enableInput(), t ? e.showValidationMessage(t) : Ye(e, n, o);
                    });
        },
        Ke = function (e, t, n) {
            t.preDeny
                ? Promise.resolve()
                      .then(function () {
                          return y(t.preDeny(n, t.validationMessage));
                      })
                      .then(function (t) {
                          !1 === t ? e.hideLoading() : e.closePopup({ isDenied: !0, value: void 0 === t ? n : t });
                      })
                : e.closePopup({ isDenied: !0, value: n });
        },
        Ye = function (e, t, n) {
            t.showLoaderOnConfirm && $t(),
                t.preConfirm
                    ? (e.resetValidationMessage(),
                      Promise.resolve()
                          .then(function () {
                              return y(t.preConfirm(n, t.validationMessage));
                          })
                          .then(function (t) {
                              bt(S()) || !1 === t ? e.hideLoading() : Le(e, void 0 === t ? n : t);
                          }))
                    : Le(e, n);
        },
        Ze = ["ArrowRight", "ArrowDown", "Right", "Down"],
        Qe = ["ArrowLeft", "ArrowUp", "Left", "Up"],
        $e = ["Escape", "Esc"],
        Je = function (t, e, n) {
            var o = St.innerParams.get(t);
            o.stopKeydownPropagation && e.stopPropagation(), "Enter" === e.key ? Xe(t, e, o) : "Tab" === e.key ? Ge(e, o) : -1 !== [].concat(Ze, Qe).indexOf(e.key) ? tn(e.key) : -1 !== $e.indexOf(e.key) && en(e, o, n);
        },
        Xe = function (t, e, n) {
            e.isComposing || (e.target && t.getInput() && e.target.outerHTML === t.getInput().outerHTML && -1 === ["textarea", "file"].indexOf(n.input) && (Ut(), e.preventDefault()));
        },
        Ge = function (t) {
            for (var e = t.target, n = R(), o = -1, i = 0; i < n.length; i++)
                if (e === n[i]) {
                    o = i;
                    break;
                }
            t.shiftKey ? De(0, o, -1) : De(0, o, 1), t.stopPropagation(), t.preventDefault();
        },
        tn = function (t) {
            -1 !== [T(), L(), I()].indexOf(document.activeElement) && ((t = -1 !== Ze.indexOf(t) ? "nextElementSibling" : "previousElementSibling"), (t = document.activeElement[t]) && t.focus());
        },
        en = function (t, e, n) {
            Y(e.allowEscapeKey) && (t.preventDefault(), n(Z.esc));
        },
        nn = function (e, t, n) {
            t.popup.onclick = function () {
                var t = St.innerParams.get(e);
                t.showConfirmButton || t.showDenyButton || t.showCancelButton || t.showCloseButton || t.input || n(Z.close);
            };
        },
        on = !1,
        rn = function (e) {
            e.popup.onmousedown = function () {
                e.container.onmouseup = function (t) {
                    (e.container.onmouseup = void 0), t.target === e.container && (on = !0);
                };
            };
        },
        an = function (e) {
            e.container.onmousedown = function () {
                e.popup.onmouseup = function (t) {
                    (e.popup.onmouseup = void 0), (t.target !== e.popup && !e.popup.contains(t.target)) || (on = !0);
                };
            };
        },
        sn = function (n, o, i) {
            o.container.onclick = function (t) {
                var e = St.innerParams.get(n);
                on ? (on = !1) : t.target === o.container && Y(e.allowOutsideClick) && i(Z.backdrop);
            };
        };
    function cn(t) {
        var e = c({}, ie.showClass, t.showClass),
            n = c({}, ie.hideClass, t.hideClass),
            o = c({}, ie, t);
        return (o.showClass = e), (o.hideClass = n), !1 === t.animation && ((o.showClass = { popup: "swal2-noanimation", backdrop: "swal2-noanimation" }), (o.hideClass = {})), o;
    }
    function un(a, s, c) {
        return new Promise(function (t) {
            function e(t) {
                a.closePopup({ isDismissed: !0, dismiss: t });
            }
            var n, o, i, r;
            ge.swalPromiseResolve.set(a, t),
                (s.confirmButton.onclick = function () {
                    return (e = c), (t = a).disableButtons(), void (e.input ? ze(t, e, "confirm") : Ye(t, e, !0));
                    var t, e;
                }),
                (s.denyButton.onclick = function () {
                    return (e = c), (t = a).disableButtons(), void (e.returnInputValueOnDeny ? ze(t, e, "deny") : Ke(t, e, !1));
                    var t, e;
                }),
                (s.cancelButton.onclick = function () {
                    return (t = e), a.disableButtons(), void t(Z.cancel);
                    var t;
                }),
                (s.closeButton.onclick = function () {
                    return e(Z.close);
                }),
                (n = a),
                (r = s),
                (t = e),
                St.innerParams.get(n).toast ? nn(n, r, t) : (rn(r), an(r), sn(n, r, t)),
                (o = a),
                (r = c),
                (i = e),
                (t = oe).keydownTarget && t.keydownHandlerAdded && (t.keydownTarget.removeEventListener("keydown", t.keydownHandler, { capture: t.keydownListenerCapture }), (t.keydownHandlerAdded = !1)),
                r.toast ||
                    ((t.keydownHandler = function (t) {
                        return Je(o, t, i);
                    }),
                    (t.keydownTarget = r.keydownListenerCapture ? window : x()),
                    (t.keydownListenerCapture = r.keydownListenerCapture),
                    t.keydownTarget.addEventListener("keydown", t.keydownHandler, { capture: t.keydownListenerCapture }),
                    (t.keydownHandlerAdded = !0)),
                (c.toast && (c.input || c.footer || c.showCloseButton) ? gt : vt)(document.body, $["toast-column"]),
                (r = a),
                "select" === (t = c).input || "radio" === t.input ? Ne(r, t) : -1 !== ["text", "email", "number", "tel", "textarea"].indexOf(t.input) && (v(t.inputValue) || b(t.inputValue)) && Ue(r, t),
                Se(c),
                dn(oe, c, e),
                pn(s, c),
                setTimeout(function () {
                    s.container.scrollTop = 0;
                });
        });
    }
    function ln(t) {
        var e = { popup: x(), container: C(), content: A(), actions: q(), confirmButton: T(), denyButton: L(), cancelButton: I(), loader: D(), closeButton: H(), validationMessage: S(), progressSteps: O() };
        return St.domCache.set(t, e), e;
    }
    var dn = function (t, e, n) {
            var o = V();
            rt(o),
                e.timer &&
                    ((t.timeout = new Ae(function () {
                        n("timer"), delete t.timeout;
                    }, e.timer)),
                    e.timerProgressBar &&
                        (it(o),
                        setTimeout(function () {
                            t.timeout.running && lt(e.timer);
                        })));
        },
        pn = function (t, e) {
            if (!e.toast) return Y(e.allowEnterKey) ? void (fn(t, e) || De(0, -1, 1)) : mn();
        },
        fn = function (t, e) {
            return e.focusDeny && bt(t.denyButton) ? (t.denyButton.focus(), !0) : e.focusCancel && bt(t.cancelButton) ? (t.cancelButton.focus(), !0) : !(!e.focusConfirm || !bt(t.confirmButton)) && (t.confirmButton.focus(), !0);
        },
        mn = function () {
            document.activeElement && "function" == typeof document.activeElement.blur && document.activeElement.blur();
        };
    function hn(t) {
        "function" == typeof t.didDestroy ? t.didDestroy() : "function" == typeof t.onDestroy && t.onDestroy();
    }
    function gn(t) {
        delete t.params, delete oe.keydownHandler, delete oe.keydownTarget, yn(St), yn(ge);
    }
    var vn,
        yn = function (t) {
            for (var e in t) t[e] = new WeakMap();
        },
        Q = Object.freeze({
            hideLoading: ue,
            disableLoading: ue,
            getInput: function (t) {
                var e = St.innerParams.get(t || this);
                return (t = St.domCache.get(t || this)) ? tt(t.content, e.input) : null;
            },
            close: ye,
            closePopup: ye,
            closeModal: ye,
            closeToast: ye,
            enableButtons: function () {
                Be(this, ["confirmButton", "denyButton", "cancelButton"], !1);
            },
            disableButtons: function () {
                Be(this, ["confirmButton", "denyButton", "cancelButton"], !0);
            },
            enableInput: function () {
                return Pe(this.getInput(), !1);
            },
            disableInput: function () {
                return Pe(this.getInput(), !0);
            },
            showValidationMessage: function (t) {
                var e = St.domCache.get(this),
                    n = St.innerParams.get(this);
                U(e.validationMessage, t),
                    (e.validationMessage.className = $["validation-message"]),
                    n.customClass && n.customClass.validationMessage && gt(e.validationMessage, n.customClass.validationMessage),
                    it(e.validationMessage),
                    (e = this.getInput()) && (e.setAttribute("aria-invalid", !0), e.setAttribute("aria-describedBy", $["validation-message"]), et(e), gt(e, $.inputerror));
            },
            resetValidationMessage: function () {
                var t = St.domCache.get(this);
                t.validationMessage && rt(t.validationMessage), (t = this.getInput()) && (t.removeAttribute("aria-invalid"), t.removeAttribute("aria-describedBy"), vt(t, $.inputerror));
            },
            getProgressSteps: function () {
                return St.domCache.get(this).progressSteps;
            },
            _main: function (t) {
                ne(t), oe.currentInstance && oe.currentInstance._destroy(), (oe.currentInstance = this);
                var e = cn(t);
                return Oe(e), Object.freeze(e), oe.timeout && (oe.timeout.stop(), delete oe.timeout), clearTimeout(oe.restoreFocusTimeout), (t = ln(this)), Nt(this, e), St.innerParams.set(this, e), un(this, t, e);
            },
            update: function (e) {
                var t = x(),
                    n = St.innerParams.get(this);
                if (!t || _(t, n.hideClass.popup)) return z("You're trying to update the closed or closing popup, that won't work. Use the update() method in preConfirm parameter or show a new popup.");
                var o = {};
                Object.keys(e).forEach(function (t) {
                    wn.isUpdatableParameter(t)
                        ? (o[t] = e[t])
                        : z(
                              'Invalid parameter to update: "'.concat(
                                  t,
                                  '". Updatable params are listed here: https://github.com/sweetalert2/sweetalert2/blob/master/src/utils/params.js\n\nIf you think this parameter should be updatable, request it here: https://github.com/sweetalert2/sweetalert2/issues/new?template=02_feature_request.md'
                              )
                          );
                }),
                    (n = c({}, n, o)),
                    Nt(this, n),
                    St.innerParams.set(this, n),
                    Object.defineProperties(this, { params: { value: c({}, this.params, e), writable: !1, enumerable: !0 } });
            },
            _destroy: function () {
                var t = St.domCache.get(this),
                    e = St.innerParams.get(this);
                e &&
                    (t.popup && oe.swalCloseEventFinishedCallback && (oe.swalCloseEventFinishedCallback(), delete oe.swalCloseEventFinishedCallback),
                    oe.deferDisposalTimer && (clearTimeout(oe.deferDisposalTimer), delete oe.deferDisposalTimer),
                    hn(e),
                    gn(this));
            },
        }),
        bn = (function () {
            function i() {
                if ((a(this, i), "undefined" != typeof window)) {
                    "undefined" == typeof Promise &&
                        W("This package requires a Promise library, please include a shim to enable it in this browser (See: https://github.com/sweetalert2/sweetalert2/wiki/Migration-from-SweetAlert-to-SweetAlert2#1-ie-support)"),
                        (vn = this);
                    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    var o = Object.freeze(this.constructor.argsToParams(e));
                    Object.defineProperties(this, { params: { value: o, writable: !1, enumerable: !0, configurable: !0 } });
                    o = this._main(this.params);
                    St.promise.set(this, o);
                }
            }
            return (
                s(i, [
                    {
                        key: "then",
                        value: function (t) {
                            return St.promise.get(this).then(t);
                        },
                    },
                    {
                        key: "finally",
                        value: function (t) {
                            return St.promise.get(this).finally(t);
                        },
                    },
                ]),
                i
            );
        })();
    c(bn.prototype, Q),
        c(bn, ce),
        Object.keys(Q).forEach(function (t) {
            bn[t] = function () {
                if (vn) return vn[t].apply(vn, arguments);
            };
        }),
        (bn.DismissReason = Z),
        (bn.version = "10.9.0");
    var wn = bn;
    return (wn.default = wn);
}),
    void 0 !== this && this.Sweetalert2 && (this.swal = this.sweetAlert = this.Swal = this.SweetAlert = this.Sweetalert2);
"undefined" != typeof document &&
    (function (e, t) {
        var n = e.createElement("style");
        if ((e.getElementsByTagName("head")[0].appendChild(n), n.styleSheet)) n.styleSheet.disabled || (n.styleSheet.cssText = t);
        else
            try {
                n.innerHTML = t;
            } catch (e) {
                n.innerText = t;
            }
    })(
        document,
        '.swal2-popup.swal2-toast{flex-direction:row;align-items:center;width:auto;padding:.625em;overflow-y:hidden;background:#fff;box-shadow:0 0 .625em #d9d9d9}.swal2-popup.swal2-toast .swal2-header{flex-direction:row;padding:0}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:static;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;padding:0;font-size:1em}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{font-size:.25em}}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{flex-basis:auto!important;width:auto;height:auto;margin:0 .3125em;padding:0}.swal2-popup.swal2-toast .swal2-styled{margin:0 .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(100,150,200,.5)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:flex;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-bottom-end>:first-child,.swal2-container.swal2-bottom-left>:first-child,.swal2-container.swal2-bottom-right>:first-child,.swal2-container.swal2-bottom-start>:first-child,.swal2-container.swal2-bottom>:first-child{margin-top:auto}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-no-transition{transition:none!important}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-popup{display:none;position:relative;box-sizing:border-box;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border:none;border-radius:5px;background:#fff;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-header{display:flex;flex-direction:column;align-items:center;padding:0 1.8em}.swal2-title{position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;margin:1.25em auto 0;padding:0 1.6em}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 transparent #2778c4 transparent}.swal2-styled{margin:.3125em;padding:.625em 2em;box-shadow:none;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#2778c4;color:#fff;font-size:1.0625em}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#d14529;color:#fff;font-size:1.0625em}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#757575;color:#fff;font-size:1.0625em}.swal2-styled:focus{outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;height:.25em;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:1.25em auto}.swal2-close{position:absolute;z-index:2;top:0;right:0;align-items:center;justify-content:center;width:1.2em;height:1.2em;padding:0;overflow:hidden;transition:color .1s ease-out;border:none;border-radius:5px;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close:focus{outline:0;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-content{z-index:1;justify-content:center;margin:0;padding:0 1.6em;color:#545454;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em auto}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em auto;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-input[type=number]{max-width:10em}.swal2-file{background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto}.swal2-validation-message{display:none;align-items:center;justify-content:center;margin:0 -2.7em;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:0 0 1.25em;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{top:auto;right:auto;bottom:auto;left:auto;max-width:calc(100% - .625em * 2);background-color:transparent!important}body.swal2-no-backdrop .swal2-container>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-container.swal2-top{top:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-top-left,body.swal2-no-backdrop .swal2-container.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-top-end,body.swal2-no-backdrop .swal2-container.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-container.swal2-center{top:50%;left:50%;transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-left,body.swal2-no-backdrop .swal2-container.swal2-center-start{top:50%;left:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-end,body.swal2-no-backdrop .swal2-container.swal2-center-right{top:50%;right:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom{bottom:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom-left,body.swal2-no-backdrop .swal2-container.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-bottom-end,body.swal2-no-backdrop .swal2-container.swal2-bottom-right{right:0;bottom:0}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}body.swal2-toast-column .swal2-toast{flex-direction:column;align-items:stretch}body.swal2-toast-column .swal2-toast .swal2-actions{flex:1;align-self:stretch;height:2.2em;margin-top:.3125em}body.swal2-toast-column .swal2-toast .swal2-loading{justify-content:center}body.swal2-toast-column .swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}body.swal2-toast-column .swal2-toast .swal2-validation-message{font-size:1em}'
    );
