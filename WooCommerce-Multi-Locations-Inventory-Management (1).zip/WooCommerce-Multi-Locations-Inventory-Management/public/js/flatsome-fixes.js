jQuery(document).ready(function($) {
    // Add our multiloca class to the price-wrapper for showing individual locations prices accordingly.
    jQuery('.single-product .product-info .price-wrapper').addClass('wcmlim_product_price');
    jQuery('.single-product .product-info .price-wrapper').addClass('price');

});