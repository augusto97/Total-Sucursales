
// Function to set a cookie
export function setcookie(name, value, days) {
  let date = new Date();
  if (days) {
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    var expires = `; expires=${date.toUTCString()}`;
  } else {
    date.setTime(date.getTime() + 1 * 24 * 60 * 60 * 1000); // Default expires in 1 day
    var expires = `; expires=${date.toUTCString()}`;
  }
  document.cookie = `${name}=${value}${expires};path=/`; // Set cookie
}

// Function to get a cookie by name
export function getCookie(name) {
  const dc = document.cookie; // Get all cookies
  const prefix = name + "="; // Cookie name prefix

  let begin = dc.indexOf("; " + prefix); // Check if cookie exists
  if (begin === -1) {
    begin = dc.indexOf(prefix); // If no "; " found, check the start of the cookie string
    if (begin !== 0) return null; // Cookie not found
  } else {
    begin += 2; // Skip the "; " prefix
  }

  let end = dc.indexOf(";", begin); // Find the end of the cookie
  if (end === -1) end = dc.length; // If no semicolon, it's the last cookie

  return decodeURI(dc.substring(begin + prefix.length, end)); // Return decoded cookie value
}
