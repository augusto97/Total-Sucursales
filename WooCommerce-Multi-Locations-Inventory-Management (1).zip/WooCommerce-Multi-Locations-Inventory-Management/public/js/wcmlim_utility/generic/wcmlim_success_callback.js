import * as wcmlim_set_location from "./wcmlim_set_location.js";

export function successCallback(position) { 
  /* Current Coordinate */
  const lat = position.coords.latitude;
  const lng = position.coords.longitude;
  
  const google_map_pos = new google.maps.LatLng(lat, lng);
  /* Use Geocoder to get address */
  const google_maps_geocoder = new google.maps.Geocoder();
  google_maps_geocoder.geocode(
    { latLng: google_map_pos },
    (results, status) => {
      if (status == google.maps.GeocoderStatus.OK && results[0]) {
        const pos_form_add = results[0].formatted_address;
        wcmlim_set_location.setLocation(pos_form_add, lat, lng);

      }
    }
  );
}

export function getselectedlocation() {
	// Retrieve cookies for 'wcmlim_selected_location' and 'wcmlim_selected_location_termid'
	let selectedLocation = "";
	let selectedLocationTermid = "";
	document.cookie.split(";").forEach(cookie => {
		let [name, value] = cookie.trim().split("=");
		if (name === "wcmlim_selected_location") {
			selectedLocation = value;
		}
		if (name === "wcmlim_selected_location_termid") {
			selectedLocationTermid = value;
		}
	});
	// If neither cookie is set, reload the page.
	if (!selectedLocation && !selectedLocationTermid) {
		location.reload();
	}
	return { selectedLocation, selectedLocationTermid };
}
