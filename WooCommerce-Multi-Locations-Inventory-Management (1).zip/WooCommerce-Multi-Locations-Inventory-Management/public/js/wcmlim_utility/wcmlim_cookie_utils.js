// Function to check if a cookie with a given name is set
function isCookieSet(cookieName) {
	return document.cookie.split(';').some(cookie => cookie.trim().startsWith(cookieName + "="));
}

// Function to check the cookie and reload the page if not set
function checkCookieAndReload(cookieName) {
	if (!isCookieSet(cookieName)) {
		location.reload();
	}
}

export { isCookieSet, checkCookieAndReload };
