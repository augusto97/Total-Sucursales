!(function (e) {
  var t = multi_inventory_popup.show_in_popup,
    s = multi_inventory_popup.force_to_select;
  
  // Function to manage empty state message visibility
  function manageEmptyStateMessage() {
    var rlistContainer = e("#set-def-store .rlist_location");
    if (rlistContainer.length) {
      // Check if container is hidden (by inline style or class)
      var isHidden = rlistContainer.is(":hidden") || 
                    rlistContainer.hasClass("wcmlim-hidden") ||
                    rlistContainer.css("display") === "none";
      
      if (isHidden) {
        // Add a temporary class to suppress empty message
        rlistContainer.addClass("wcmlim-suppress-empty");
      } else {
        // Remove the suppression class when visible
        rlistContainer.removeClass("wcmlim-suppress-empty");
      }
    }
  }
  
  e(".set-def-store-popup-btn").click(function (s) {
    s.preventDefault(),
      (function s() {
        switch (t) {
          case "select":
            e("#set-def-store .rlist_location, #set-def-store .postcode-checker").hide(),
            e("#set-def-store .rlist_location").addClass("wcmlim-hidden"),
            e("#set-def-store #wcmlim-change-lc-select").is(":visible") ||
              (e("#set-def-store #wcmlim-change-lc-select").removeAttr("style"),
              jQuery("#set-def-store #wcmlim-change-lc-select").css("display", "block"));
            break;
          case "input":
            e("#set-def-store .rlist_location").hide(),
            e("#set-def-store .rlist_location").addClass("wcmlim-hidden"),
            e("#set-def-store .wcmlim_sel_location").hide(),
            e("#set-def-store .postcode-checker").show();
            break;
          case "list":
            e("#set-def-store .postcode-checker, #wcmlim-change-lc-select").hide(),
            e("#set-def-store .rlist_location").show(),
            e("#set-def-store .rlist_location").removeClass("wcmlim-hidden");
        }
        // Manage empty state message after mode change
        setTimeout(manageEmptyStateMessage, 50);
      })();
  }),
    e(".set-def-store-popup-btn").magnificPopup({
      type: "inline",
      fixedContentPos: !1,
      fixedBgPos: !0,
      overflowY: "auto",
      closeBtnInside: !0,
      closeOnBgClick: !1,
      enableEscapeKey: !1,
      preloader: !1,
      midClick: !0,
      removalDelay: 300,
    });

  // Initialize empty state management when popup is opened
  e(document).on("mfpOpen", function() {
    setTimeout(manageEmptyStateMessage, 100);
  });
  
  // Also manage empty state on popup initialization
  setTimeout(manageEmptyStateMessage, 200);

  // Get location data from PHP via wp_localize_script
  var locationTermid = multi_inventory_popup.selected_location_termid;
  var location = multi_inventory_popup.selected_location;
  
  // Fallback to cookies if PHP data is not available
  if (!locationTermid || locationTermid === 'undefined' || locationTermid === null) {
    locationTermid = getCookie("wcmlim_selected_location_termid");
  }
  if (!location || location === 'undefined' || location === null) {
    location = getCookie("wcmlim_selected_location");
  }
  
  // If either cookie is missing, blank, null, or -1, show the popup
  if (
    "on" == s &&
    (locationTermid == null || locationTermid === "" || locationTermid === "-1" ||
     location == null || location === "" || location === "-1")
  ) {
    jQuery(".mfp-close").hide();
    e(".set-def-store-popup-btn").click();
  }
})(jQuery);

// Function to get the current location cookie value
function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}