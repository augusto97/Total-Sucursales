jQuery(document).ready(($) => {
  $.noConflict();
  let lat;
  let lng;
  const { ajaxurl } = multi_inventory;
  const { wc_currency } = multi_inventory;
  const autoDetect = multi_inventory.autodetect;
  const { enable_price } = multi_inventory;
  const restricted = multi_inventory.user_specific_location;
  const showLocationInRestricted = multi_inventory.show_location_selection;
  const { instock } = multi_inventory;
  const { soldout } = multi_inventory;
  const stock_format = multi_inventory.stock_format;
  const { widget_select_type } = multi_inventory;
  const nextloc = multi_inventory.nxtloc;
  var store_on_map_arr = multi_inventory.store_on_map_arr;
  var default_zoom = multi_inventory.default_zoom;
  var setting_loc_dis_unit = multi_inventory.setting_loc_dis_unit;
  var listmode = multi_inventory.optiontype_loc;
  var sc_listmode = multi_inventory.scoptiontype_loc;
  var detailadd = multi_inventory.fulladd;
  var listformat = multi_inventory.viewformat;

  advanced_listOrdering();
  $(".variation_id").change(() => {
    advanced_listOrdering();
  });

  function advanced_listOrdering() {
    if (listmode == "on") {
      if (listformat == "advanced_list_view") {
        $(".rselect_location").removeClass("wclimscroll wclimhalf wclimthird wclimfull");
        $(".loc_dd.Wcmlim_prefloc_sel .wc_scrolldown").hide();
        $(".rselect_location").addClass("wclimadvlist");

        if ($(".variation_id").length) {
          var product_id = $("input.variation_id").val();
        } else {
          var product_id = $(".single_add_to_cart_button").val();
        }
        if (product_id != 0) {
          $.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
              action: "wcmlim_prepare_advanced_view_information",
              product_id: product_id,
              security : multi_inventory.security,
            },
            dataType: "json",
            success(response) {
              $(".single_add_to_cart_button, .quantity, #globMsg").hide();

              $.each(response, (key, value) => {
                var indexing = value.indexing;
                var location_id = value.location_id;
                var loc_stock_pid = value.loc_stock_pid;
                var loc_each_backorder = value.loc_each_backorder;
                var stock_price = value.stock_price;
                var shipping_cost = value.shipping_cost;
                var start_time = value.location_start_time;
                var end_time = value.location_end_time;

                var html = "<div class='wcmlim-advanced-detailed'><span class='wcmlim_list_view_price'> " + wc_currency + stock_price + "</span><br></div>";
                var html3 = "<div class='wcmlim-advanced-detailed1'><span class='wcmlim_list_view_shippingprice'><span class='wcmlim-adv-li-icon fa fa-truck'></span>: " + shipping_cost + "</span></div>";
                var html1 = "";

                if (detailadd === "on" && start_time != undefined && end_time != undefined) {
                  html1 = `
                    <div class="wcmlim-advanced-open-close">
                      <p style="font-size:10px;">Open By: ${start_time}</p>
                      <p>Close By: ${end_time}</p>
                    </div>
                  `;
                } else {
                  html1 = `
                    <div class="wcmlim-advanced-open-close" style="visibility: hidden; height: 0;"></div>
                  `;
                }

                var button_class = loc_stock_pid <= 0 && loc_each_backorder != "Yes" ? " pointer-events: none !important;" : " pointer-events: auto !important;";
                var html2 = `
                  <div class='wcmlim-advanced-detailed' style="display: flex; align-items: center; gap: 10px;">
                    ${html1} <!-- Open By / Close By -->
                    <div class='wcmlim-quantity'>
                      <input 
                        type='number' 
                        name='product_qty' 
                        data-product_qty='4' 
                        class='ml-0 input-text qty text wcmlim_list_view_custom_input' 
                        step='1' 
                        min='1' 
                        max='${loc_stock_pid}' 
                        title='Qty' 
                        size='4' 
                        placeholder='1' 
                        inputmode='numeric' 
                        autocomplete='off'>
                    </div>
                    <div class='wcmlim-cart-button'>
                      <button 
                        type="submit" 
                        data-lc-term-id="${location_id}" 
                        name="add-to-cart" 
                        id="list_view" 
                        value="${product_id}" 
                        class="ml-0 single_add_to_cart_button single_add_to_cart_button1 button alt" 
                        style="${button_class}">
                        <span class='fa fa-shopping-cart'></span>
                      </button>
                    </div>
                  </div>
                `;

                $(".wclimrw_" + indexing + " .wclimcol2").wrap('<div class="wcmlim_wrapper_adv_list_view"></div>');
                $(html3).insertAfter(".wclimrw_" + indexing + " .wclimcol2 .stockupp");
                $(html).insertAfter(".wclimrw_" + indexing + " .wclimcol2 .wcmlim-advanced-detailed1");
                $(html2).insertAfter(".wclimrw_" + indexing + " .wcmlim_wrapper_adv_list_view .wclimcol2 .wcmlim_detadd");
              });

              var indexing = response.length;
              indexing = indexing + 1;
              $(".wclimrw_" + indexing).remove();
            },
          });
        }
      }
    }
    $(document).on("mouseover", ".wcmlradio_box .wclimrow", function () {
      $(this).children("input").prop("checked", true);
      $(".wclimcol1").removeClass("selected");
      $(this).toggleClass("selected");
      $(this).find("input").trigger("click");

      var qty_input = $(this).find('.wcmlim_list_view_custom_input').val();
      var qty_button = $(this).children(".wcmlim_addtocart").children("button");
      if (listmode == "on" && listformat == "advanced_list_view") {
        $(".single_add_to_cart_button, .quantity").hide();
      } else {
        $(".single_add_to_cart_button, .quantity").show();
      }

      $("form.cart input[name='quantity']").val(qty_input);
      $("form.cart input[name='quantity']").attr("max", qty_input);
      $("form.cart input[name='quantity']").attr("value", qty_input);
      $("form.cart input[name='quantity']").trigger("change");
    });
  }
});
