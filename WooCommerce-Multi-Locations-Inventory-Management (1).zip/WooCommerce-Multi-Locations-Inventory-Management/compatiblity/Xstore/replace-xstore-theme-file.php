<?php

//This will make wcmlim compatible with Xstore theme

$theme = wp_get_theme(); // gets the current theme
if ( 'Xstore' == $theme->name || 'Xstore' == $theme->parent_theme ) {
   
    
    add_filter( 'theme_file_path', 'wcmlim_replace_xstore_theme_file', 20, 2 );
    function wcmlim_replace_xstore_theme_file( $path, $file = '' ) {
        if( 'woocommerce/single-product/add-to-cart/simple.php' === $file ) {
            // change path here as required
            return plugin_dir_path( __FILE__ ) . 'compatiblity/Xstore/woocommerce/single-product/add-to-cart/simple.php';
        }
        return $path;
    }

    
}



?>